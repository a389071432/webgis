from flask import Flask
from flask_cors import CORS
app = Flask(__name__)
cors = CORS(app, resources={r"/submit_agent_file": {"origins": "*"},r"/upload_url_building": {"origins": "*"},r"/upload_url_landuse": {"origins": "*"},r"/upload_population_file": {"origins": "*"},
                            r"/upload_infected_model": {"origins": "*"},r"/construct_scene": {"origins": "*"},
                            r"/start_simulation": {"origins": "*"},r"/pause_simulation": {"origins": "*"},
                            r"/init_global_variables": {"origins": "*"},})

from views import build_scene
from views import globvars
from views import ol_home

app.register_blueprint(build_scene.us)
app.register_blueprint(ol_home.us)
app.register_blueprint(globvars.us)
