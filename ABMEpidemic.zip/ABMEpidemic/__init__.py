from flask import Flask
from flask_cors import CORS
app = Flask(__name__)
cors = CORS(app, resources={r"/submit_agent_file": {"origins": "*"},r"/upload_url_buildings": {"origins": "*"},r"/upload_url_landuse": {"origins": "*"},r"/upload_population_file": {"origins": "*"},
                            r"/upload_infected_model": {"origins": "*"},r"/construct_scene": {"origins": "*"},
                            r"/start_simulation": {"origins": "*"},r"/pause_simulation": {"origins": "*"},
                            r"/get_heats": {"origins": "*"},r"/get_statis": {"origins": "*"},r"/get_nodes_info": {"origins": "*"},
                            r"/continue_simulation": {"origins": "*"},
                            r"/upload_infected_params": {"origins": "*"}, r"/modify_infected_model": {"origins": "*"},
                            r"/init_globvars": {"origins": "*"},
                            r"/get_heats_3d": {"origins": "*"},
                            r"/get_trip_data": {"origins": "*"},
                            r"/construct_scene_temp": {"origins": "*"},
                            r"/reset_simulation": {"origins": "*"},
                           })

from views import build_scene
from views import globvars
from views import ol_home
from views import statis
from views import edit_infected_model
from views import ThreeDVisualize

app.register_blueprint(build_scene.us)
app.register_blueprint(ol_home.us)
app.register_blueprint(globvars.us)
app.register_blueprint(statis.us)
app.register_blueprint(edit_infected_model.us)
app.register_blueprint(ThreeDVisualize.us)