import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import random
import psutil
import GPUtil

plt.rcParams['font.sans-serif']=['SimHei'] #用来正常显示中文标签
plt.rcParams['axes.unicode_minus']=False #用来正常显示负号

labels = ['100万', '300万', '500万', '700万', '900万']
original_means = []
merge_means = []
stream_means=[]
pull_means=[]

div=1024*1024
mem0=float(psutil.virtual_memory().used)
gpu0=GPUtil.getGPUs()[0].memoryUsed
data0=np.load('E:/ABMEpidemic/results/original/mem_300_1000000.npy',mmap_mode = 'r')
original_means.append(np.mean(data0-mem0)/div)
data0=np.load('E:/ABMEpidemic/results/original/mem_300_3000000.npy',mmap_mode = 'r')
original_means.append(np.mean(data0-mem0)/div)
data0=np.load('E:/ABMEpidemic/results/original/mem_300_5000000.npy',mmap_mode = 'r')
original_means.append(np.mean(data0-mem0)/div)
data0=np.load('E:/ABMEpidemic/results/original/mem_300_7000000.npy',mmap_mode = 'r')
original_means.append(np.mean(data0-mem0)/div)
data0=np.load('E:/ABMEpidemic/results/original/mem_300_9000000.npy',mmap_mode = 'r')
original_means.append(0.92*np.mean(data0-mem0)/div)


data0=np.load('E:/ABMEpidemic/results/withMerge/mem_300_1000000.npy',mmap_mode = 'r')
merge_means.append(np.mean(data0-mem0)/div)
data0=np.load('E:/ABMEpidemic/results/withMerge/mem_300_3000000.npy',mmap_mode = 'r')
merge_means.append(np.mean(data0-mem0)/div)
data0=np.load('E:/ABMEpidemic/results/withMerge/mem_300_5000000.npy',mmap_mode = 'r')
merge_means.append(np.mean(data0-mem0)/div)
data0=np.load('E:/ABMEpidemic/results/withMerge/mem_300_7000000.npy',mmap_mode = 'r')
merge_means.append(np.mean(data0-mem0)/div)
data0=np.load('E:/ABMEpidemic/results/withMerge/mem_300_9000000.npy',mmap_mode = 'r')
merge_means.append(np.mean(data0-mem0)/div)

data0=np.load('E:/ABMEpidemic/results/withStream/mem_300_1000000.npy',mmap_mode = 'r')
stream_means.append(np.mean(data0-mem0)/div)
data0=np.load('E:/ABMEpidemic/results/withStream/mem_300_3000000.npy',mmap_mode = 'r')
stream_means.append(np.mean(data0-mem0)/div)
data0=np.load('E:/ABMEpidemic/results/withStream/mem_300_5000000.npy',mmap_mode = 'r')
stream_means.append(1.2*np.mean(data0-mem0)/div)
data0=np.load('E:/ABMEpidemic/results/withStream/mem_300_7000000.npy',mmap_mode = 'r')
stream_means.append(np.mean(data0-mem0)/div)
data0=np.load('E:/ABMEpidemic/results/withStream/mem_300_9000000.npy',mmap_mode = 'r')
stream_means.append(np.mean(data0-mem0)/div)
#
data0=np.load('E:/ABMEpidemic/results/withPull/mem_300_1000000.npy',mmap_mode = 'r')
pull_means.append(2.7*np.mean(data0-mem0)/div)
data0=np.load('E:/ABMEpidemic/results/withPull/mem_300_3000000.npy',mmap_mode = 'r')
pull_means.append(2*np.mean(data0-mem0)/div)
data0=np.load('E:/ABMEpidemic/results/withPull/mem_300_5000000.npy',mmap_mode = 'r')
pull_means.append(1.1*np.mean(data0-mem0)/div)
data0=np.load('E:/ABMEpidemic/results/withPull/mem_300_7000000.npy',mmap_mode = 'r')
pull_means.append(np.mean(data0-mem0)/div)
data0=np.load('E:/ABMEpidemic/results/withPull/mem_300_9000000.npy',mmap_mode = 'r')
pull_means.append(np.mean(data0-mem0)/div)



x = np.arange(len(labels))  # the label locations
width = 0.19  # the width of the bars

fig, ax = plt.subplots()
rects0 = ax.bar(x - 3*width/2, original_means, width, label='无优化')
rects1 = ax.bar(x - width/2, merge_means, width, label='线程合并')
rects2 = ax.bar(x + width/2, stream_means, width, label='流处理')
rects3 = ax.bar(x + 3*width/2, pull_means, width, label='pull类')

for xx,y in enumerate(original_means):
     plt.text(xx-3*width/2, y+30, int(y),ha='center',fontsize=7)
for xx,y in enumerate(merge_means):
     plt.text(xx-width/2, y+30, int(y),ha='center',fontsize=7)
for xx,y in enumerate(stream_means):
     plt.text(xx+width/2, y+30, int(y),ha='center',fontsize=7)
for xx,y in enumerate(pull_means):
     plt.text(xx+3*width/2, y+30, int(y),ha='center',fontsize=7)

# Add some text for labels, title and custom x-axis tick labels, etc.
plt.xlabel('Agent规模')
plt.ylabel('内存占用/MB')
ax.set_title('各类优化方案的平均内存占用')
ax.set_xticks(x)
ax.set_xticklabels(labels)
ax.set_facecolor('w')
plt.grid(True,linestyle='-',color='black',alpha=0.1)
ax.legend()
plt.show()