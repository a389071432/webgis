from views.classes.Agents import Agents
from views.classes.GeoInfo import GeoInfo
from views.classes.InfectedModel import InfectedModel
from views.classes.EventHandler import EventHandler
from views.classes.EpidemicScene import EpidemicSceneGPU
from views.classes.EpidemicSceneWithStream import EpidemicSceneStream
from views.classes.EpidemicSceneWithPull import EpidemicScenePull

agents=Agents()
infected_model=InfectedModel()
geoinfo=GeoInfo()
event_handler=EventHandler()

agents.data_to_numpy()
geoinfo.data_to_numpy()
infected_model.set_model([{'state0':'S','state1':'I','p0':'1','p1':'1','p2':'1','t0':'1','t1':'1','t2':'1'},
                          {'state0':'I','state1':'R','p0':'1','p1':'1','p2':'1','t0':'120','t1':'120','t2':'120'}])
infected_model.set_params(['1','1','1','1'],'1',['0','1','0'],['0','0','0'])
infected_model.data_to_numpy()
scene = EpidemicSceneGPU(event_handler, agents, geoinfo,infected_model, interval=1, duration=168)
scene.simulation(300)