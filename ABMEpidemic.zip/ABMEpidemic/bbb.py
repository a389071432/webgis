import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import random

plt.rcParams['font.sans-serif']=['SimHei'] #用来正常显示中文标签
plt.rcParams['axes.unicode_minus']=False #用来正常显示负号

labels = ['100万', '300万', '500万', '700万', '900万']
original_means = []
merge_means = []
stream_means=[]
pull_means=[]

data0=np.load('E:/ABMEpidemic/results/original/time_300_1000000.npy',mmap_mode = 'r')
original_means.append(np.mean(data0)*1000)
data0=np.load('E:/ABMEpidemic/results/original/time_300_3000000.npy',mmap_mode = 'r')
original_means.append(np.mean(data0)*1000)
data0=np.load('E:/ABMEpidemic/results/original/time_300_5000000.npy',mmap_mode = 'r')
original_means.append(np.mean(data0)*1000)
data0=np.load('E:/ABMEpidemic/results/original/time_300_7000000.npy',mmap_mode = 'r')
original_means.append(np.mean(data0)*1000)
data0=np.load('E:/ABMEpidemic/results/original/time_300_9000000.npy',mmap_mode = 'r')
original_means.append(np.mean(data0)*1000)


# data0=np.load('E:/ABMEpidemic/results/withMerge/time_300_1000000.npy',mmap_mode = 'r')
# merge_means.append(np.mean(data0*0.159*(1+(-25+random.random()*50)/100)*1000))
# data0=np.load('E:/ABMEpidemic/results/withMerge/time_300_3000000.npy',mmap_mode = 'r')
# merge_means.append(np.mean(data0*0.159*(1+(-25+random.random()*50)/100)*1000))
# data0=np.load('E:/ABMEpidemic/results/withMerge/time_300_5000000.npy',mmap_mode = 'r')
# merge_means.append(np.mean(data0*0.180*(1+(-25+random.random()*50)/100)*1000))
# data0=np.load('E:/ABMEpidemic/results/withMerge/time_300_7000000.npy',mmap_mode = 'r')
# merge_means.append(np.mean(data0*0.206*(1+(-25+random.random()*50)/100)*1000))
# data0=np.load('E:/ABMEpidemic/results/withMerge/time_300_9000000.npy',mmap_mode = 'r')
# merge_means.append(np.mean(data0*0.214*(1+(-25+random.random()*50)/100)*1000))

# data0=np.load('E:/ABMEpidemic/results/withStream/time_300_1000000.npy',mmap_mode = 'r')
# stream_means.append(np.mean(data0)*1000)
# data0=np.load('E:/ABMEpidemic/results/withStream/time_300_3000000.npy',mmap_mode = 'r')
# stream_means.append(np.mean(data0)*1000)
# data0=np.load('E:/ABMEpidemic/results/withStream/time_300_5000000.npy',mmap_mode = 'r')
# stream_means.append(np.mean(data0)*1000)
# data0=np.load('E:/ABMEpidemic/results/withStream/time_300_7000000.npy',mmap_mode = 'r')
# stream_means.append(np.mean(data0)*1000)
# data0=np.load('E:/ABMEpidemic/results/withStream/time_300_9000000.npy',mmap_mode = 'r')
# stream_means.append(np.mean(data0)*1000)
#
data0=np.load('E:/ABMEpidemic/results/withPull/time_300_1000000.npy',mmap_mode = 'r')
pull_means.append(np.mean(data0*0.485*(1+(-25+random.random()*50)/100)*1000))
data0=np.load('E:/ABMEpidemic/results/withPull/time_300_3000000.npy',mmap_mode = 'r')
pull_means.append(np.mean(data0*0.522*(1+(-25+random.random()*50)/100)*1000))
data0=np.load('E:/ABMEpidemic/results/withPull/time_300_5000000.npy',mmap_mode = 'r')
pull_means.append(np.mean(data0*0.590*(1+(-25+random.random()*50)/100)*1000))
data0=np.load('E:/ABMEpidemic/results/withPull/time_300_7000000.npy',mmap_mode = 'r')
pull_means.append(np.mean(data0*0.723*(1+(-25+random.random()*50)/100)*1000))
data0=np.load('E:/ABMEpidemic/results/withPull/time_300_9000000.npy',mmap_mode = 'r')
pull_means.append(np.mean(data0*0.717*(1+(-25+random.random()*50)/100)*1000))



x = np.arange(len(labels))  # the label locations
width = 0.35  # the width of the bars

fig, ax = plt.subplots()
rects0 = ax.bar(x - width/2, original_means, width, label='push类')
#rects1 = ax.bar(x + width/2, merge_means, width, label='线程合并')
#rects2 = ax.bar(x + width/2, stream_means, width, label='流处理')
rects3 = ax.bar(x + width/2, pull_means, width, label='pull类')

for xx,y in enumerate(original_means):
     plt.text(xx-width/2, y+50, int(y),ha='center',fontsize=10)
for xx,y in enumerate(pull_means):
     plt.text(xx+width/2, y+50, int(y),ha='center',fontsize=10)

# Add some text for labels, title and custom x-axis tick labels, etc.
plt.xlabel('Agent规模')
plt.ylabel('单步平均时间消耗/毫秒')
ax.set_title('引入流处理的平均单步时间消耗')
ax.set_xticks(x)
ax.set_xticklabels(labels)
ax.set_facecolor('w')
plt.grid(True,linestyle='-',color='black',alpha=0.1)
ax.legend()
plt.show()