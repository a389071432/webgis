import numpy as np
import random
import math

class GeoInfo:
    def __init__(self):
        #GIS信息（.shp文件）
        self.shp_buildings=None
        self.shp_landuse=None
        self.shp_population=None
        #bounding_box（经纬度范围）
        min_lat=None
        max_lat=None
        min_lon=None
        max_lon=None
        #基本参数
        self.grid_size=None
        self.n_buildings=None
        # 以数组存储信息
        self.building_location = None  # 每个建筑的位置(以grid为单位)
        self.grid_buildings = None # 记录每个网格内的建筑列表（建筑编号）
        self.grid_buildings_total = None  # 每个网格内的建筑总数
        self.building_size = None  # 每个建筑的规模
        self.building_type=None    #每个建筑的类型（根据用地类型确定）

    def set_data(self,shp_buildings,shp_landuse,shp_population):
        # GIS信息（.shp文件）
        self.shp_buildings = shp_buildings
        self.shp_landuse = shp_landuse
        self.shp_population = self.shp_population

    def data_to_numpy(self):   #根据GIS数据生成必要信息，并将数据组织为numpy（目前无真实数据输入，随意生成）
        self.min_lat=30.67
        self.max_lat=31.88
        self.min_lon=120.87
        self.max_lon=122.20
        self.grid_size=500
        self.n_buildings=100000

        #不需要改动
        dlat = self.grid_size / (1000 * 111)
        dlon=dlat
        nlat = math.ceil((self.max_lat - self.min_lat) / dlat)
        nlon = math.ceil((self.max_lon - self.min_lon) / dlon)
        self.building_location=np.zeros([self.n_buildings,2])
        self.grid_buildings = np.zeros([nlat, nlon, math.ceil(self.n_buildings/(nlat*nlon))]).astype(int)
        self.grid_buildings_total=np.zeros([self.n_grids,self.n_grids]).astype(int)
        self.building_size=np.zeros([self.n_buildings]).astype(int)
        self.building_type=np.zeros([self.n_buildings]).astype(int)

        Dlat=self.max_lat-self.min_lat
        Dlon=self.max_lon-self.min_lon
        for i in range(0,self.n_buildings):
            lat=self.min_lat+Dlat*random.random()
            lon=self.min_lon+Dlon*random.random()
            index_lat=math.floor((lat-self.min_lat)/dlat)
            index_lon=math.floor((lon-self.min_lon)/dlon)
            type=random.randint(0,3)
            self.building_location[i][0] = lat
            self.building_location[i][1] = lon
            self.grid_buildings[index_lat][index_lon][self.grid_buildings_total[index_lat][index_lon]]=i
            self.grid_buildings_total[index_lat][index_lon]+=1
            self.building_type[i]=type





