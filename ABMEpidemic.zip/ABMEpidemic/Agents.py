import numpy as np

class Agents:
    def __init__(self,data):  #以前端data为输入，目前没想好
        self.data=None
        #基本参数
        self.n_agents=None

    def set_data(self,data):  #接收前端数据
        self.data=data

    def data_to_numpy(self):
        self.n_agents=3000000

        # activity type统一编号如下：
        # 0:H 1:W 2:L 3:S
        self.agent_activity_type = np.zeros([self.n_agents, 8]).astype(int)
        self.agent_activity_duration = np.zeros([self.n_agents, 8])
        self.agent_activity_distance = np.zeros([self.n_agents, 8])
        self.agent_activity_total = np.zeros([self.n_agents, 8])

        #随机生成agent数据
