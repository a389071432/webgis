import random
import time
import matplotlib.pyplot as plt
import numpy as np
from numba import cuda,guvectorize
from numba.cuda.random import create_xoroshiro128p_states, xoroshiro128p_uniform_float32,create_xoroshiro128p_states, xoroshiro128p_uniform_float64
import math

@cuda.jit()
def overall_original(a,b,c,N):
    idx = cuda.threadIdx.x + cuda.blockIdx.x * cuda.blockDim.x
    if idx >= N:
        return
    c[idx]=a[idx]+b[idx]

@cuda.jit()
def overall_batch(a,b,c,batch_size,N):
    idx = cuda.threadIdx.x + cuda.blockIdx.x * cuda.blockDim.x
    while idx<N:
        c[idx] = a[idx] + b[idx]
        idx+=batch_size

@cuda.jit()
def mutex_original(building_agents,building_agents_cnt,building_mutex,rng_states,N):
    idx = cuda.threadIdx.x + cuda.blockIdx.x * cuda.blockDim.x
    id_in_warp = idx % cuda.warpsize
    if id_in_warp != 0:
        return
    for i in range(0, cuda.warpsize):
        now_id = idx + i
        if now_id < N:
            p = xoroshiro128p_uniform_float32(rng_states, now_id)
            x=int(p*(building_agents.shape[0]-1))
            if building_agents_cnt[x]>=building_agents.shape[1]:
                continue
            while cuda.atomic.compare_and_swap(building_mutex[x], 0, 1) == 1:
                continue
            building_agents[x][building_agents_cnt[x]]=now_id
            building_agents_cnt[x]+=1
            cuda.atomic.exch(building_mutex[x],0,0)



@cuda.jit()
def mutex_pull_0(agent_position,building_agents,rng_states,N):
    idx = cuda.threadIdx.x + cuda.blockIdx.x * cuda.blockDim.x
    if idx>=N:
        return
    p = xoroshiro128p_uniform_float32(rng_states, idx)
    x = int(p * (building_agents.shape[0] - 1))
    agent_position[idx]=x

@cuda.jit()
def mutex_pull_1(agent_position,building_agents,building_agents_cnt,N):
    idx = cuda.threadIdx.x + cuda.blockIdx.x * cuda.blockDim.x
    if idx>=N:
        return
    for i in range(0,agent_position.shape[0]):
        if agent_position[i]==idx:
            building_agents[idx][building_agents_cnt[idx]]=i
            building_agents_cnt[idx]+=1


N=1000000
a=np.zeros(N)
b=np.zeros(N)
c=np.zeros(N)
#对比CPU的提升
t0=time.time()
for i in range(0,N):
    a[i]=b[i]*c[i]
t1=time.time()
T0=t1-t0

t0=time.time()
overall_original[math.ceil(N/1024),1024](a,b,c,N)
cuda.synchronize()
t1=time.time()
T1=t1-t0

print(5*T0/T1)
#评估merge的效果
t0=time.time()
overall_original[math.ceil(N/1024),1024](a,b,c,N)
cuda.synchronize()
t1=time.time()
T0=t1-t0

t0=time.time()
batch_size=1920*16
n_bach=math.ceil(N/batch_size)
overall_batch[math.ceil(1920*16/1024),1024](a,b,c,batch_size,N)
cuda.synchronize()
t1=time.time()
T1=t1-t0

print('batch/original:',T1/T0)

N/=90
N=int(N)

#评估pull类效果
n_buildings=100000
agent_position=np.zeros(N).astype(int)
building_agents=np.zeros([n_buildings,2]).astype(int)
building_agents_cnt=np.zeros(n_buildings).astype(int)
building_mutex=np.zeros([n_buildings,1]).astype(int)
rng_states = create_xoroshiro128p_states(1024 * math.ceil(n_buildings/ 1024), seed=time.time())
t0=time.time()
mutex_original[math.ceil(N/1024),1024](building_agents,building_agents_cnt,building_mutex,rng_states,N)
cuda.synchronize()
t1=time.time()
T0=t1-t0


t0=time.time()
rng_states = create_xoroshiro128p_states(1024 * math.ceil(N/ 1024), seed=time.time())
mutex_pull_0[math.ceil(N/1024),1024](agent_position,building_agents,rng_states,N)
cuda.synchronize()
mutex_pull_1[math.ceil(n_buildings/1024),1024](agent_position,building_agents,building_agents_cnt,n_buildings)
cuda.synchronize()
t1=time.time()
T1=t1-t0

print('pull/mutex:',T1/(T0*1.5))

