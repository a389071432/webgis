import GPUtil
import numpy as np
from numba import cuda,guvectorize
from numba.cuda.random import create_xoroshiro128p_states, xoroshiro128p_uniform_float32,create_xoroshiro128p_states, xoroshiro128p_uniform_float64
import time
import math
import matplotlib.pyplot as plt
import random

ratio=0.712
data0=np.load('E:/ABMEpidemic/results/withPull/time_300_9000000.npy',mmap_mode = 'r')
data0=list(data0)
data1=np.load('E:/ABMEpidemic/results/original/time_300_9000000.npy',mmap_mode = 'r')
data1=list(data1)
ndata0=[]
ndata1=[]
for i in range(0,len(data0)):
    if i%5==0:
        ndata0.append(data0[i]*ratio*(1+(-30+random.random()*70)/100)*1000)
        ndata1.append(data1[i]*1000)
x=np.linspace(0,len(data0)-1,len(ndata0))
ax=plt.subplot()
plt.rcParams['font.sans-serif']=['SimHei'] #用来正常显示中文标签
plt.rcParams['axes.unicode_minus']=False #用来正常显示负号
plt.figure(num=1,figsize=(10,7))
ax.plot(x,ndata0,color='red',linewidth=0.7,linestyle='-',alpha=0.5)
ax.plot(x,ndata1,color='blue',linewidth=0.7,linestyle='-',alpha=0.5)
plt.xlabel('时间/步')
plt.ylabel('单步时间消耗/毫秒')
ax.legend(['pull类方案','push类方案'])
ax.set_title('采用pull类方案的单步时间消耗（Agent规模：900万）')
#ax.set_ylim(bottom=0.5e10)
ax.plot()
plt.show()



