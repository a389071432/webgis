import numpy as np
import random
import math
from owslib.wms import WebMapService
from owslib.fes import *
from owslib.etree import etree
from owslib.wfs import WebFeatureService
from requests import Request
import geopandas as gpd
from shapely.geometry import Polygon, Point

class GeoInfo:
    def __init__(self):
        #来自前端的url
        self.url_buildings=None
        self.url_landuse=None
        self.url_population=None
        #GIS数据(Geopandas.DataFrame格式)
        self.data_buildings=None
        self.data_landuse=None
        self.data_population=None
        #bounding_box（经纬度范围）
        self.min_lat=None
        self.max_lat=None
        self.min_lon=None
        self.max_lon=None
        self.dlat=None
        self.dlon=None
        #基本参数
        self.grid_size=None
        self.n_buildings=None
        # 以数组存储信息
        self.building_location = None  # 每个建筑的位置(以grid为单位)
        self.building_location_lonlat=None #每个建筑的位置（以经纬度为单位）
        self.grid_buildings = None # 记录每个网格内的建筑列表（建筑编号）
        self.grid_buildings_total = None  # 每个网格内的建筑总数
        self.building_size = None  # 每个建筑的规模
        self.building_type=None    #每个建筑的类型（根据用地类型确定）

    def set_url_buildings(self,url_buildings):
        self.url_buildings = url_buildings

    def set_url_landuse(self,url_landuse):
        self.url_landuse = url_landuse

    def set_url_population(self,urL_population):
        self.url_population = self.url_population

    def fetch_data(self):  #调用WFS服务从GeoServer依次获取shp文件
        wfs = WebFeatureService(url=self.url_buildings, version='1.1.0')
        layer = list(wfs.contents)[0]
        params = dict(service='WFS', version="1.0.0", request='GetFeature',
                      typeName=layer, outputFormat='json')
        q = Request('GET', self.url_buildings, params=params).prepare().url
        self.data_buildings = gpd.read_file(q)

        wfs = WebFeatureService(url=self.url_landuse, version='1.1.0')
        layer = list(wfs.contents)[0]
        params = dict(service='WFS', version="1.0.0", request='GetFeature',
                      typeName=layer, outputFormat='json')
        # Parse the URL with parameters
        q = Request('GET', self.url_buildings, params=params).prepare().url
        self.data_landuse = gpd.read_file(q)

        wfs = WebFeatureService(url=self.url_population, version='1.1.0')
        layer = list(wfs.contents)[0]
        params = dict(service='WFS', version="1.0.0", request='GetFeature',
                      typeName=layer, outputFormat='json')
        # Parse the URL with parameters
        q = Request('GET', self.url_buildings, params=params).prepare().url
        self.data_population = gpd.read_file(q)

    def data_to_numpy(self):   #根据GIS数据生成必要信息，并将数据组织为numpy（目前无真实数据输入，随意生成）
        self.min_lat=31.0827875
        self.max_lat=31.41700379
        self.min_lon=121.12548861
        self.max_lon=121.6635758
        self.grid_size=4500
        self.n_buildings=4000

        #不需要改动
        dlat = self.grid_size / (1000 * 111)
        dlon=dlat
        self.dlat=dlat
        self.dlon=dlon
        nlat = math.ceil((self.max_lat - self.min_lat) / dlat)
        nlon = math.ceil((self.max_lon - self.min_lon) / dlon)
        self.building_location=np.zeros([self.n_buildings,2]).astype(int)
        self.building_location_lonlat = np.zeros([self.n_buildings, 2])
        self.grid_buildings_total=np.zeros([nlat,nlon]).astype(int)
        self.building_size=np.zeros([self.n_buildings]).astype(int)
        self.building_type=np.zeros([self.n_buildings]).astype(int)

        Dlat=self.max_lat-self.min_lat
        Dlon=self.max_lon-self.min_lon
        temp_cnt=np.zeros(self.grid_buildings_total.shape).astype(int)
        for i in range(0,self.n_buildings):
            lat=self.min_lat+Dlat*random.random()
            lon=self.min_lon+Dlon*random.random()
            index_lat=math.floor((lat-self.min_lat)/dlat)
            index_lon=math.floor((lon-self.min_lon)/dlon)
            self.building_location[i][0] = index_lat
            self.building_location[i][1] = index_lon
            self.building_location_lonlat[i][0]=lat
            self.building_location_lonlat[i][1]=lon
            # print('nlat nlon',nlat,nlon)
            temp_cnt[index_lat][index_lat]+=1

        self.grid_buildings = np.zeros([nlat, nlon, np.max(temp_cnt)]).astype(int)
        for i in range(0,self.n_buildings):
            lat = self.building_location_lonlat[i][0]
            lon = self.building_location_lonlat[i][1]
            index_lat = math.floor((lat - self.min_lat) / dlat)
            index_lon = math.floor((lon - self.min_lon) / dlon)
            # print('nlat nlon',nlat,nlon)
            # print('index_lat index_lon', index_lat, index_lon)
            # print('grid_buildings',self.grid_buildings.shape)
            # print('grid_buildings_total', self.grid_buildings_total.shape)
            self.grid_buildings[index_lat][index_lon][self.grid_buildings_total[index_lat][index_lon]]=i
            self.grid_buildings_total[index_lat][index_lon]+=1
            type = random.randint(0, 3)  # 四种type
            self.building_type[i]=type




