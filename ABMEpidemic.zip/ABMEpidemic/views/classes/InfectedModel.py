import numpy as np

class InfectedModel:
    def __init__(self):
        self.trasition_form=None
        self.p=None
        self.land_contacts=None
        #基本参数
        self.n_nodes=None
        self.max_degree=None
        #以数组存储信息
        # 规定感染状态的编号，0-未感染(Susceptible) 1-住院 2-恢复(Recovered/出院) 3-死亡
        self.node_name=None  #每个结点（状态）的名称
        self.trasition_graph_node = None  # 结点
        self.trasition_graph_prob = None  # 转移概率
        self.trasiton_graph_delay = None  # 转移时延
        self.trasition_graph_degree = None #每个结点的度
        self.type_contacts=None   #每种类型建筑内的接触次数，由land_contacts确定

    def set_data(self,trasition_form,land_contacts,p):
        # 接收前端数据
        self.trasition_form = trasition_form
        self.p = p
        self.land_contacts = land_contacts

    def data_to_numpy(self):
        #根据trasition_form构建


        self.trasition_graph_node = np.zeros([self.n_nodes, self.max_degree]).astype(int)
        self.trasition_graph_prob = np.zeros([self.n_nodes, self.max_degree,3])
        self.trasition_graph_delay = np.zeros([self.n_nodes, self.max_degree,3])
        self.trasition_graph_degree = np.zeros(self.n_nodes).astype(int)
        self.type_contacts=np.zeros([4])