import numpy as np

class InfectedModel:
    def __init__(self):
        self.trasition_form=None
        self.p=None
        self.land_contacts=np.zeros(4).astype(int)
        #基本参数
        self.n_nodes=None
        self.max_degree=None
        #以数组存储信息
        # 规定感染状态的编号，0-未感染(Susceptible) 1-住院 2-恢复(Recovered/出院) 3-死亡
        self.node_name=None   #每个结点（状态）的名称
        self.node_degree=None
        self.name2num=None    #结点名称到编号的映射
        self.infectivity=None
        self.quarantine=None
        self.node_infectivity=None   #某状态是否具有传染力
        self.node_quarantine=None      #某状态是否被隔离（限制活动）
        self.trasition_graph_node = None  # 结点
        self.trasition_graph_prob = None  # 转移概率
        self.trasition_graph_delay = None  # 转移时延
        self.trasition_graph_degree = None #每个结点的度
        self.type_contacts=None   #每种类型建筑内的接触次数，由land_contacts确定

    def set_model(self,trasition_form):
        # 接收前端数据
        self.trasition_form = trasition_form

    def set_params(self,land_contacts,p,node_infectivity,node_quarantine):
        print(type(land_contacts))
        print('land_contacts:',land_contacts)
        self.land_contacts=land_contacts
        self.p=float(p)
        self.infectivity =node_infectivity  #字典形式
        self.quarantine = node_quarantine

    def data_to_numpy(self):
        #根据trasition_form构建
        self.name2num={}
        temp_name2num={}
        self.n_nodes=0
        for edge in self.trasition_form:
            node0=edge['state0']
            node1=edge['state1']
            if not temp_name2num.__contains__(node0):
                temp_name2num[node0]=self.n_nodes
                self.n_nodes += 1
            if not temp_name2num.__contains__(node1):
                temp_name2num[node1] = self.n_nodes
                self.n_nodes += 1

        print('n_nodes:',self.n_nodes)
        self.node_name=[0]*int(self.n_nodes)
        self.n_nodes=0
        for edge in self.trasition_form:
            node0=edge['state0']
            node1=edge['state1']
            num0=-1
            num1=-1
            if self.name2num.__contains__(node0):
                num0=self.name2num[node0]
            else:
                num0=self.n_nodes
                self.node_name[num0]=node0
                self.name2num[node0]=num0
                self.n_nodes += 1
            if self.name2num.__contains__(node1):
                num1=self.name2num[node1]
            else:
                num1 = self.n_nodes
                self.node_name[num1] = node1
                self.name2num[node1] = num1
                self.n_nodes += 1

        self.trasition_graph_degree = np.zeros(self.n_nodes).astype(int)
        self.node_degree=np.zeros(self.n_nodes).astype(int)
        for edge in self.trasition_form:
            node0=edge['state0']
            num0=self.name2num[node0]
            self.trasition_graph_degree[num0]+=1
        self.max_degree=np.max(self.trasition_graph_degree)

        self.trasition_graph_node = np.zeros([self.n_nodes, self.max_degree]).astype(int)
        self.trasition_graph_prob = np.zeros([self.n_nodes, self.max_degree,3])
        self.trasition_graph_delay = np.zeros([self.n_nodes, self.max_degree,3])
        for edge in self.trasition_form:
            node0=edge['state0']
            node1=edge['state1']
            p0=float(edge['p0'])
            p1=float(edge['p1'])
            p2=float(edge['p2'])
            t0=float( edge['t0'])
            t1=float(edge['t1'])
            t2=float( edge['t2'])

            num0=self.name2num[node0]
            num1=self.name2num[node1]
            degree0=self.node_degree[num0]
            self.trasition_graph_node[num0][degree0]=num1
            self.trasition_graph_prob[num0][degree0][0]=p0
            self.trasition_graph_prob[num0][degree0][1] =p1
            self.trasition_graph_prob[num0][degree0][2] =p2

            self.trasition_graph_delay[num0][degree0][0] = t0
            self.trasition_graph_delay[num0][degree0][1] = t1
            self.trasition_graph_delay[num0][degree0][2] = t2
            self.node_degree[num0]+=1

        #以下待修改前端，应从前端获取
        self.node_infectivity=np.zeros(self.n_nodes).astype(int)
        self.node_quarantine=np.zeros(self.n_nodes).astype(int)
        self.type_contacts=np.zeros([4])
        for i in range(0,self.type_contacts.shape[0]):
            self.type_contacts[i]=float(self.land_contacts[i])
        for i in range(0,self.n_nodes):
            self.node_infectivity[i]=int(self.infectivity[i])
        for i in range(0,self.n_nodes):
            self.node_quarantine[i]=int(self.quarantine[i])


    def modify_infected_model(self):
        cnt=np.zeros(self.n_nodes).astype(int)
        for edge in self.trasition_form:
            node0=edge['state0']
            node1=edge['state1']
            p0=float(edge['p0'])
            p1=float(edge['p1'])
            p2=float(edge['p2'])
            t0=float( edge['t0'])
            t1=float(edge['t1'])
            t2=float( edge['t2'])
            num0=self.name2num[node0]
            num1=self.name2num[node1]
            cnt0=cnt[num0]
            self.trasition_graph_node[num0][cnt0]=num1
            self.trasition_graph_prob[num0][cnt0][0]=p0
            self.trasition_graph_prob[num0][cnt0][1] =p1
            self.trasition_graph_prob[num0][cnt0][2] =p2

            self.trasition_graph_delay[num0][cnt0][0] = t0
            self.trasition_graph_delay[num0][cnt0][1] = t1
            self.trasition_graph_delay[num0][cnt0][2] = t2
            cnt[num0]+=1