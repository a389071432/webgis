import time
import matplotlib.pyplot as plt
import numpy as np
from numba import cuda,guvectorize
from numba.cuda.random import create_xoroshiro128p_states, xoroshiro128p_uniform_float32,create_xoroshiro128p_states, xoroshiro128p_uniform_float64
import math

@cuda.jit
def init_building_free_list_gpu(building_agents_free_list,building_agents_free_list_front,building_agents_free_list_rear,N):
    idx = cuda.threadIdx.x + cuda.blockIdx.x * cuda.blockDim.x
    if idx >= N:
        return
    for i in range(0,building_agents_free_list.shape[1]-1):
        building_agents_free_list[idx][i]=i
    building_agents_free_list_front[idx]=0
    building_agents_free_list_rear[idx]=building_agents_free_list.shape[1]-1

@cuda.jit
def init_infected_trasition_events_gpu(agent_infected_status,agent_next_infected_staus,new_event_mutex,new_event_pointer,new_event_type,new_event_agent,new_event_delay,N):
    idx = cuda.threadIdx.x + cuda.blockIdx.x * cuda.blockDim.x
    if idx >= N:
        return
    id_in_warp = idx % cuda.warpsize
    if id_in_warp != 0:
        return
    for i in range(0, cuda.warpsize):
        now_id = idx + i
        if now_id < N:
            if agent_infected_status[now_id]>0:
                agent_next_infected_staus[now_id]=1
                while cuda.atomic.compare_and_swap(new_event_mutex, 0, 1) == 1:
                    continue
                new_event_type[new_event_pointer[0]] = 2
                new_event_delay[new_event_pointer[0]] =0
                new_event_agent[new_event_pointer[0]] = now_id
                new_event_pointer[0] += 1
                cuda.atomic.exch(new_event_mutex, 0, 0)

@cuda.jit
def init_activity_trasition_events_gpu(agent_activity_duration,new_event_mutex,new_event_pointer, new_event_type,new_event_delay, new_event_agent,N):
    idx = cuda.threadIdx.x + cuda.blockIdx.x * cuda.blockDim.x
    if idx >= N:
        return
    id_in_warp = idx % cuda.warpsize
    if id_in_warp != 0:
        return
    for i in range(0, cuda.warpsize):
        now_id = idx + i
        if now_id < N:
            delay=agent_activity_duration[now_id][0]
            while cuda.atomic.compare_and_swap(new_event_mutex, 0, 1) == 1:
                continue
            new_event_type[new_event_pointer[0]] =1
            new_event_delay[new_event_pointer[0]] = delay
            new_event_agent[new_event_pointer[0]] = now_id
            new_event_pointer[0]+=1
            cuda.atomic.exch(new_event_mutex,0,0)


@cuda.jit
def event_step_gpu(event_type,event_agent,new_event_mutex,new_event_pointer,new_event_type,new_event_agent,new_event_delay,
                   agent_activity_position,agent_activity_distance,agent_position,agent_activity_total,agent_activity_index,agent_activity_type,agent_family,agent_work,agent_activity_duration,agent_infected_status,agent_next_infected_status,
                   trasition_graph_degree,trasition_graph_prob,trasition_graph_node,trasition_graph_delay,
                   building_agents_cnt,building_mutex,building_size,building_location,building_agents,building_free_list,building_free_list_front,building_free_list_rear,grid_buildings,grid_building_total,building_near_hospital,
                   hospital_agents_cnt,hospital_capacity,hospital_mutex,hospital_free_list,hospital_free_list_front,hospital_agents,
                   grid_size,rng_states,N):
    idx = cuda.threadIdx.x + cuda.blockIdx.x * cuda.blockDim.x
    if idx >= N:
        return
    id_in_warp = idx % cuda.warpsize
    if id_in_warp != 0:
        return

    for i in range(0, cuda.warpsize):
        now_id = idx + i
        if now_id < N:
            new_type = -1
            new_delay = -1
            new_agent = -1
            agent=event_agent[now_id]
            type=event_type[now_id]
            if agent_infected_status==3:   #跳过死亡的agent
                continue
            #处理单个事件
            if type == 0:                 # 0代表transport_finish(activity_start)
                #跳过隔离中的agent
                if agent_infected_status[agent]==1:
                    continue
                agent_activity_index[agent] += 1
                agent_activity_index[agent] %= agent_activity_total[agent]
                # 先查询新的活动地点（building_id）
                building_id = agent_activity_position[agent][agent_activity_index[agent]]
                # 将agent置入新的building
                while cuda.atomic.compare_and_swap(building_mutex[building_id], 0, 1) == 1:
                    continue
                npos = building_free_list[building_id][building_free_list_front[building_id]]
                building_free_list_front[building_id] += 1
                building_free_list_front[building_id] %= building_agents.shape[2]
                building_agents[building_id][npos] = agent
                building_agents_cnt[building_id] += 1
                cuda.atomic.exch(building_mutex[building_id], 0, 0)
                agent_position[agent] = building_id

                #注册一个活动结束事件
                next_index = (agent_activity_index[agent] + 1) % agent_activity_duration.shape[1]
                #next_activity_type = agent_activity_type[agent][next_index]
                new_type=1
                new_agent = agent
                new_delay = agent_activity_duration[agent][agent_activity_index[agent]]
            elif type == 1:               # 1代表activity结束
                # 跳过隔离中的agent
                if agent_infected_status[agent] == 1:
                    continue
                next_activity_index=(agent_activity_index[agent]+1) %agent_activity_total[agent]
                next_building_id = -1
                # 选择下一个目的地
                # 分为H/W/other三种情况
                activity_type = agent_activity_type[agent][next_activity_index]
                if activity_type == 0:  # H
                    next_building_id = agent_family[agent]
                elif activity_type == 1:  # W
                    next_building_id = agent_work[agent]
                else:  # other
                    # 选择下一个目的地
                    # 查询两次activity间隔距离
                    dis = agent_activity_distance[agent][agent_activity_index[agent]]
                    # 确定具体的活动场所（building_id）
                    now_x = building_location[now_building_id][0]
                    now_y = building_location[now_building_id][1]
                    nx=-1
                    ny=-1
                    while not (nx >= 0 and nx < grid_buildings.shape[0] and ny >= 0 and ny < grid_buildings.shape[1]):
                        theta = xoroshiro128p_uniform_float32(rng_states, now_id) * 360
                        theta = theta * math.pi / 180
                        dx = int(dis*math.cos(theta)/grid_size)
                        dy = int(dis*math.sin(theta)/grid_size)
                        nx = now_x + dx
                        ny = now_y + dy
                    while next_building_id == -1:
                        id = int(xoroshiro128p_uniform_float32(rng_states, now_id) * (grid_building_total[nx][ny] - 1))
                        next_building_id=grid_buildings[nx][ny][id]
                        if building_agents_cnt[id] < building_size[id]:
                            next_building_id = id
                agent_activity_position[agent][next_activity_index]=next_building_id
                #估算旅行时长

                #将agent从当前的活动地点移除
                # 查询agent目前所在地点（building_id）
                now_building_id = agent_position[agent]
                pos = int(-1)
                k = 0
                while k < building_agents.shape[1]:
                    if building_agents[now_building_id][k] == agent:
                        pos = k
                        break
                    k += 1
                if pos != -1:
                    building_agents[now_building_id][pos] = -1
                    while cuda.atomic.compare_and_swap(building_mutex[now_building_id], 0, 1) == 1:
                        continue
                    building_free_list[now_building_id][building_free_list_rear[now_building_id]] = pos
                    building_free_list_rear[now_building_id] += 1
                    building_free_list_rear[now_building_id] %= building_agents.shape[1]
                    cuda.atomic.exch(building_mutex[now_building_id], 0, 0)
                agent_position[agent] = -1
                #注册一个到达事件（待修改）
                new_type = 0
                new_agent = agent
                new_delay = 5  #（待修改!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!）
            elif type==2:                # 2代表infected_status_trasition
                agent_infected_status[agent]=agent_next_infected_status[agent]
                now_status = agent_infected_status[agent]
                #如果感染状态为1.则入院
                if now_status==1:
                    # 先选择目标医院/隔离点(hospital_id)
                    target_hospital_id = -1
                    for k in range(0, building_near_hospital.shape[0]):
                        id = building_near_hospital[k]
                        if hospital_agents_cnt[id] < hospital_capacity[id]:
                            target_hospital_id = id
                            break
                    #如果附近医院没有容量，移送集中隔离点

                    #将agent置入医院/隔离点
                    while cuda.atomic.compare_and_swap(hospital_mutex[target_hospital_id], 0, 1) == 1:
                        continue
                    npos = hospital_free_list[target_hospital_id][hospital_free_list_front[target_hospital_id]]
                    hospital_free_list_front[target_hospital_id] += 1
                    hospital_free_list_front[target_hospital_id] %= hospital_agents.shape[2]
                    hospital_agents[target_hospital_id][npos] = agent
                    hospital_agents_cnt[target_hospital_id] += 1
                    cuda.atomic.exch(hospital_mutex[target_hospital_id], 0, 0)
                    #再将其从所在building移除
                    activity_type=agent_activity_type[agent][agent_activity_index[agent]]
                    now_building_id = agent_position[agent]
                    pos = int(-1)
                    k = 0
                    while k < building_agents.shape[1]:
                        if building_agents[now_building_id][k] == agent:
                            pos = k
                            break
                        k += 1
                    if pos != -1:
                        building_agents[now_building_id][pos] = -1
                        while cuda.atomic.compare_and_swap(building_mutex[now_building_id], 0, 1) == 1:
                            continue
                        building_free_list[now_building_id][building_free_list_rear[now_building_id]] = pos
                        building_free_list_rear[now_building_id] += 1
                        building_free_list_rear[now_building_id] %= building_agents.shape[1]
                        cuda.atomic.exch(building_mutex[now_building_id], 0, 0)
                #如果感染状态为2，则出院
                # elif now_status==2:
                #     #后期再考虑恢复该agent的日常活动
                #
                #     #将agent从hospital移除
                #     agent_hospital
                #根据转移概率确定下一个感染状态
                p=xoroshiro128p_uniform_float32(rng_states, now_id)
                new_status=-1
                p_sum=0
                for k in range(0,trasition_graph_degree[now_status]):
                    if p>= p_sum and p<=p_sum+trasition_graph_prob[now_status][k]:
                        new_status=trasition_graph_node[now_status][k]
                        new_delay=trasition_graph_delay[now_status][k]
                        break
                    p_sum+=trasition_graph_prob[now_status][k]
                agent_next_infected_status[agent]=new_status
                new_agent=agent
                new_type=2
                if trasition_graph_degree[now_status]==0:
                    new_type=-1
            # 若插入新事件，互斥访问new_event
            if new_type == -1:
                continue
            while cuda.atomic.compare_and_swap(new_event_mutex, 0, 1) == 1:
                continue
            new_event_type[new_event_pointer[0]] = new_type
            new_event_agent[new_event_pointer[0]] = new_agent
            new_event_delay[new_event_pointer[0]] = new_delay
            new_event_pointer[0] += 1
            cuda.atomic.exch(new_event_mutex, 0, 0)


@cuda.jit
def update_infected_status_gpu(agent_infected_status,
                               building_agents,building_type,building_free_list_front,building_free_list_rear,
                               new_event_mutex,new_event_pointer,new_event_type,new_event_agent,new_event_delay,
                               rng_states,next_infected_status,land_contacts,infected_p,temp,N):
    idx = cuda.threadIdx.x + cuda.blockIdx.x * cuda.blockDim.x
    if idx >= N:
        return
    id_in_warp = idx % cuda.warpsize
    if id_in_warp != 0:
        return
    for i in range(0, cuda.warpsize):
        now_id = idx + i
        if now_id < N:
            #该建筑体内当前有多少agent
            front=building_free_list_front[now_id]
            rear=building_free_list_rear[now_id]
            cnt=0
            for k in range(0,building_agents.shape[2]):
                if building_agents[now_id][k]!=-1:
                    temp[now_id][cnt]=building_agents[now_id][k]
                    cnt+=1
            #该建筑体属于那种用地类型，根据类型确定接触次数
            land_type=building_type
            ave_contact=land_contacts[land_type]
            #随机从该建筑体内选择若干对agent进行接触，平均每个agent接触2人
            now=0
            while now<ave_contact*cnt/2:
                a=xoroshiro128p_uniform_float32(rng_states, now_id)*(cnt-1)
                b=xoroshiro128p_uniform_float32(rng_states, now_id)*(cnt-1)
                a=int(a)
                b=int(b)
                agent_a=temp[now_id][a]
                agent_b=temp[now_id][b]
                now += 1
                if agent_infected_status[agent_a] > 0 or agent_infected_status[agent_b] > 0:  #接触检测
                    p = xoroshiro128p_uniform_float32(rng_states, now_id)
                    if infected_p>p:
                        next_infected_status[agent_a] = 1  # 1代表刚被感染
                        infected_agent=-1
                        if agent_infected_status[agent_a]==0:
                            infected_agent=agent_a
                        elif agent_infected_status[agent_b]==0:
                            infected_agent=agent_b
                        while cuda.atomic.compare_and_swap(new_event_mutex, 0, 1) == 1:
                            continue
                        new_event_type[new_event_pointer[0]] = 2
                        new_event_delay[new_event_pointer[0]] = 0
                        new_event_agent[new_event_pointer[0]] = infected_agent
                        new_event_pointer[0] += 1
                        cuda.atomic.exch(new_event_mutex, 0, 0)



@cuda.jit
def statis_building_infected_cnt_gpu(agent_position,agent_infected_status,building_infected_status_cnt,temp_mutex,N):
    idx = cuda.threadIdx.x + cuda.blockIdx.x * cuda.blockDim.x
    if idx >= N:
        return
    id_in_warp = idx % cuda.warpsize
    if id_in_warp != 0:
        return
    for i in range(0, cuda.warpsize):
        now_id = idx + i
        if now_id < N:
            if agent_infected_status[now_id]!=1:
                continue
            building_id = agent_position[now_id]
            status=agent_infected_status[now_id]
            while cuda.atomic.compare_and_swap(temp_mutex[building_id][status], 0, 1) == 1:
                continue
            building_infected_status_cnt[building_id][status] += 1
            cuda.atomic.exch(temp_mutex[building_id][status], 0, 0)

@cuda.jit
def init_agent_position_gpu(agent_position,agent_family,N):
    idx = cuda.threadIdx.x + cuda.blockIdx.x * cuda.blockDim.x
    if idx >= N:
        return
    agent_position[idx]=agent_family[idx]

@cuda.jit
def assign_agent_to_family_gpu(agent_family,sum,grid_buildings,grid_buildings_total,rng_states,N):
    idx = cuda.threadIdx.x + cuda.blockIdx.x * cuda.blockDim.x
    if idx >= N:
        return
    p=xoroshiro128p_uniform_float32(rng_states, idx)
    pos=0
    while pos<sum.shape[0] and sum[pos]<p:
        pos+=1
    x=pos/grid_buildings.shape[0]
    y=pos%grid_buildings.shape[1]
    id = int(xoroshiro128p_uniform_float32(rng_states, idx) * (grid_buildings_total[x][y] - 1))
    agent_family[idx]=grid_buildings[x][y][id]

@cuda.jit
def assign_agent_to_work_gpu(agent_family,agent_commuting_distance,agent_work,building_location,grid_buildings,grid_buildings_total,grid_size,rng_states,N):
    idx = cuda.threadIdx.x + cuda.blockIdx.x * cuda.blockDim.x
    if idx >= N:
        return
    if agent_commuting_distance[idx]==-1:
        agent_work[idx]=-1
        return
    dis = agent_commuting_distance[idx]
    now_building_id=agent_family[idx]
    # 确定具体的活动场所（building_id）
    now_x = building_location[now_building_id][0]
    now_y = building_location[now_building_id][1]
    nx = -1
    ny = -1
    while not (nx >= 0 and nx < grid_buildings.shape[0] and ny >= 0 and ny < grid_buildings.shape[1]):
        theta = xoroshiro128p_uniform_float32(rng_states, idx) * 360
        theta = theta * math.pi / 180
        dx = int(dis * math.cos(theta) / grid_size)
        dy = int(dis * math.sin(theta) / grid_size)
        nx = now_x + dx
        ny = now_y + dy
    id = int(xoroshiro128p_uniform_float32(rng_states, id) * (grid_buildings_total[nx][ny] - 1))
    agent_work[idx]=grid_buildings[nx][ny][id]

class EpidemicSceneGPU:
    def __init__(self, event_handler, agents, geoinfo,infected_model, interval=1,duration=168):
        #仿真参数
        self.current_step = 0
        self.total_steps=duration
        self.event_handler=event_handler
        self.interval=interval
        self.total_step=None
        self.on_simulation=False

        #来自Agents
        #activity type统一编号如下：
        #0:H 1:W 2:L 3:S
        self.n_agents=agents.n_agents
        self.agent_activity_type=agents.agent_activity_type
        self.agent_activity_duration=agents.agent_activity_duration
        self.agent_activity_distance=agents.agent_activity_distance
        self.agent_activity_total=agents.agent_activity_total
        self.agent_family=agents.agent_family
        self.agent_commuting_distance=agents.agent_commuting_distance
        self.agent_work=None
        self.agent_current_activity_index=np.zeros(self.n_agents).astype(int)
        self.agent_infected_status=np.zeros(self.n_agents).astype(int)
        self.agent_next_infected_status=np.zeros(self.n_agents).astype(int)
        self.agent_position=np.zeros(self.n_agents).astype(int)


        #感染状态转移图相关,来自infected_model
        #规定感染状态的编号，0-未感染(Susceptible) 1-住院 2-恢复(Recovered/出院) 3-死亡
        self.infected_p=infected_model.p
        self.node_name=infected_model.node_name
        self.n_nodes=infected_model.n_nodes
        self.trasition_graph_node=infected_model.trasition_graph_node   #结点
        self.trasition_graph_prob=infected_model.trasition_graph_prob   #转移概率
        self.trasiton_graph_delay=infected_model.trasition_graph_delay   #转移时延
        self.trasition_graph_degree=infected_model.trasition_graph_degree
        self.type_contacts=infected_model.type_contacts

        #城市空间信息相关，来自geoinfo
        self.n_buildings=geoinfo.n_buildings
        self.building_location=geoinfo.building_location
        self.building_location_lonlat=geoinfo.building_location_lonlat
        self.grid_size=geoinfo.grid_size
        self.grid_buildings=geoinfo.grid_buildings
        self.grid_buildings_total=geoinfo.grid_buildings_total
        self.building_size=geoinfo.building_size
        self.building_type=geoinfo.building_type

        self.building_agents=np.zeros([self.n_buildings,300]).astype(int)
        self.building_agents_cnt=np.zeros(self.n_buildings).astype(int)
        self.buildng_agents_free_list=np.zeros([self.n_buildings,300]).astype(int)     #每个building的agent列表的空闲位置索引，以循环队列的形式实现
        self.building_agents_free_list_front=np.zeros([self.n_buildings,300]).astype(int)          #front和rear指针
        self.building_agents_free_list_rear = np.zeros([self.n_buildings,300]).astype(int)
        self.building_agents_cnt=np.zeros(self.n_buildings).astype(int)   #当前每个building内部的agent数量
        self.building_infected_status_cnt=np.zeros([self.n_buildings,self.n_nodes]).astype(int)
        self.building_near_hospital=None #存储每个建筑就近的医院

        #event相关
        self.new_event_mutex = np.zeros(1).astype(int)
        self.new_event_pointer = np.zeros(1).astype(int)
        self.new_event_type = np.zeros(10000000).astype(int)
        self.new_event_delay = np.zeros(10000000)
        self.new_event_agent = np.zeros(10000000).astype(int)


        #医疗资源相关
        self.hospital_total=None     #总数
        self.hospital_capacity=None  #容量
        self.hospital_agents=None  #当前所收容的患者(编号)
        self.hospital_agents_cnt=None #当前医院收容的患者数
        self.hospital_agents_free_list =None
        # front和rear指针
        self.hospital_agents_free_list_front = None
        self.hospital_agents_free_list_rear = None
        self.grid_hospitals =None

        #感染状态宏观统计
        self.step_infected_status_cnt=None

        #初始化各数组
        self.init_arrays_for_gpu()
        self.assign_agent_to_work()
        self.init_agent_position(self)
        self.init_infected_trasition_events(self)
        self.init_activity_trasition_events(self)
        self.event_handler.insert_new_events(self.new_event_pointer,self.new_event_type,self.new_event_agent,self.new_event_delay)
        self.new_event_pointer[0]= 0
        self.transmit_arrays_to_gpu()
        print('scene init done')

    # 初始化各类数组
    def init_arrays_for_gpu(self):
        #subarea_agents初始化为-1
        temp=np.ones(self.building_agents.shape)
        self.building_agents=(temp-self.building_agents).astype(int)
        self.init_building_free_list(self)
        self.step_infected_status_cnt=np.zeros([self.total_steps,self.n_nodes]).astype(int)

    #为每个agent注册work地点(某个building内)
    @staticmethod
    def assign_agent_to_work(self):
        #根据人口密度为agent注册family
        total=0
        sum=np.zeros(self.grid_buildings_total.shape[0]*self.grid_buildings_total.shape[1])
        sum[0]=self.grid_buildings_total[0][0]
        for i in range(1,sum.shape[0]):
            x=i/self.grid_buildings_total.shape[1]
            y=i%self.grid_buildings_total.shape[1]
            sum[i]=sum[i-1]+self.grid_buildings_total[x][y]
        rng_states = create_xoroshiro128p_states(1024 * math.ceil(self.n_agents / 1024),seed=time.time())
        assign_agent_to_family_gpu[math.ceil(self.n_agents/1024),1024](self.agent_family,sum,self.grid_buildings,self.grid_buildings_total,rng_states,self.n_agents)
        assign_agent_to_work_gpu[math.ceil(self.n_agents/1024),1024](self.agent_family,self.agent_commuting_distance,self.agent_work,self.building_location,self.grid_buildings,self.grid_buildings_total,self.grid_size,rng_states,self.n_agents)

    #将频繁读写的array预先装入gpu
    def transmit_arrays_to_gpu(self):
        self.agent_activity_duration=cuda.to_device(self.agent_activity_duration)
        self.new_event_agent=cuda.to_device(self.new_event_agent)
        self.new_event_type = cuda.to_device(self.new_event_type)
        self.new_event_delay = cuda.to_device(self.new_event_delay)
        self.new_event_mutex = cuda.to_device(self.new_event_mutex)
        self.new_event_pointer = cuda.to_device(self.new_event_pointer)
        self.subarea_agents=cuda.to_device(self.subarea_agents)
        self.agent_infected_status=cuda.to_device(self.agent_infected_status)

    @staticmethod
    def init_building_free_list(self):
        N = self.n_buildings
        init_building_free_list_gpu[math.ceil(N/1024),1024](self.building_agents_free_list,self.building_agents_free_list_front,self.building_agents_free_list_rear,N)

    @staticmethod
    def init_agent_position(self):
        N=self.n_agents
        init_agent_position_gpu[math.ceil(N/1024),1024](self.agent_position,self.agent_family,N)

    #为初始感染者注册状态转移事件
    @staticmethod
    def init_infected_trasition_events(self):
        init_infected_trasition_events_gpu[math.ceil(self.n_agents/1024),1024](self.agent_infected_status,self.agent_next_infected_status,self.new_event_mutex,self.new_event_pointer,self.new_event_type,self.new_event_agent,self.new_event_delay,self.n_agents)

    #注册初始事件
    @staticmethod
    def init_activity_trasition_events(self):
        init_activity_trasition_events_gpu[math.ceil(self.n_agents/1024),1024](self.agent_activity_duration,self.new_event_mutex,self.new_event_pointer, self.new_event_type,
                                                             self.new_event_delay, self.new_event_agent,self.n_agents)
        cuda.synchronize()

    #一步迭代
    def update(self):
        self.event_handler.to_numpy()
        # 触发一般事件，生成新的一般事件
        self.event_step(self)
        self.update_infected_status(self)
        self.statis_infected_status()
        #将新生成的一般事件统一注册到event_handler
        self.event_handler.insert_new_events(self.new_event_pointer,self.new_event_type,self.new_event_agent,self.new_event_delay)
        self.new_event_pointer[0] = 0
        self.current_time=self.current_step*self.interval
        if self.current_time>0 and self.current_time%24==0:    #每24小时统计感染的空间分布情况
            self.statis_building_infected_cnt(self)
        print('step',self.current_step,'done')
        print('now infected cnt:',self.agent_infected_status[self.agent_infected_status==1].shape[0])

    @staticmethod
    def event_step(self):
        if self.event_handler.now_event_type.shape[0]==0 or self.event_handler.now_event_type[0]==-1:
            return
        building_mutex=np.zeros([self.n_buildings,1]).astype(int)
        rng_states = create_xoroshiro128p_states(1024 * math.ceil(self.event_handler.now_event_type.shape[0] / 1024), seed=time.time())
        event_step_gpu[math.ceil(self.event_handler.now_event_type.shape[0]/ 1024), 1024](self.event_handler.now_event_type,self.event_handler.now_event_agent,self.new_event_mutex,self.new_event_pointer,self.new_event_type,self.new_event_agent,self.new_event_delay,
                                                                                          self.agent_activity_position,self.agent_activity_distance,self.agent_position,self.agent_activity_total,self.agent_activity_index,self.agent_activity_type,self.agent_family,self.agent_work,self.agent_activity_duration,self.agent_infected_status,self.agent_next_infected_status,
                                                                                          self.trasition_graph_degree,self.trasition_graph_prob,self.trasition_graph_node,self.trasition_graph_delay,
                                                                                          building_mutex,self.build_agents_cnt,self.building_size,self.building_location,self.building_agents,self.building_free_list,self.building_free_list_front,self.building_free_list_rear,self.grid_buildings,self.grid_buildings_total,self.building_near_hospital,
                                                                                          self.hospital_agents_cnt,self.hospital_capacity,self.hospital_mutex,self.hospital_free_list,self.hospital_free_list_front,self.hospital_agents,
                                                                                          self.grid_size,rng_states,self.event_handler.now_event_type.shape[0])
        cuda.synchronize()



    @staticmethod
    def update_infected_status(self):
        N=self.n_buildings
        rng_states = create_xoroshiro128p_states(1024 * math.ceil(N / 1024), seed=time.time())
        temp=np.zeros(self.building_agents.shape).astype(int)
        update_infected_status_gpu[math.ceil(N/1024),1024](self.agent_infected_status,
                                                           self.building_agents,self.building_type,self.building_free_list_front,self.building_free_list_rear,
                                                           self.new_event_mutex,self.new_event_pointer,self.new_event_type,self.new_event_agent,self.new_event_delay,
                                                           rng_states,self.agent_next_infected_status,self.type_contacts,self.infected_p,temp,N)
        cuda.synchronize()

    #各感染状态宏观统计（每个step进行一次）
    def statis_infected_status(self):
        now_step=self.current_step
        for i in range(0,self.step_infected_status_cnt.shape[1]):
            self.step_infected_status_cnt[now_step][i]=(self.agent_infected_status[self.agent_infected_status==i]).shape[0]

    #前端请求宏观统计数据时调用
    def get_statis(self):
        ans={}
        for i in range(0,self.current_step):
            now_data={}
            for k in range(0,len(self.node_name)):
                name=self.node_name[k]
                now_data[name]=self.step_infected_status_cnt[i][k]
            ans[str(i)]=now_data
        return ans


    #感染状态的空间分布统计(每24h进行一次)
    @staticmethod
    def statis_building_infected_cnt(self):
        N=self.n_agents
        self.building_infected_status_cnt=np.zeros([self.n_buildings,self.n_nodes]).astype(int)
        temp_mutex=np.zeros([self.n_buildings,self.n_nodes]).astype(int)
        statis_building_infected_cnt_gpu[math.ceil(N/1024),1024](self.agent_position,self.agent_infected_status,self.building_infected_status_cnt,temp_mutex,N)

    #前端请求heat信息时调用
    @staticmethod
    def get_heats(self):
        heats={}
        for i in range(0,self.n_nodes):
            now_heat={}
            for k in range(0,self.building_infected_status_cnt.shape[0]):
                now_heat[str(k)]={'lon':self.building_location_lonlat[k][1],
                                  'lat':self.building_location_lonlat[k][0],
                                  'cnt':self.building_infected_status_cnt[k][i]}
            heats[self.node_name[i]]=now_heat
        return heats


    def step(self):
        self.current_step+=1
        self.event_handler.step()

    def simulation(self,total_step):
        self.on_simulation = True
        self.total_step=total_step
        while self.current_step < self.total_step:
            if self.on_simulation == False:
                continue
            self.update()
            self.step()
            print('step', self.current_step, 'done')

    def pause(self):
        self.on_simulation=False

    def go_on(self):
        self.on_simulation=True

    def get_nodes_info(self):
        return {'n_nodes':self.n_nodes,'node_name',self.node_name}

