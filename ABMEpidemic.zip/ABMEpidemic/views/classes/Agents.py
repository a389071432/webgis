import random
import math
import numpy as np

class Agents:
    def __init__(self):  #以前端data为输入，目前没想好
        self.data=None
        #基本参数
        self.n_agents=None

    def set_data(self,data):  #接收前端数据
        self.data=data

    def data_to_numpy(self):
        self.n_agents=3000000

        # activity type统一编号如下：
        # 0:H 1:W 2:L 3:S
        self.agent_activity_type = np.zeros([self.n_agents, 8]).astype(int)
        self.agent_activity_duration = np.zeros([self.n_agents, 8])
        self.agent_activity_distance = np.zeros([self.n_agents, 8])
        self.agent_activity_total = np.zeros(self.n_agents).astype(int)
        self.agent_commuting_distance=np.zeros(self.n_agents)
        #self.agent_family=np.zeros(self.n_agents).astype(int)
        #随机生成agent数据
        #活动模式编号
        #0: H-W-H-W-H
        #1: H-W-L-W-H
        #2: H-L-H
        for i in range(0,self.n_agents):
            type=random.randint(0,2)
            if type==0:
                self.agent_activity_total[i] = 5

                self.agent_activity_type[i][0]=0
                self.agent_activity_type[i][1]=1
                self.agent_activity_type[i][2] = 0
                self.agent_activity_type[i][3] = 1
                self.agent_activity_type[i][4] = 0

                self.agent_activity_duration[i][0]=random.normalvariate(7.5, 0.6)
                self.agent_activity_duration[i][1] = random.normalvariate(3, 0.2)
                self.agent_activity_duration[i][2] = random.normalvariate(1.5, 0.2)
                self.agent_activity_duration[i][3] = random.normalvariate(5, 1)
                self.agent_activity_duration[i][4] =24-self.agent_activity_duration[i][0]-self.agent_activity_duration[i][1]-self.agent_activity_duration[i][2]-self.agent_activity_duration[i][3]
            elif type==1:
                self.agent_activity_total[i] = 5

                self.agent_activity_type[i][0]=0
                self.agent_activity_type[i][1]=1
                self.agent_activity_type[i][2] = 2
                self.agent_activity_type[i][3] = 1
                self.agent_activity_type[i][4] = 0

                self.agent_activity_duration[i][0]=random.normalvariate(7.5, 0.6)
                self.agent_activity_duration[i][1] = random.normalvariate(3, 0.2)
                self.agent_activity_duration[i][2] = random.normalvariate(1.5, 0.2)
                self.agent_activity_duration[i][3] = random.normalvariate(5, 1)
                self.agent_activity_duration[i][4] =24-self.agent_activity_duration[i][0]-self.agent_activity_duration[i][1]-self.agent_activity_duration[i][2]-self.agent_activity_duration[i][3]

                self.agent_activity_distance[i][1]=random.randint(500,1500)
                self.agent_activity_distance[i][2]=self.agent_activity_distance[i][1]
            elif type==2:
                self.agent_activity_total[i] = 3

                self.agent_activity_type[i][0]=0
                self.agent_activity_type[i][1]=2
                self.agent_activity_type[i][2] = 0

                self.agent_activity_duration[i][0]=random.normalvariate(7.5, 0.6)
                self.agent_activity_duration[i][1] = random.normalvariate(3, 0.2)
                self.agent_activity_duration[i][4] =12-self.agent_activity_duration[i][0]-self.agent_activity_duration[i][1]-self.agent_activity_duration[i][2]

                self.agent_activity_distance[i][0] = random.randint(1000,3000)
                self.agent_activity_distance[i][1] = self.agent_activity_distance[i][0]

            for i in range(0,math.ceil(0.5*self.n_agents)):
                if self.agent_activity_total[i]==5:
                    self.agent_activity_distance[i][0]=random.randint(1500, 3000)
                    self.agent_activity_distance[i][3] =self.agent_activity_distance[i][0]
                    if self.agent_activity_type[i][2]==0:
                        self.agent_activity_distance[i][0] = random.randint(1500, 3000)
                        self.agent_activity_distance[i][3] = self.agent_activity_distance[i][0]
                    self.agent_commuting_distance[i]=self.agent_activity_distance[0]
                else:
                    self.agent_commuting_distance=-1


            for i in range(math.ceil(0.5*self.n_agents),math.ceil(0.9*self.n_agents)):
                if self.agent_activity_total[i]==5:
                    self.agent_activity_distance[i][0]=random.randint(2500, 4000)
                    self.agent_activity_distance[i][3] =self.agent_activity_distance[i][0]
                    if self.agent_activity_type[i][2]==0:
                        self.agent_activity_distance[i][0] = random.randint(2500, 4000)
                        self.agent_activity_distance[i][3] = self.agent_activity_distance[i][0]
                    self.agent_commuting_distance[i] = self.agent_activity_distance[0]
                else:
                    self.agent_commuting_distance=-1

            for i in range(math.ceil(0.9*self.n_agents),math.ceil(self.n_agents)):
                if self.agent_activity_total[i]==5:
                    self.agent_activity_distance[i][0]=random.randint(4500,8000)
                    self.agent_activity_distance[i][3] =self.agent_activity_distance[i][0]
                    if self.agent_activity_type[i][2]==0:
                        self.agent_activity_distance[i][0] = random.randint(4500,8000)
                        self.agent_activity_distance[i][3] = self.agent_activity_distance[i][0]
                    self.agent_commuting_distance[i] = self.agent_activity_distance[0]
                else:
                    self.agent_commuting_distance=-1





