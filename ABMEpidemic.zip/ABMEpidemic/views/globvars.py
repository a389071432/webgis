import numpy as np
from flask import Blueprint
import time
from views.classes.Agents import Agents
from views.classes.GeoInfo import GeoInfo
from views.classes.InfectedModel import InfectedModel
from views.classes.EventHandler import EventHandler
from views.classes.EpidemicScene import EpidemicSceneGPU

us = Blueprint("globvars",__name__)

agents=None
geoinfo=None
infected_model=None
event_handler=None
scene=None

@us.route('/init_global_variables',methods=['POST'])
def init_global_variables():
    global agents
    global geoinfo
    global infected_model
    global event_handler
    global scene
    agents=Agents()
    infected_model=InfectedModel()
    geoinfo=GeoInfo()
    event_handler=EventHandler()

    return 'globvars init done'
