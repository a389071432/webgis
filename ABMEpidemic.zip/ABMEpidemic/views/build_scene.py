from flask import Blueprint,request
import numpy as np
import json
from views import globvars
from views.classes.EpidemicScene import EpidemicSceneGPU
import time

us = Blueprint("build_scene",__name__)


@us.route('/submit_agent_file',methods=['POST'])  #接收agent文件并保存，待补充
def upload_agent_file():
    print(type(globvars.infected_model))
    #globvars.agents.set_data()
    return 'ok'

@us.route('/upload_url_buildings',methods=['POST'])  #接收url并保存，待补充
def upload_url_building():
    #globvars.geoinfo.set_url_buildings(url_buildings)
    return 'ok'

@us.route('/upload_url_landuse',methods=['POST'])  #接收url并保存，待补充
def upload_url_landuse():
    #globvars.geoinfo.set_url_landuse(url_landuse)
    return 'ok'

@us.route('/upload_population_file',methods=['POST'])  #接收url并保存，待补充
def upload_url_population():
    #globvars.geoinfo.set_url_population(url_population)
    return 'ok'

@us.route('/upload_infected_model',methods=['POST'])  #接收infected_model，待补充
def upload_infected_model():
    data = request.get_json()
    trasition_form=data['form']
    globvars.infected_model.set_model(trasition_form)
    return 'ok'

@us.route('/upload_infected_params',methods=['POST'])  #接收感染参数
def upload_infected_params():
    data=request.get_json()
    p=data['p']
    land_contacts=data['land_contacts']
    node_infectivity=data['node_infectivity']
    node_quarantine=data['node_quarantine']
    globvars.infected_model.set_params(land_contacts, p,node_infectivity,node_quarantine)
    return 'ok'

@us.route('/construct_scene',methods=['GET'])  #根据已上传数据构建仿真场景
def construct_scene():
    #globvars.geoinfo.fetch_data()  暂时不管
    #将各类数据组织为numpy
    globvars.agents.data_to_numpy()
    globvars.geoinfo.data_to_numpy()
    globvars.infected_model.data_to_numpy()
    #构建scene
    globvars.scene=EpidemicSceneGPU(globvars.event_handler, globvars.agents, globvars.geoinfo,globvars.infected_model, interval=1,duration=168)
    print('construct scene done')
    return 'ok'

