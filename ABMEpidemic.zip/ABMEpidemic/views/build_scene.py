from flask import Blueprint,request
import numpy as np
import json
from views import globvars
from views.classes.EpidemicScene import EpidemicSceneGPU
import time

us = Blueprint("build_scene",__name__)

@us.route('/submit_agent_file',methods=['POST'])  #接收agent文件并保存，待补充
def upload_agent_file():
    #globvars.agents.set_data()
    return 'ok'

@us.route('/upload_building',methods=['POST'])  #接收url并保存，待补充
def upload_url_building():
    #globvars.geoinfo.set_url_buildings(url_buildings)
    return 'ok'

@us.route('/upload_url_landuse',methods=['POST'])  #接收url并保存，待补充
def upload_url_landuse():
    #globvars.geoinfo.set_url_landuse(url_landuse)
    return 'ok'

@us.route('/upload_population_file',methods=['POST'])  #接收url并保存，待补充
def upload_url_population():
    #globvars.geoinfo.set_url_population(url_population)
    return 'ok'

@us.route('/upload_infected_model',methods=['POST'])  #接收infected_model，待补充
def upload_infected_model():
    #globvars.infected_model.set_data(trasition_form,land_contacts,p)
    return 'ok'

@us.route('/construct_scene',methods=['GET'])  #根据已上传数据构建仿真场景
def construct_scene():
    globvars.geoinfo.fetch_data()
    #将各类数据组织为numpy
    globvars.agents.data_to_numpy()
    globvars.geoinfo.data_to_numpy()
    globvars.infected_model.data_to_numpy()
    #构建scene
    globvars.scene=EpidemicSceneGPU(globvars.event_handler, globvars.agents, globvars.geoinfo,globvars.infected_model, interval=1,duration=168)
    return 'ok'

