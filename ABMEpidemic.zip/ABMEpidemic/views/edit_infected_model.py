from flask import Blueprint,request
import numpy as np
import json
from views import globvars

us = Blueprint("edit_infected_model",__name__)


@us.route("/modify_infected_model",methods=['POST'])
def modify_infected_model():
    data = request.get_json()
    trasition_form = data['form']
    globvars.infected_model.set_model(trasition_form)
    globvars.infected_model.modify_infected_model()
    globvars.scene.reset_infected_model(globvars.infected_model)
    return 'ok'
