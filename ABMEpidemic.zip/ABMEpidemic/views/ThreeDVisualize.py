from flask import Blueprint,request
import numpy as np
import json
from views import globvars

us = Blueprint("ThreeDVisualize",__name__)

@us.route("/get_heats_3d",methods=['GET'])
def get_heats_3d():
    heats=globvars.scene.get_heats(globvars.scene)
    ans0={}
    ans1={}
    for key0 in heats.keys():
        heat=heats[key0]
        now_heat = []
        now_grid= []
        for key1 in heat.keys():
            lon=heat[key1]['lon']
            lat=heat[key1]['lat']
            cnt=heat[key1]['cnt']
            now_grid.append({'CNT': cnt, 'COORDINATES': [lon, lat]})
            for i in range(0,heat[key1]['cnt']):
                now_dict={}
                now_dict['lng']=lon
                now_dict['lat']=lat
                now_heat.append(now_dict)
        ans0[key0]=now_heat
        ans1[key0]=now_grid
        #补齐为零的数据
        for name in globvars.scene.node_name:
            if name not in heats.keys():
                ans0[name] = []
                ans1[name] = []
    return json.dumps({'heat_data':ans0,'grid_data':ans1})

@us.route("/get_trip_data",methods=['GET'])
def get_trip_data():
    trips=globvars.scene.get_trips()
    return json.dumps(trips)