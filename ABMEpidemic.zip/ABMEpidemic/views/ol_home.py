from flask import Blueprint,request
import numpy as np
import json
from views import globvars

us = Blueprint("ol_home",__name__)

on_simulation=False

@us.route("/start_simulation",methods=['GET'])
def start_simulation():
    global on_simulation
    if on_simulation==True:
        return 'running...'
    on_simulation=True
    total_step=request.values['total_step']
    total_step=int(total_step)
    globvars.scene.simulation(total_step)
    return 'ok'

@us.route("/pause_simulation",methods=['POST'])
def pause_simulation():
    global on_simulation
    on_simulation=False
    globvars.scene.pause()
    return 'ok'

@us.route("/continue_simulation",methods=['POST'])
def continue_simulation():
    global on_simulation
    on_simulation=True
    globvars.scene.go_on()
    return 'ok'

@us.route("/get_heat",methods=['GET'])
def get_heat():
    heats=globvars.scene.get_heats(globvars.scene)
    #print('heats:',heats['I'],heats['R'])
    return json.dumps(heats)

@us.route("/get_nodes_info",methods=['GET'])
def get_ndoes_info():
    return json.dumps(globvars.scene.get_nodes_info())