from flask import Blueprint,request
import numpy as np
import json
from views import globvars

us = Blueprint("ol_home",__name__)

on_simulation=False

@us.route("/start_simulation",methods=['GET'])
def start_simulation():
    global on_simulation
    if on_simulation==True:
        return 'running...'
    on_simulation=True
    total_step=request.values['total_step']
    total_step=int(total_step)
    print('total_step:',type(total_step))
    globvars.scene.simulation(total_step)
    return 'ok'

@us.route("/pause_simulation",methods=['POST'])
def pause_simulation():
    global on_simulation
    on_simulation=False
    globvars.scene.pause()
    return 'ok'