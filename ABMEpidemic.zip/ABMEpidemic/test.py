def read_txt(inputpath, outputpath):
    with open(outputpath, 'w', encoding='utf-8') as file:
        with open(inputpath, 'r', encoding='utf-8') as infile:
            data2 = []
            for line in infile:
                data_line = line.strip("\n").split()  # 去除首尾换行符，并按空格划分
                s=data_line[0]+'=='+data_line[1]
                data2.append(s)
            # 写入方法
            for line in data2:
                data = line+'\n'  # 用\t隔开
                file.write(data)


if __name__ == "__main__":
    input_path = 'E:/temp.txt'
    output_path = 'require.txt'
    read_txt(input_path, output_path)
