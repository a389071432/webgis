import GPUtil
import numpy as np
from numba import cuda,guvectorize
from numba.cuda.random import create_xoroshiro128p_states, xoroshiro128p_uniform_float32,create_xoroshiro128p_states, xoroshiro128p_uniform_float64
import time
import math
# while True:
#     gpus=GPUtil.getGPUs()
#     # for gpu in gpus:
#     #     print(gpu.memoryUsed)
#     print(gpus[0].memoryUsed)

@cuda.jit
def test(a,rng_states):
    idx = cuda.threadIdx.x + cuda.blockIdx.x * cuda.blockDim.x
    p = a[0]*xoroshiro128p_uniform_float32(rng_states, idx)

rng_states = create_xoroshiro128p_states(1024 * math.ceil(2048 / 1024),seed=time.time())
a=np.zeros(1)
a[0]=100
test[2,1024](a,rng_states)