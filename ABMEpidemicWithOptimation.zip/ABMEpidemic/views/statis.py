from flask import Blueprint,request
import numpy as np
import json
from views import globvars

us = Blueprint("statis",__name__)

@us.route("/get_statis",methods=['GET'])
def get_statis():
    statis= globvars.scene.get_statis()
    return json.dumps(statis)