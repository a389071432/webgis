from Agent import HumanAgent,EstateAgent
from CustomStructs import Contact

class HumanAgentForEpidemic(HumanAgent):
    def __init__(self):
        super().__init__()
        self.id=None
        self.family=None
        self.work=None
        self.commuting_distance=None  #通勤距离
        self.traveling_way=None        #出行方式
        self.activity_type=[]
        self.activity_duration=[]           #每个活动时长，目前简单设定为(R,T,W,L,W,T,R)
        self.activity_center_x=[]         #每个活动的活动中心
        self.activity_center_y=[]
        self.activity_range=[]          #每个活动的随机活动范围
        self.current_activity_index=None
        self.infected_status=None
        self.initial_points=None
        self.regular_contacts={}
        self.daily_random_cotacts={}     #每日随机接触列表，字典形式{agent,接触时长}

class EstateAgentForEpidemic(EstateAgent):
    def __init__(self,size):
        super().__init__(size)
        self.members=[]
