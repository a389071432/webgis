import random
from numba import cuda
from numba.cuda.random import create_xoroshiro128p_states, xoroshiro128p_uniform_float32
from numba.experimental import jitclass
import time
import numpy as np
import math
from numba.cuda.random import create_xoroshiro128p_states, xoroshiro128p_uniform_float32
import matplotlib.pyplot as plt

@cuda.jit
def test(rng_states,a_mutex,a,N):
    idx = cuda.threadIdx.x + cuda.blockIdx.x * cuda.blockDim.x
    if idx >= N:
        return
    id_in_warp = idx % cuda.warpsize
    if id_in_warp != 0:
        return
    for i in range(0, cuda.warpsize):
        now_id = idx + i
        if now_id < N:
            x = xoroshiro128p_uniform_float32(rng_states, idx)*100
            y = xoroshiro128p_uniform_float32(rng_states, idx)*100
            x = int(x)
            y = int(y)
            while cuda.atomic.compare_and_swap(a_mutex[x][y], 0, 1) == 1:
                continue
            a[x][y] += 1
            cuda.atomic.exch(a_mutex[x][y], 0, 0)



a=np.zeros([100,100]).astype(int)
a_mutex=np.zeros([100,100,1]).astype(int)
N=500000
rng_states = create_xoroshiro128p_states(1024 * math.ceil(N / 1024), seed=time.time())
test[math.ceil(N/1024),1024](rng_states,a_mutex,a,N)
cuda.synchronize()
plt.imshow(a, cmap=plt.cm.hot, vmin=0, vmax=a.max()*1.5)
plt.colorbar()
plt.show()
print(a)



