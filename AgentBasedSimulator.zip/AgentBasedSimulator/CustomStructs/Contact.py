class Contact:
    def __init__(self,duration,agent):
        self.duration=duration
        self.agent=agent