from CustomAgent.AgentForEpidemic import HumanAgentForEpidemic,EstateAgentForEpidemic
import random
import time
from Traffic.Stop import Stop
from DataStructure.Graph import Egde,Graph

#根据统计数据生成agents
#参数：（统计数据）
def generate_human_agents(statis_data):
    agents=[]
    families=[]
    works=[]
    # 目前随意生成
    total=0

    for i in range(0,500000):
        size=random.randint(2,3)
        total+=size
        family=EstateAgentForEpidemic(size)
        family.id=i
        families.append(family)
    print('total:',total)
    for i in range(0, total):
        agent = HumanAgentForEpidemic()
        agent.id=i
        agent.infected_status=0
        agent.initial_points=7
        agent.commuting_distancce = random.randint(1000, 7000)
        agent.activity_duration.append(random.normalvariate(7.5, 0.6))   #7.5
        agent.activity_duration.append(-1)
        agent.activity_duration.append(random.normalvariate(3, 0.2))
        agent.activity_duration.append(random.normalvariate(1.5, 0.2))
        agent.activity_duration.append(random.normalvariate(5, 1))
        agent.activity_duration.append(-1)
        agent.activity_duration.append(12-agent.activity_duration[0])
        if i>=0 and i<1:
            agent.infected_status=1
            agent.initial_points=0
        # activity_type:
        #0-R
        #1-T
        #2-W
        #3-L
        agent.activity_type.append(0)
        agent.activity_type.append(1)
        agent.activity_type.append(2)
        agent.activity_type.append(3)
        agent.activity_type.append(2)
        agent.activity_type.append(1)
        agent.activity_type.append(0)

        agent.activity_range.append(random.randint(6, 120)/10)  #agent的position,activity_center,activity_range都以subgrid为单位
        agent.activity_range.append(-1)
        agent.activity_range.append(random.randint(3, 120)/10)
        agent.activity_range.append(random.randint(3, 30))
        agent.activity_range.append(random.randint(3, 120)/10)
        agent.activity_range.append(-1)
        agent.activity_range.append(random.randint(6, 120)/10)

        agent.activity_range=[0]*7

        agent.current_activity_index = 0
        agents.append(agent)

    work_total=0
    for i in range(0,60000):
        size=random.randint(20,200)
        work=EstateAgentForEpidemic(size)
        work.id=i
        works.append(work)
        work_total+=size
    print('work total=',work_total)

    print('generate done')
    return agents,families,works




#获取公共交通站点，目前每个grid放置一个
def get_traffic_data(traffic_data):
    stops=[]
    lines=[]
    for i in range(0,100):
        for j in range(0,100):
            dx=random.randint(0,9)
            dy=random.randint(0,9)
            stop=Stop(i*10+dx,j*10+dy)
            stops.append(stop)
    return stops,lines

def get_trasition_graph():
    g_prob=Graph(n_nodes=3,is_dir=True)
    g_delay=Graph(n_nodes=3,is_dir=True)
    g_prob.add_edge(0,1,1)
    g_prob.add_edge(1,2,1)
    g_delay.add_edge(0,1,-1)
    g_delay.add_edge(1,2,4*24)
    g={}
    g['prob']=g_prob
    g['delay']=g_delay
    return g