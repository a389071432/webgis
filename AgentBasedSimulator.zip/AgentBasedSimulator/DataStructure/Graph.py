import numpy
class Egde:
    def __init__(self,x,y,w):
        self.x=x
        self.y=y
        self.w=w

class Graph:
    def __init__(self,n_nodes,is_dir):
        self.n_nodes=n_nodes
        self.al=[]
        self.is_dir=dir
        for i in range(0,n_nodes):
            self.al.append([])

    def add_edge(self,x,y,w):
        edge=Egde(x,y,w)
        self.al[edge.x].append(edge)
        if self.is_dir==False:
            self.al[edge.y].append(edge)
