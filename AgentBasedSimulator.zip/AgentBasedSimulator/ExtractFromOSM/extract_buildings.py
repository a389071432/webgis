from xml.dom.minidom import parse
import xml.dom.minidom
import numpy as np
import matplotlib.pyplot as plt

DOMTree = xml.dom.minidom.parse("F:/map_beijing_part.osm")
collection = DOMTree.documentElement

dict_ref_index={}
nodes=collection.getElementsByTagName("node")
position=np.zeros([len(nodes),2])  #0-lat 1-lon
pointer=0
for node in nodes:
    ref=float(node.getAttribute('id'))
    lat=float(node.getAttribute('lat'))
    lon=float(node.getAttribute('lon'))
    dict_ref_index[ref]=pointer
    position[pointer][0]=lat
    position[pointer][1]=lon
    pointer+=1

ways=collection.getElementsByTagName("way")
ways_with_tag=[]
polygons=np.zeros([100000,50]).astype(float)
polygon_pointer=0
polygon_size=np.zeros(1000000).astype(int)
for way in ways:
    tags=way.getElementsByTagName('tag')
    if len(tags)>0:
        has_building=False
        for tag in tags:
            if tag.getAttribute('k')=='building'or tag.getAttribute('k')=='amenity' or tag.getAttribute('k')=='landuse':
                has_building=True
                break
        if has_building:
            nds=way.getElementsByTagName('nd')
            for i,nd in enumerate(nds):
                polygons[polygon_pointer][i]=float(nd.getAttribute('ref'))
            polygon_size[polygon_pointer]=len(nds)
            polygon_pointer+=1

plt.figure()
for i in range(0,polygon_pointer):
    coords=np.zeros([polygon_size[i],2])
    for k in range(0,coords.shape[0]):
        index=dict_ref_index[polygons[i][k]]
        coords[k][0]=position[index][0]
        coords[k][1]=position[index][1]
    xs, ys = zip(*coords)
    plt.plot(xs, ys)

print(polygon_pointer)
plt.show()





