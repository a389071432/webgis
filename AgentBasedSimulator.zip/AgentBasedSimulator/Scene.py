from abc import abstractmethod
from EventHandler import EventHandler

class Scene:
    def __init__(self,event_handler,agents,geoinfo,interval=1,duration=168):
        self.agents=agents
        self.geoinfo=geoinfo
        self.event_handler=event_handler
        self.interval=1
        self.duration=duration
        self.steps=self.duration/self.interval
        self.current_step=0

    @abstractmethod
    def step(self):
        pass


