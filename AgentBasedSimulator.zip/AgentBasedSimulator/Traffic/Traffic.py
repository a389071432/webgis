import numpy as np
from Traffic.Stop import Stop
import math
from numba import cuda
from numba.cuda.random import create_xoroshiro128p_states, xoroshiro128p_uniform_float32

@cuda.jit
def assign_agent_to_stop_gpu(agents,agent_position,grid_stops,grid_stops_total,stop_position,stop_agents,stop_agents_front,stop_agents_rear,stop_agents_mutex,N,stop_cnts):
    idx = cuda.threadIdx.x + cuda.blockIdx.x * cuda.blockDim.x
    if idx >= N:
        return
    id_in_warp = idx % cuda.warpsize
    if id_in_warp != 0:
        return
    for i in range(0, cuda.warpsize):
        now_id = idx + i
        if now_id < N:
            # 先为agent找到最近的stop
            x = agent_position[now_id][0]
            y = agent_position[now_id][1]
            gx = math.floor(x/10)
            gy = math.floor(y/10)
            gx=int(gx)
            gy=int(gy)
            if gx>=grid_stops.shape[0]:
                gx=grid_stops.shape[0]-1
            if gy>=grid_stops.shape[1]:
                gy=grid_stops.shape[1]-1
            near_stop =-1
            min_dis =1000000
            for k in range(0, grid_stops_total[gx][gy]):
                stop = grid_stops[gx][gy][k]
                dis = math.sqrt((x - stop_position[stop][0]) * (x - stop_position[stop][0]) + (y - stop_position[stop][1]) * (y - stop_position[stop][1]))
                if dis < min_dis:
                    min_dis = dis
                    near_stop = stop
            if near_stop==-1:
                continue
            # 将agent放入车站，注意互斥访问stop_agents
            while cuda.atomic.compare_and_swap(stop_agents_mutex[near_stop:], 0, 1) == 1:
                continue
            rear=stop_agents_rear[near_stop]
            stop_agents[near_stop][rear] = agents[now_id]
            stop_agents_rear[near_stop] += 1
            stop_agents_rear[near_stop] %= stop_agents.shape[1]
            cuda.atomic.exch(stop_agents_mutex, near_stop, 0)
            stop_cnts[near_stop]+=1


@cuda.jit
def assign_agent_to_terminal_stop_gpu(agents,agent_target,grid_stops,grid_stops_total,stop_position,agent_terminal,N):
    idx = cuda.threadIdx.x + cuda.blockIdx.x * cuda.blockDim.x
    if idx >= N:
        return
    # 先为agent找到最近的stop
    x = agent_target[idx][0]
    y = agent_target[idx][1]
    gx = math.floor(x / 10)
    gy = math.floor(y / 10)
    gx=int(gx)
    gy=int(gy)
    near_stop = -1
    min_dis = 10000000
    for k in range(0, grid_stops_total[gx][gy]):
        stop = grid_stops[gx][gy][k]
        dis = math.sqrt((x - stop_position[stop][0]) * (x - stop_position[stop][0]) + (y - stop_position[stop][1]) * (y - stop_position[stop][1]))
        if dis < min_dis:
            min_dis = dis
            near_stop = stop
    agent_terminal[agents[idx]] = near_stop


@cuda.jit
def simple_transport_gpu(agent_terminal,stop_position,stop_agents,stop_agents_front,stop_agents_rear,
                             new_event_mutex,new_event_pointer, new_event_type,
                             new_event_delay, new_event_agent,N,stop_cnts):
    #目前简单实现，只是把stop内的agent运输到指定位置
    idx = cuda.threadIdx.x + cuda.blockIdx.x * cuda.blockDim.x
    if idx >= N:
        return
    id_in_warp = idx % cuda.warpsize
    if id_in_warp != 0:
        return
    for i in range(0, cuda.warpsize):
        now_id = idx + i
        if now_id>=N:
            continue
        while stop_agents_front[now_id]!=stop_agents_rear[now_id]:
            agent=stop_agents[now_id][stop_agents_front[now_id]]
            stop_agents_front[now_id]+=1
            stop_agents_front[now_id]%=stop_agents.shape[1]
            while cuda.atomic.compare_and_swap(new_event_mutex, 0, 1) == 1:
                continue
            speed=500
            new_event_type[new_event_pointer[0]] =0       #0-agent_arrive
            new_event_agent[new_event_pointer[0]] = agent
            delay=math.sqrt((stop_position[now_id][0]-stop_position[agent_terminal[agent]][0])*(stop_position[now_id][0]-stop_position[agent_terminal[agent]][0])+(stop_position[now_id][1]-stop_position[agent_terminal[agent]][1])*(stop_position[now_id][1]-stop_position[agent_terminal[agent]][1]))/speed
            new_event_delay[new_event_pointer[0]]=delay
            new_event_pointer[0] += 1
            cuda.atomic.exch(new_event_mutex, 0, 0)
            #print(agent)
            if agent==0:
                print('agent0 will arrive after',delay)


@cuda.jit
def event_step_gpu(now_event_type, now_event_agent,is_agent_arrive,N):
    #目前简单实现
    idx = cuda.threadIdx.x + cuda.blockIdx.x * cuda.blockDim.x
    if idx >= N:
        return
    is_agent_arrive[now_event_agent[idx]]=1

class Traffic:
    def __init__(self,event_handler,max_agents,geoinfo,roadnet,stops,lines):
        self.event_handler=event_handler
        self.roadnet=roadnet
        self.stops=stops
        self.lines=lines
        self.geoinfo=geoinfo
        self.max_agents=max_agents
        self.current_step=0
        #arrays for gpu
        self.stop_position=np.zeros([len(self.stops),2])   #stop的位置也以subgrid为单位
        self.grid_stops=np.zeros([self.geoinfo.n_grids,self.geoinfo.n_grids,10]).astype(int)   #记录每个网格有哪些车站
        self.grid_stops_total=np.zeros([self.geoinfo.n_grids,self.geoinfo.n_grids]).astype(int)
        self.stop_agents=np.zeros([len(self.stops),500]).astype(int)
        self.stop_agents_front=np.zeros(len(self.stops)).astype(int)
        self.stop_agents_rear= np.zeros(len(self.stops)).astype(int)
        self.agent_terminal=np.zeros(max_agents).astype(int)    #存储agent的当前终点，此处的agent编号与Scene中的一致

        self.new_event_mutex = np.zeros(1).astype(int)
        self.new_event_pointer = np.zeros(1).astype(int)
        self.new_event_type = np.zeros(10000000).astype(int)
        self.new_event_delay = np.zeros(10000000)
        self.new_event_agent = np.zeros(10000000).astype(int)

        self.stop_cnts=np.zeros(len(self.stops)).astype(int) #debug用

        #生成路线
        self.paths=[]
        for i in range(0,len(self.stops)):
            self.paths.append([])
        self.generate_paths()
        self.init_arrays_for_gpu()
        self.transmit_arrays_to_gpu()

    def init_arrays_for_gpu(self):
        for i,stop in enumerate(self.stops):
            self.stop_position[i][0]=stop.position_x
            self.stop_position[i][1]=stop.position_y

        for i in range(0,len(self.stops)):
            stop=self.stops[i]
            x=math.floor(stop.position_x/self.geoinfo.n_sub)
            y=math.floor(stop.position_y/self.geoinfo.n_sub)
            self.grid_stops[x][y][self.grid_stops_total[x][y]]=i
            self.grid_stops_total[x][y]+=1


    def transmit_arrays_to_gpu(self):
        self.grid_stops_total=cuda.to_device(self.grid_stops_total)
        self.grid_stops=cuda.to_device(self.grid_stops)
        #self.stop_position=cuda.to_device(self.stop_position)
        self.stop_agents=cuda.to_device(self.stop_agents)
        self.stop_agents_front=cuda.to_device(self.stop_agents_front)
        self.stop_agents_rear=cuda.to_device(self.stop_agents_rear)
        self.new_event_agent = cuda.to_device(self.new_event_agent)
        self.new_event_type = cuda.to_device(self.new_event_type)
        self.new_event_delay = cuda.to_device(self.new_event_delay)
        self.new_event_mutex = cuda.to_device(self.new_event_mutex)
        self.new_event_pointer = cuda.to_device(self.new_event_pointer)
        #self.agent_terminal=cuda.to_device(self.agent_terminal)

    #为每对站点生成一条路线（BFS）
    def generate_paths(self):
        pass

    @staticmethod
    def transport_agents(self,agents,agent_position,agent_target):  #运输agent，注意此处的agents是全部agent中的一小部分，索引与Scene不一致
        #先确定agent的起始stop（同时将agent放入stop）
        stop_agents_mutex=np.zeros(len(self.stops)).astype(int)
        agents=np.asarray(agents).astype(int)
        assign_agent_to_stop_gpu[math.ceil(agents.shape[0]/1024),1024](agents,agent_position,self.grid_stops,self.grid_stops_total,self.stop_position,self.stop_agents,self.stop_agents_front,self.stop_agents_rear,stop_agents_mutex,agents.shape[0],self.stop_cnts)
        cuda.synchronize()
        #然后确定agent的终点stop
        assign_agent_to_terminal_stop_gpu[math.ceil(agents.shape[0]/1024),1024](agents,agent_target,self.grid_stops,self.grid_stops_total,self.stop_position,self.agent_terminal,agents.shape[0])
        cuda.synchronize()
        #根据agent的起始和终止stop,为agent确定最短乘车路线(各地之间的路线是预先生成的，此时只需查表)
        #待实现

    def update(self):
        self.event_handler.to_numpy()
        is_agent_arrive=self.event_step(self,self.current_step)
        self.event_handler.insert_new_events(self.new_event_pointer,self.new_event_type,self.new_event_agent,self.new_event_delay)
        self.new_event_pointer[0] = 0
        if is_agent_arrive[0]==-1:
            arrive_agents=np.zeros(1)
            arrive_agents[0]=-1
            return arrive_agents,None
        temp=np.linspace(0,is_agent_arrive.shape[0]-1,is_agent_arrive.shape[0]).astype(int)
        arrive_agents = temp[is_agent_arrive == 1]
        agents_now_stops = self.agent_terminal[arrive_agents]
        agents_now_position = self.stop_position[agents_now_stops]
        return arrive_agents,agents_now_position

    @staticmethod
    def event_step(self,t):
        #目前简单实现
        simple_transport_gpu[math.ceil(len(self.stops)/1024),1024](self.agent_terminal,self.stop_position,self.stop_agents,self.stop_agents_front,self.stop_agents_rear,
                             self.new_event_mutex,self.new_event_pointer, self.new_event_type,
                             self.new_event_delay, self.new_event_agent,len(self.stops),self.stop_cnts)
        cuda.synchronize()
        self.event_handler.insert_new_events(self.new_event_pointer,self.new_event_type,self.new_event_agent,self.new_event_delay)
        self.new_event_pointer[0]=0
        is_agent_arrive=np.zeros(self.max_agents).astype(int)  #每个agent是否到达，此处agent索引与Scene一致
        if self.event_handler.now_event_type[0]==-1:
             is_agent_arrive=np.zeros(1)
             is_agent_arrive[0]=-1
             return is_agent_arrive

        event_step_gpu[math.ceil(self.event_handler.now_event_type.shape[0]/1024), 1024](self.event_handler.now_event_type, self.event_handler.now_event_agent,is_agent_arrive,self.event_handler.now_event_type.shape[0])
        cuda.synchronize()
        return is_agent_arrive

    def step(self):
        self.current_step+=1
        self.event_handler.step()
        #print('stops max assigned:',self.stop_cnts.max())
        self.stop_cnts=np.zeros(len(self.stops)).astype(int)