class Vehicle:
    def __init__(self,id,speed,capacity):
        self.id=id
        self.speed=speed
        self.capacity=capacity
        self.left_capacity=capacity
        self.current_stop=0
        self.passengers=[]

    #乘客下车
    def remove_passengers(self):

    #从站点接收乘客
    #参数：（新乘客列表）
    def pick_up_passengers(self,new_passengers):

