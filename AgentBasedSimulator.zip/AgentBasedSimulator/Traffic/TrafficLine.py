import Vehicle

class TrafficLine:
    #初始化
    #参数：（公交类型，路经站点，车辆总数，发车间隔）
    def __init__(self,type,stops,n_vehicle,interval):
        self.type=type
        self.stops=stops
        self.n_vehicle=n_vehicle
        self.interval=interval
        self.vehicles=[]
        for i in range(0,n_vehicle):
            self.vehicles.append(Vehicle(i,100,50))

