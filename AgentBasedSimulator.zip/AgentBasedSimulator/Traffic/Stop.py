class Stop:
    def __init__(self,x,y):
        self.position_x=x
        self.position_y=y
        self.waiting_passengers=[]  #候车agent列表

