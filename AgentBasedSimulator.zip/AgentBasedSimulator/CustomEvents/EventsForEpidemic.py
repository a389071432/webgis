from Event import Event

class EventForEpidemic(Event):
    def __init__(self,type,t,agent_id):
        super().__init__(type,t)
        self.agent_id=agent_id
