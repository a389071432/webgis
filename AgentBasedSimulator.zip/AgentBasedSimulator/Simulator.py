import time


class Simulator:
    def __init__(self,scene,duration=168,interval=1):
        self.scene=scene
        self.duration=duration
        self.interval=interval
        self.steps=int(duration/interval)
        self.current_time=0

    def start(self):
        for i in range(0,self.steps):
            self.step(i)
        self.scene.show_infected_status_cnt()

    def step(self,current_step):
        self.scene.update()
        if (current_step-22)%24==0:
            self.scene.statis_region_infected_cnt(self.scene)
        self.scene.step() #更新时钟






