import numpy as np
import random

class GeoInfo:
    def __init__(self,city_code,info,area_size,n_grids=100,n_sub=10):
        self.info=info
        self.city_code=city_code
        self.shapes=[]
        self.records=[]
        self.land_types_level1 = None
        self.land_types_level2 = None
        self.extract_infos()
        self.area_size=area_size  #区域实际大小（公里）
        self.n_grids=n_grids   #所划分的大网格数
        self.n_sub=n_sub       #每个大网格的细分数
        self.land_use=np.zeros([n_grids,n_grids])  #用地类型，住宅 办公 公共
        self.get_geoinfo()

    def extract_infos(self):
        shapes=self.info['shapes']
        records=self.info['records']
        for i in range(0,len(shapes)):
            if records[i][3]==self.city_code:
                self.shapes.append(shapes[i])
                self.records.append(records[i])
        self.land_types_level1 = []
        self.land_types_level2 = []
        for record in self.records:
            self.land_types_level1.append(record[5])
            self.land_types_level2.append(record[6])
        print('extract done')

    #从OSM获取地理信息 （待完成，目前随意）
    def get_geoinfo(self):
        for i in range(0,self.n_grids):
            for j in range(0,self.n_grids):
                self.land_use[i][j]=random.randint(0,1)

    def plot_landuse(self,plt):
        MIN_X=0X3F3F3F
        MAX_X=-1
        MIN_Y=0X3F3F3F
        MAX_Y=-1
        for i, shape in enumerate(self.shapes):
            xs, ys = zip(*shape.points)
            xs=np.asarray(xs)
            ys=np.asarray(ys)
            min_x=xs.min()
            max_x=xs.max()
            min_y=ys.min()
            max_y=ys.max()
            MIN_X=min(MIN_X,min_x)
            MAX_X=max(MAX_X,max_x)
            MIN_Y=min(MIN_Y,min_y)
            MAX_Y=max(MAX_Y,max_y)
        du_x=MAX_X-MIN_X
        du_y=MAX_Y-MIN_Y
        for i, shape in enumerate(self.shapes):
            xs, ys = zip(*shape.points)
            xs=np.asarray(xs)
            ys=np.asarray(ys)
            for i in range(0,len(xs)):
                xs[i]=1000*(xs[i]-MIN_X)/du_x
                ys[i]=1000*(ys[i]-MIN_Y)/du_y
            plt.plot(xs,ys,linewidth=0.1)
        plt.show()



