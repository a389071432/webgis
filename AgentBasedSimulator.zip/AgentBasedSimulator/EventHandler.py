import numpy as np
from numba import cuda
import math
from CustomEvents.EventsForEpidemic import EventForEpidemic

@cuda.jit
def count_new_events(cnt_delay_mutex,cnt_delay,new_event_type,new_event_agent,new_event_delay,N):
    idx = cuda.threadIdx.x + cuda.blockIdx.x * cuda.blockDim.x
    if idx >= N:
        return
    id_in_warp = idx % cuda.warpsize
    if id_in_warp != 0:
        return
    for i in range(0, cuda.warpsize):
        now_id = idx + i
        if now_id < N:
            while cuda.atomic.compare_and_swap(cnt_delay_mutex[new_event_delay[now_id]], 0, 1) == 1:
                continue
            cnt_delay[new_event_delay[now_id]]+=1
            cuda.atomic.exch(cnt_delay_mutex, new_event_delay[now_id], 0)


class EventHandler:
    def __init__(self):
        self.event_dict_type={}   #每个时刻存放的都是numpy
        self.event_dict_agent={}
        self.event_handlers={}
        self.now_event_type=np.zeros(1).astype(int)
        self.now_event_type[0]=-1
        self.now_event_agent=np.zeros(1).astype(int)
        self.current_step=0

    def step(self):
        self.current_step+=1

    def to_numpy(self):
        t=self.current_step
        self.now_event_type=np.zeros(1).astype(int)
        if self.event_dict_type.__contains__(t)==False:
            self.now_event_type[0]=-1
            return
        self.now_event_type = self.event_dict_type[t].astype(int)
        self.now_event_agent = self.event_dict_agent[t].astype(int)

    def register_event(self,event_type,handler):
        self.event_handlers[event_type]=handler

    #插入新生成的事件们
    def insert_new_events(self,new_event_pointer,new_event_type_gpu,new_event_agent_gpu,new_event_delay_gpu):
        if new_event_pointer[0]==0:
            return
        # new_event_delay=math.ceil(new_event_delay)
        # cnt_delay=np.zeros(200).astype(int)   #辅助数组，记录不同时延事件的数量
        # cnt_delay_mutex = np.zeros(cnt_delay.shape[0]).astype(int)
        # count_new_events[math.ceil(new_event_pointer[0]/1024),1024](cnt_delay_mutex,cnt_delay,new_event_type,new_event_agent,new_event_delay,new_event_pointer[0])
        # cuda.synchronize()
        # start_pos=np.zeros([200])   #辅助数组，记录cnt_delay的前缀和，用于标识各delay事件在有序数组中的初始插入位置
        # for i in range(1,200):
        #     start_pos[i]=start_pos[i-1]+cnt_delay[i-1]
        # ordered_new_event_type=np.zeros(new_event_type.shape)    #待填充的有序数组
        # ordered_new_event_agent=np.zeros(new_event_agent.shape)
        # ordered_new_event_delay=np.zeros(new_event_delay.shape)
        # #填充有序数组（按delay排序后的新事件）
        # fill_orderd_new_events[math.ceil(new_event_pointer[0]/1024),1024](start_pos,new_event_type,new_event_agent,new_event_delay,ordered_new_event_type,ordered_new_event_agent,ordered_new_event_delay,new_event_pointer[0])
        # cuda.synchronize()

        new_event_delay=new_event_delay_gpu.copy_to_host()
        new_event_type=new_event_type_gpu.copy_to_host()
        new_event_agent=new_event_agent_gpu.copy_to_host()

        new_event_delay=new_event_delay[0:new_event_pointer[0]]
        new_event_type=new_event_type[0:new_event_pointer[0]]
        new_event_agent=new_event_agent[0:new_event_pointer[0]]

        new_event_delay = new_event_delay.astype(int)
        order_index=np.argsort(new_event_delay)
        ordered_new_event_delay=new_event_delay[order_index]
        ordered_new_event_delay=np.concatenate((ordered_new_event_delay,np.array([-1]))) #技巧，无意义
        ordered_new_event_type=new_event_type[order_index]
        ordered_new_event_agent=new_event_agent[order_index]
        current_type=[]
        current_agent=[]
        current_type.append(ordered_new_event_type[0])
        current_agent.append(ordered_new_event_agent[0])
        for i in range(1,new_event_pointer[0]+1):
            if ordered_new_event_delay[i]==ordered_new_event_delay[i-1]:
                current_type.append(ordered_new_event_type[i])
                current_agent.append(ordered_new_event_agent[i])
            else:
                last_delay=ordered_new_event_delay[i-1]
                current_type=np.asarray(current_type)
                current_agent=np.asarray(current_agent)
                target_t=self.current_step+last_delay+1
                if self.event_dict_type.__contains__(target_t) == False:
                    self.event_dict_type[target_t] =current_type
                    self.event_dict_agent[target_t]=current_agent
                else:
                    self.event_dict_type[target_t]=np.concatenate((self.event_dict_type[target_t],current_type))
                    self.event_dict_agent[target_t] = np.concatenate((self.event_dict_agent[target_t], current_agent))
                current_type=[]
                current_agent=[]
                if i<new_event_pointer[0]:
                  current_type.append(ordered_new_event_type[i])
                  current_agent.append(ordered_new_event_agent[i])


