import matplotlib.pyplot as plt
import numpy as np

a=np.zeros(100)
b=np.ones(100)
a[0]=1
print((a[a==99]).shape)
