import shapefile  # 使用pyshp库
from dbfread import DBF
import matplotlib.pyplot as plt

def get_geoinfo():
    shp = shapefile.Reader('E:/trajectory_test/EULUC_china/euluc-latlonnw.shp')
    dbf = DBF('E:/trajectory_test/EULUC_china/euluc-latlonnw.dbf')
    shapes = shp.shapes()
    records = shp.records()
    print(type(shapes))
    info={}
    info['shapes']=shapes
    info['records']=records
    return info

get_geoinfo()
#导入用地类型
# shp = shapefile.Reader('E:/trajectory_test/EULUC_china/euluc-latlonnw.shp')
# dbf = DBF('E:/trajectory_test/EULUC_china/euluc-latlonnw.dbf')
# shapes = shp.shapes()
# records = shp.records()

# <editor-fold desc="读取元数据">
# print(shp.shapeType)  # 输出shp类型
# print(shp.bbox)
# print(len(shapes))
# print(len(records))


# print(records[0]) #record中的第3项是城市码
# for field in dbf.fields:
#     print(field)
# dict_city_code={}
# dict_lat={}
# dict_lon={}

# shanghai_cnt=0
# for record in records:
#     city_code=record[3]
#     if dict_city_code.__contains__(city_code)==False:
#         dict_city_code[city_code]=0
#     dict_city_code[city_code]+=1
#     dict_lon[city_code]=record[0]
#     dict_lat[city_code]=record[1]
#     if city_code==310100:
#         shanghai_cnt+=1
# print(shanghai_cnt)

# for city in dict_city_code.keys():
#     lat=dict_lat[city]
#     lon=dict_lon[city]
#     if lat>=30 and lat<=32 and lon>=120 and lon<=123:
#         print(city)

#110100-北京市
#310100-上海市
# plt.figure()
# for i,shape in enumerate(shapes):
#     city=records[i][3]
#     if city==310100:
#         xs,ys=zip(*shape.points)
#         plt.plot(xs,ys)
