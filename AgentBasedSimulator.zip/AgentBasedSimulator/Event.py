class Event:
    def __init__(self,type,t):
        self.type=type
        self.t=t


