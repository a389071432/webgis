import random
import numpy as np
import Scene
from CustomEvents.EventsForEpidemic import EventForEpidemic

class EpidemicScene(Scene):
    def __init__(self,event_handler,agents,families,works,geoinfo,traffic,trasition_graph,interval=1,duration=168):
        super().__init__(interval,duration,event_handler,agents,geoinfo)
        self.families=families #家庭
        self.works=works     #企业
        self.traffic=traffic
        self.trasition_graph=trasition_graph
        self.assign_agent_to_family()
        self.assign_work_to_location()
        self.assign_family_to_household()
        self.assign_agent_to_work()
        self.regis_event_handlers()
        self.current_step=0

    #将agent注册到家庭
    def assign_agent_to_family(self):
        pointer=0
        for family in self.families:
            for i in range(0,family.size):
                agent=self.agents[pointer]
                agent.family=family
                family.members.append(agent)
                pointer+=1

    #将就业单位注册到物理地点，目前随意
    def assign_work_to_location(self):
        for work in self.works:
            x = random.randint(0, 9)
            y = random.randint(0, 9)
            while self.geoinfo.landuse[x][y]!=1:
                x = random.randint(0, 9)
                y = random.randint(0, 9)
            work.position_x=x
            work.position_y=y

    #应用区位选择模型，为家庭选择居住位置，目前随意
    def assign_family_to_household(self):
        for family in self.families:
            x = random.randint(0, 9)
            y = random.randint(0, 9)
            while self.geoinfo.landuse[x][y]!=0:
                x = random.randint(0, 9)
                y = random.randint(0, 9)
            family.position_x=x
            family.position_y=y

    #为agent选择就业单位，目前随意
    def assign_agent_to_work(self):
        index=0
        p=np.zeros(np.asarray(self.works).sum())
        pointer=0
        while pointer<p.shape[0]:
            p[pointer:pointer+len(self.works[index])]=index
            pointer+=len(self.works[index])
            index+=1
        for agent in self.agents:
            x=random.randint(0,p.shape[0])
            agent.work=self.works[p[x]]

    #注册事件回调函数
    def regis_event_handlers(self):
        self.event_handler.regis_event('infected_status_trasition',self.on_infected_status_trasition())
        self.event_handler.regis_event('activity_trasition',self.on_activity_trasition())

    #一步迭代
    def step(self,current_step):
        self.event_handler.step()
        self.update_agent_position()
        self.current_time=current_step*self.interval
        if self.current_time%24==0:    #每24小时更新agent的感染状态，根据每日接触列表
            self.update_infected_status()

    #感染状态转移事件
    def on_infected_status_trasition(self,event):

    #活动转移事件
    def on_activity_trasition(self,event):
        agent=event.agent
        agent.current_activity_index+=1
        next_activity=agent.activity_status[agent.current_activity_index]
        event=EventForEpidemic(next_activity,self.current_step+agent.activity_duration/self.interval,agent)
        if next_activity=='T':
            self.traffic.push_agent_to_stop(agent)
        else:
            self.event_handler.insert_a_event(event)

    #可自定义的agent每日感染状态计算函数
    def update_infected_status(self):


    #每个step根据agent的活动类型更新其位置
    def update_agent_position(self):


