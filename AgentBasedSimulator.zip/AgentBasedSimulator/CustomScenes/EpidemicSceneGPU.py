import time
import matplotlib.pyplot as plt
import numpy as np
from Scene import Scene
from numba import cuda,guvectorize
from numba.cuda.random import create_xoroshiro128p_states, xoroshiro128p_uniform_float32,create_xoroshiro128p_states, xoroshiro128p_uniform_float64
import math

@cuda.jit
def assign_agent_to_family_gpu(rng_states,p,family_mutex,family_members_pointer,family_real_size,family_members,agent_family,N):
    idx = cuda.threadIdx.x + cuda.blockIdx.x * cuda.blockDim.x
    if idx >= N:
        return
    id_in_warp=idx%cuda.warpsize
    if id_in_warp!=0:
          return
    for i in range(0,cuda.warpsize):
        now_id=idx+i
        if now_id<N:
            while True:
                x = xoroshiro128p_uniform_float32(rng_states, now_id) * (p.shape[0] - 1)
                x = math.floor(x)
                x = int(x)
                x = p[x]
                if family_members_pointer[x]<family_members.shape[1]:
                    break
            while cuda.atomic.compare_and_swap(family_mutex[x:], 0, 1) != 0:
                continue
            family_members[x][family_members_pointer[x]] = now_id
            agent_family[now_id]=x
            family_members_pointer[x]+=1
            family_real_size[x]+=1
            cuda.atomic.exch(family_mutex,x,0)


@cuda.jit
def assign_work_to_location_gpu(rng_states,land_use,work_location,n_sub,N):
    idx = cuda.threadIdx.x + cuda.blockIdx.x * cuda.blockDim.x
    if idx >= N:
        return
    x=xoroshiro128p_uniform_float32(rng_states, idx) * (land_use.shape[0]-1)
    y=xoroshiro128p_uniform_float32(rng_states, idx) * (land_use.shape[0]-1)
    x=int(x)
    y=int(y)
    while land_use[x][y]!=1:
        x = xoroshiro128p_uniform_float32(rng_states, idx) * (land_use.shape[0]-1)
        y = xoroshiro128p_uniform_float32(rng_states, idx) * (land_use.shape[0]-1)
        x = int(x)
        y = int(y)
    nx=xoroshiro128p_uniform_float32(rng_states, idx) * n_sub
    ny=xoroshiro128p_uniform_float32(rng_states, idx) * n_sub
    nx=int(nx)
    ny=int(ny)
    work_location[idx][0]=x*n_sub+nx
    work_location[idx][1]=y*n_sub+ny

@cuda.jit
def assign_family_to_location_gpu(rng_states,land_use,family_location,n_sub,N):
    idx = cuda.threadIdx.x + cuda.blockIdx.x * cuda.blockDim.x
    if idx >= N:
        return
    x=xoroshiro128p_uniform_float32(rng_states, idx) * (land_use.shape[0]-1)
    y=xoroshiro128p_uniform_float32(rng_states, idx) * (land_use.shape[0]-1)
    x=int(x)
    y=int(y)
    while land_use[x][y]!=0:
        x = xoroshiro128p_uniform_float32(rng_states, idx) * land_use.shape[0]
        y = xoroshiro128p_uniform_float32(rng_states, idx) * land_use.shape[0]
        x = int(x)
        y = int(y)
    dx=xoroshiro128p_uniform_float32(rng_states, idx) * (n_sub-1)
    dy=xoroshiro128p_uniform_float32(rng_states, idx) * (n_sub-1)
    dx=int(dx)
    dy=int(dy)
    family_location[idx][0]=x*n_sub+dx
    family_location[idx][1]=y*n_sub+dy

@cuda.jit
def assign_agent_to_work_gpu(rng_states,p,work_mutex,work_members_pointer,work_real_size,work_members,agent_work,N):
    idx = cuda.threadIdx.x + cuda.blockIdx.x * cuda.blockDim.x
    if idx >= N:
        return
    id_in_warp = idx % cuda.warpsize
    if id_in_warp != 0:
        return
    for i in range(0,cuda.warpsize):
        now_id=idx+i
        if now_id<N:
            while True:
                x = xoroshiro128p_uniform_float32(rng_states, now_id) * (p.shape[0]-1)
                x = math.ceil(x)
                x = int(x)
                x = p[x]
                if work_members_pointer[x]<work_members.shape[1]:
                    break
            while cuda.atomic.compare_and_swap(work_mutex[x:], 0, 1) == 1:
                continue
            work_members[x][work_members_pointer[x]] = now_id
            agent_work[now_id] = x
            work_members_pointer[x] += 1
            work_real_size[x] += 1
            cuda.atomic.compare_and_swap(work_mutex[x:], 1, 0)

@cuda.jit
def init_subarea_free_list_gpu(subarea_agents_free_list,subarea_agents_free_list_front,subarea_agents_free_list_rear,N):
    idx = cuda.threadIdx.x + cuda.blockIdx.x * cuda.blockDim.x
    if idx >= N:
        return
    len = math.sqrt(N)
    len = int(len)
    x = idx/ len
    y = idx% len
    x = int(x)
    y = int(y)
    for i in range(0,subarea_agents_free_list.shape[2]-1):
        subarea_agents_free_list[x][y][i]=i
    subarea_agents_free_list_front[x][y]=0
    subarea_agents_free_list_rear[x][y]=subarea_agents_free_list.shape[2]-1

@cuda.jit
def init_infected_trasition_events_gpu(agent_infected_status,agent_next_infected_staus,new_event_mutex,new_event_pointer,new_event_type,new_event_agent,new_event_delay,N):
    idx = cuda.threadIdx.x + cuda.blockIdx.x * cuda.blockDim.x
    if idx >= N:
        return
    id_in_warp = idx % cuda.warpsize
    if id_in_warp != 0:
        return
    for i in range(0, cuda.warpsize):
        now_id = idx + i
        if now_id < N:
            if agent_infected_status[now_id]>0:
                agent_next_infected_staus[now_id]=1
                while cuda.atomic.compare_and_swap(new_event_mutex, 0, 1) == 1:
                    continue
                new_event_type[new_event_pointer[0]] = 2
                new_event_delay[new_event_pointer[0]] =0
                new_event_agent[new_event_pointer[0]] = now_id
                new_event_pointer[0] += 1
                cuda.atomic.exch(new_event_mutex, 0, 0)

@cuda.jit
def init_events_gpu(agent_activity_duration,new_event_mutex,new_event_pointer, new_event_type,new_event_delay, new_event_agent,N):
    idx = cuda.threadIdx.x + cuda.blockIdx.x * cuda.blockDim.x
    if idx >= N:
        return
    id_in_warp = idx % cuda.warpsize
    if id_in_warp != 0:
        return
    for i in range(0, cuda.warpsize):
        now_id = idx + i
        if now_id < N:
            delay=agent_activity_duration[now_id][0]
            if now_id==0:
                print('agent0 will trasit to activity1 after',delay)
            while cuda.atomic.compare_and_swap(new_event_mutex, 0, 1) == 1:
                continue
            new_event_type[new_event_pointer[0]] =1
            new_event_delay[new_event_pointer[0]] = delay
            new_event_agent[new_event_pointer[0]] = now_id
            new_event_pointer[0]+=1
            cuda.atomic.exch(new_event_mutex,0,0)


@cuda.jit
def update_agent_position_gpu(rng_states,agent_position,current_activity_index,agent_activity_type,agent_activity_range,agent_activity_center,
                                  subarea_mutex,subarea_agents,subarea_agents_free_list,
                                  subarea_agents_free_list_front,subarea_agents_free_list_rear,N):
    idx = cuda.threadIdx.x + cuda.blockIdx.x * cuda.blockDim.x
    if idx >= N:
        return
    id_in_warp = idx % cuda.warpsize
    if id_in_warp != 0:
        return
    i=0
    while i<cuda.warpsize:
        now_id = idx + i
        i+=1
        if now_id < N:
            activity_index = current_activity_index[now_id]
            if agent_activity_type[now_id][activity_index] == 1:   #如果正在被运输，跳过
                continue
            x = int(agent_position[now_id][0])
            y = int(agent_position[now_id][1])
            center_x = agent_activity_center[now_id][activity_index][0]
            center_y = agent_activity_center[now_id][activity_index][1]
            range = agent_activity_range[now_id][activity_index]
            # 计算新位置
            r = xoroshiro128p_uniform_float32(rng_states, now_id) * range
            theta = xoroshiro128p_uniform_float32(rng_states, now_id) * 2 * math.pi
            nx = center_x + r * math.cos(theta)
            ny = center_y + r * math.sin(theta)
            #更新agent位置
            agent_position[now_id][0]=nx
            agent_position[now_id][1]=ny
            nx=int(nx)
            ny=int(ny)
            # 更新subarea_agents列表
            if x<0:
                x=0
            if y<0:
                y=0
            if nx<0:
                nx=0
            if ny<0:
                ny=0
            if x>=subarea_mutex.shape[0]:
                x=subarea_mutex.shape[0]-1
            if y>=subarea_mutex.shape[1]:
                y=subarea_mutex.shape[1]-1
            if nx>=subarea_mutex.shape[0]:
                nx=subarea_mutex.shape[0]-1
            if ny>=subarea_mutex.shape[1]:
                ny=subarea_mutex.shape[1]-1
            # 从现区域移除该agent
            pos = int(-1)
            k = 0
            while k < subarea_agents.shape[2]:
                # for i in range(0,subarea_agents.shape[2]):
                if subarea_agents[x][y][k] == now_id:
                    pos = k
                    break
                k += 1
            if pos != -1:
                subarea_agents[x][y][pos] = -1
                while cuda.atomic.compare_and_swap(subarea_mutex[x][y], 0, 1) == 1:
                    continue
                subarea_agents_free_list[x][y][subarea_agents_free_list_rear[x][y]] = pos
                subarea_agents_free_list_rear[x][y] += 1
                subarea_agents_free_list_rear[x][y] %= subarea_agents.shape[2]
                cuda.atomic.exch(subarea_mutex[x][y], 0, 0)
            # 将该agent加入新区域
            while cuda.atomic.compare_and_swap(subarea_mutex[nx][ny], 0, 1) == 1:
                continue
            npos = subarea_agents_free_list_front[nx][ny]
            subarea_agents_free_list_front[nx][ny] += 1
            subarea_agents_free_list_front[nx][ny] %= subarea_agents.shape[2]
            cuda.atomic.exch(subarea_mutex[nx][ny], 0, 0)
            subarea_agents[nx][ny][npos] = now_id


@cuda.jit
def event_step_gpu(event_type,event_agent,new_event_mutex,new_event_pointer,new_event_type,new_event_agent,new_event_delay,agent_activity_index,agent_activity_type,agent_activity_center,agent_activity_duration,agent_infected_status,
                                                            transport_mutex,transport_pointer,transport_agents,transport_agents_target,rng_states,agent_next_infected_status,trasition_graph_degree,trasition_graph_prob,trasition_graph_node,trasition_graph_delay,N):
    idx = cuda.threadIdx.x + cuda.blockIdx.x * cuda.blockDim.x
    if idx >= N:
        return
    id_in_warp = idx % cuda.warpsize
    if id_in_warp != 0:
        return

    for i in range(0, cuda.warpsize):
        now_id = idx + i
        if now_id < N:
            new_type = -1
            new_delay = -1
            new_agent = -1
            agent=event_agent[now_id]
            type=event_type[now_id]
            if type==0 or type==1:
                agent_activity_index[agent] += 1
                agent_activity_index[agent] %= agent_activity_duration.shape[1]
            #处理单个事件
            if type == 0:                 # 0代表activity_start
                next_index = (agent_activity_index[agent] + 1) % agent_activity_duration.shape[1]
                next_activity_type = agent_activity_type[agent][next_index]
                if next_activity_type == 1:
                    new_type = 1
                else:
                    new_type = 0
                new_agent = agent
                new_delay = agent_activity_duration[agent][agent_activity_index[agent]]
            elif type == 1:               # 1代表transport_start
                while cuda.atomic.compare_and_swap(transport_mutex, 0, 1) == 1:
                    continue
                transport_agents[transport_pointer[0]] = agent
                transport_agents_target[transport_pointer[0]][0] = agent_activity_center[agent][
                    (agent_activity_index[agent] + 1) % agent_activity_duration.shape[1]][0]
                transport_agents_target[transport_pointer[0]][1] = agent_activity_center[agent][
                    (agent_activity_index[agent] + 1) % agent_activity_duration.shape[1]][1]
                transport_pointer[0] += 1
                cuda.atomic.compare_and_swap(transport_mutex, 1, 0)
            elif type==2:                # 2代表infected_status_trasition
                agent_infected_status[agent]=agent_next_infected_status[agent]
                #根据转移概率确定下一个感染状态
                p=xoroshiro128p_uniform_float32(rng_states, now_id)
                now_status=agent_infected_status[agent]
                new_status=-1
                p_sum=0
                for k in range(0,trasition_graph_degree[now_status]):
                    if p>= p_sum and p<=p_sum+trasition_graph_prob[now_status][k]:
                        new_status=trasition_graph_node[now_status][k]
                        new_delay=trasition_graph_delay[now_status][k]
                        break
                    p_sum+=trasition_graph_prob[now_status][k]
                agent_next_infected_status[agent]=new_status
                new_agent=agent
                new_type=2
                if trasition_graph_degree[now_status]==0:
                    new_type=-1

            # 若插入新事件，互斥访问new_event
            if new_type == -1:
                continue
            while cuda.atomic.compare_and_swap(new_event_mutex, 0, 1) == 1:
                continue
            new_event_type[new_event_pointer[0]] = new_type
            new_event_agent[new_event_pointer[0]] = new_agent
            new_event_delay[new_event_pointer[0]] = new_delay
            new_event_pointer[0] += 1
            cuda.atomic.exch(new_event_mutex, 0, 0)

@cuda.jit
def fill_agent_activiry_center_gpu(agent_family,family_location,agent_work,work_location,agent_activity_center,N):
    idx = cuda.threadIdx.x + cuda.blockIdx.x * cuda.blockDim.x
    if idx >= N:
        return
    agent_activity_center[idx][0][0]=family_location[agent_family[idx]][0]
    agent_activity_center[idx][0][1] = family_location[agent_family[idx]][1]

    agent_activity_center[idx][6][0]=agent_activity_center[idx][0][0]
    agent_activity_center[idx][6][1] = agent_activity_center[idx][0][1]

    agent_activity_center[idx][2][0] = work_location[agent_work[idx]][0]
    agent_activity_center[idx][2][1] = work_location[agent_work[idx]][1]

    agent_activity_center[idx][4][0] = agent_activity_center[idx][2][0]
    agent_activity_center[idx][4][1] = agent_activity_center[idx][2][1]

    agent_activity_center[idx][3][0] = agent_activity_center[idx][2][0]
    agent_activity_center[idx][3][1] = agent_activity_center[idx][2][1]


@cuda.jit
def generate_walking_events_gpu(arrive_agents,agents_now_postion,agents_target,new_event_mutex,new_event_pointer, new_event_type,
                                                            new_event_delay, new_event_agent,N):
    idx = cuda.threadIdx.x + cuda.blockIdx.x * cuda.blockDim.x
    if idx >= N:
        return
    id_in_warp = idx % cuda.warpsize
    if id_in_warp != 0:
        return
    for i in range(0, cuda.warpsize):
        now_id = idx + i
        if now_id < N:
            x=agents_now_postion[now_id][0]
            y=agents_now_postion[now_id][1]
            tx=agents_target[now_id][0]
            ty=agents_target[now_id][1]
            delay=math.sqrt((x-tx)*(x-tx)+(y-ty)*(y-ty))/45
            while cuda.atomic.compare_and_swap(new_event_mutex, 0, 1) == 1:
                continue
            new_event_type[new_event_pointer[0]]=0
            new_event_delay[new_event_pointer[0]]=delay
            new_event_agent[new_event_pointer[0]]=arrive_agents[now_id]
            new_event_pointer[0]+=1
            cuda.atomic.exch(new_event_mutex,0,0)

@cuda.jit
def update_infected_points_gpu(agent_initial_points,agent_infected_status,subarea_agents,new_event_mutex,new_event_pointer,new_event_type,new_event_agent,new_event_delay,rng_states,subarea_free_list_front,subarea_free_list_rear,next_infected_status,temp,N):
    idx = cuda.threadIdx.x + cuda.blockIdx.x * cuda.blockDim.x
    if idx >= N:
        return
    id_in_warp = idx % cuda.warpsize
    if id_in_warp != 0:
        return
    for i in range(0, cuda.warpsize):
        now_id = idx + i
        if now_id < N:
            len=math.sqrt(N)
            len=int(len)
            x=now_id/len
            y=now_id%len
            x=int(x)
            y=int(y)
            #该区域当前有多少agent
            front=subarea_free_list_front[x][y]
            rear=subarea_free_list_rear[x][y]
            cnt=0
            for k in range(0,subarea_agents.shape[2]):
                if subarea_agents[x][y][k]!=-1:
                    temp[x][y][cnt]=subarea_agents[x][y][k]
                    cnt+=1
            #随机从该区域选择若干对agent进行接触，平均每个agent接触2人
            ave_contact=1
            now=0
            while now<ave_contact*cnt/2:
                a=xoroshiro128p_uniform_float32(rng_states, now_id)*(cnt-1)
                b=xoroshiro128p_uniform_float32(rng_states, now_id)*(cnt-1)
                a=int(a)
                b=int(b)
                agent_a=temp[x][y][a]
                agent_b=temp[x][y][b]
                now += 1
                if agent_infected_status[agent_a] > 0 or agent_infected_status[agent_b] > 0:
                    agent_initial_points[agent_a] -= 1
                    agent_initial_points[agent_b] -= 1
                    if agent_initial_points[agent_a] == 0:  # 若减为0，插入新事件
                        next_infected_status[agent_a] = 1  # 1代表刚被感染
                        while cuda.atomic.compare_and_swap(new_event_mutex, 0, 1) == 1:
                            continue
                        new_event_type[new_event_pointer[0]] = 2
                        new_event_delay[new_event_pointer[0]] = 0
                        new_event_agent[new_event_pointer[0]] = agent_a
                        new_event_pointer[0] += 1
                        cuda.atomic.exch(new_event_mutex, 0, 0)
                    if agent_initial_points[agent_b] == 0:  # 若减为0，插入新事件
                        next_infected_status[agent_b] = 1
                        while cuda.atomic.compare_and_swap(new_event_mutex, 0, 1) == 1:
                            continue
                        new_event_type[new_event_pointer[0]] = 2
                        new_event_delay[new_event_pointer[0]] = 0
                        new_event_agent[new_event_pointer[0]] = agent_b
                        new_event_pointer[0] += 1
                        cuda.atomic.exch(new_event_mutex, 0, 0)



@cuda.jit
def temp_statis_population_grid(agent_family,family_location,temp_mutex,temp,N):
    idx = cuda.threadIdx.x + cuda.blockIdx.x * cuda.blockDim.x
    if idx >= N:
        return
    id_in_warp = idx % cuda.warpsize
    if id_in_warp != 0:
        return
    for i in range(0, cuda.warpsize):
        now_id = idx + i
        if now_id < N:
            x = family_location[agent_family[now_id]][0]
            y = family_location[agent_family[now_id]][1]
            x = int(x / 10)
            y = int(y / 10)
            while cuda.atomic.compare_and_swap(temp_mutex[x][y], 0, 1) == 1:
                continue
            temp[x][y] += 1
            cuda.atomic.exch(temp_mutex[x][y],0,0)

@cuda.jit
def temp_statis_household_gird(family_location,temp_mutex,temp,N):
    idx = cuda.threadIdx.x + cuda.blockIdx.x * cuda.blockDim.x
    if idx >= N:
        return
    id_in_warp = idx % cuda.warpsize
    if id_in_warp != 0:
        return
    for i in range(0, cuda.warpsize):
        now_id = idx + i
        if now_id < N:
            x = family_location[now_id][0]
            y = family_location[now_id][1]
            x = int(x / 10)
            y = int(y / 10)
            while cuda.atomic.compare_and_swap(temp_mutex[x][y], 0, 1) == 1:
                continue
            temp[x][y] += 1
            cuda.atomic.exch(temp_mutex[x][y],0,0)

@cuda.jit
def statis_region_infected_cnt_gpu(agent_position,agent_infected_status,temp,temp_mutex,N):
    idx = cuda.threadIdx.x + cuda.blockIdx.x * cuda.blockDim.x
    if idx >= N:
        return
    id_in_warp = idx % cuda.warpsize
    if id_in_warp != 0:
        return
    for i in range(0, cuda.warpsize):
        now_id = idx + i
        if now_id < N:
            if agent_infected_status[now_id]!=1:
                continue
            x = agent_position[now_id][0]
            y = agent_position[now_id][1]
            x = int(x / 10)
            y = int(y / 10)
            while cuda.atomic.compare_and_swap(temp_mutex[x][y], 0, 1) == 1:
                continue
            temp[x][y] += 1
            cuda.atomic.exch(temp_mutex[x][y], 0, 0)


class EpidemicSceneGPU(Scene):
    def __init__(self, event_handler, agents, families, works, geoinfo, traffic, trasition_graph, interval=1,duration=168):
        super().__init__(event_handler, agents, geoinfo,interval, duration)
        self.trasition_graph=trasition_graph
        self.families = families  # 家庭
        self.works = works  # 企业
        self.traffic = traffic
        self.trasition_graph = trasition_graph
        self.current_step = 0
        self.total_steps=duration

        #numpy arrays FOR GPU
        self.agent_family=np.zeros(len(self.agents)).astype(int)
        self.agent_work = np.zeros(len(self.agents)).astype(int)
        self.agent_commuting_distance=np.zeros(len(self.agents))
        self.agent_activity_type=np.zeros([len(self.agents),7]).astype(int)
        self.agent_activity_duration=np.zeros([len(self.agents),7])
        self.agent_activity_center=np.zeros([len(self.agents),7,2])   #以subarea为单位
        self.agent_activity_range = np.zeros([len(self.agents), 7])
        self.agent_current_activity_index=np.zeros(len(self.agents)).astype(int)
        self.agent_infected_status=np.zeros(len(self.agents)).astype(int)
        self.agent_next_infected_status=np.zeros(len(self.agents)).astype(int)
        self.agent_daily_contacts=np.zeros([len(self.agents),48])
        self.agent_daily_contacts_pointer=np.zeros(len(self.agents))
        self.agent_position=np.zeros([len(self.agents),2])
        self.agent_infected_status=np.zeros([len(self.agents)]).astype(int)
        self.agent_initial_points=np.zeros([len(self.agents)]).astype(int)

        self.family_size=np.zeros(len(self.families)).astype(int)
        self.family_real_size=np.zeros(len(self.families)).astype(int)
        self.family_members=np.zeros([len(self.families),5]).astype(int)
        self.family_location=np.zeros([len(self.families),2])
        self.work_size=np.zeros(len(self.works)).astype(int).astype(int)
        self.work_real_size=np.zeros(len(self.works)).astype(int)
        self.work_members=np.zeros([len(self.works),50]).astype(int)
        self.work_location=np.zeros([len(self.works),2])
        #每个子区域的当前agent列表
        self.subarea_agents=np.zeros([self.geoinfo.n_grids*self.geoinfo.n_sub,self.geoinfo.n_grids*self.geoinfo.n_sub,50]).astype(int)
        #每个子区域的agent列表的空闲位置索引，以循环队列的形式实现
        self.subarea_agents_free_list=np.zeros([self.geoinfo.n_grids*self.geoinfo.n_sub,self.geoinfo.n_grids*self.geoinfo.n_sub,50+1]).astype(int)
        #front和rear指针
        self.subarea_agents_free_list_front=np.zeros([self.geoinfo.n_grids*self.geoinfo.n_sub,self.geoinfo.n_grids*self.geoinfo.n_sub]).astype(int)
        self.subarea_agents_free_list_rear = np.zeros([self.geoinfo.n_grids * self.geoinfo.n_sub, self.geoinfo.n_grids * self.geoinfo.n_sub]).astype(int)

        self.new_event_mutex = np.zeros(1).astype(int)
        self.new_event_pointer = np.zeros(1).astype(int)
        self.new_event_type = np.zeros(10000000).astype(int)
        self.new_event_delay = np.zeros(10000000)
        self.new_event_agent = np.zeros(10000000).astype(int)

        #感染状态转移图相关
        self.trasition_graph_node=None   #结点
        self.trasition_graph_prob=None   #转移概率
        self.trasiton_graph_delay=None   #转移时延
        self.trasition_graph_degree=None

        #感染状态统计
        self.step_infected_status_cnt=None

        self.init_arrays_for_gpu()
        self.transmit_arrays_to_gpu()
        self.assign_agent_to_family(self)
        self.assign_work_to_location(self)
        self.assign_family_to_household(self)

        # self.draw_household_heatmap(self)
        # self.draw_population_heatmap(self)  #绘制初始人口分布热力图，debug用

        self.assign_agent_to_work(self)
        self.fill_agent_activity_center(self)
        self.init_agent_position()
        self.current_step = 0
        #self.init_infected_trasition_events(self)
        self.init_events(self)
        self.event_handler.insert_new_events(self.new_event_pointer,self.new_event_type,self.new_event_agent,self.new_event_delay)
        self.new_event_pointer[0]= 0
        self.plt=plt
        self.figure=self.plt.figure()
        self.plt.rcParams['agg.path.chunksize'] = 10000000
        #self.plt.ion()
        print('scene init done')
        print('total agents:',len(self.agents))
        print('agent0 init position:',self.agent_position[0][0], self.agent_position[0][1])
        print('agent0 work position:',self.work_location[self.agent_work[0]][0],self.work_location[self.agent_work[0]][1])
        print('agent0 activity0 duration:',self.agent_activity_duration[0][0])
        #绘制land use图层
        #self.geoinfo.plot_landuse(self.plt)


    # 初始化用于gpu计算的数组
    def init_arrays_for_gpu(self):
        for i in range(0,self.agent_commuting_distance.shape[0]):
            self.agent_commuting_distance[i]=self.agents[i].commuting_distance

        for i in range(0,self.agent_activity_type.shape[0]):
            for j in range(0,self.agent_activity_type.shape[1]):
                self.agent_activity_type[i][j]=self.agents[i].activity_type[j]

        for i in range(0,self.agent_activity_duration.shape[0]):
            for j in range(0,self.agent_activity_duration.shape[1]):
                self.agent_activity_duration[i][j]=self.agents[i].activity_duration[j]

        for i in range(0,self.agent_activity_range.shape[0]):
            for j in range(0,self.agent_activity_range.shape[1]):
                self.agent_activity_range[i][j]=self.agents[i].activity_range[j]

        for i in range(0,self.family_size.shape[0]):
            self.family_size[i]=self.families[i].size

        for i in range(0,self.work_size.shape[0]):
            self.work_size[i]=self.works[i].size

        for i in range(0,self.agent_infected_status.shape[0]):
            self.agent_infected_status[i]=self.agents[i].infected_status

        for i in range(0,self.agent_initial_points.shape[0]):
            self.agent_initial_points[i]=self.agents[i].initial_points

        #subarea_agents初始化为-1
        temp=np.ones(self.subarea_agents.shape)
        self.subarea_agents=(self.subarea_agents-temp).astype(int)
        self.init_subarea_free_list(self)

        al_prob=self.trasition_graph['prob']
        al_delay=self.trasition_graph['delay']
        max_degree=-1   #最大度
        for i in range(0,len(al_prob.al)):
            max_degree=max(max_degree,len(al_prob.al[i]))
        self.trasition_graph_node=np.zeros([al_prob.n_nodes,max_degree]).astype(int)
        self.trasition_graph_prob = np.zeros([al_prob.n_nodes, max_degree])
        self.trasition_graph_delay = np.zeros([al_prob.n_nodes, max_degree])
        self.trasition_graph_degree=np.zeros(al_prob.n_nodes).astype(int)
        self.step_infected_status_cnt=np.zeros([self.total_steps,al_prob.n_nodes]).astype(int)

        for i in range(0,len(al_prob.al)):
            self.trasition_graph_degree[i]=len(al_prob.al[i])

        for i in range(0,len(al_prob.al)):
            for k in range(0,len(al_prob.al[i])):
                self.trasition_graph_node[i][k]=al_prob.al[i][k].y

        for i in range(0,len(al_prob.al)):
            for k in range(0,len(al_prob.al[i])):
                self.trasition_graph_prob[i][k]=al_prob.al[i][k].w

        for i in range(0,len(al_delay.al)):
            for k in range(0,len(al_delay.al[i])):
                self.trasition_graph_delay[i][k]=al_delay.al[i][k].w

    #将频繁读写的array预先装入gpu
    def transmit_arrays_to_gpu(self):
        self.agent_family=cuda.to_device(self.agent_family)
        self.family_members=cuda.to_device(self.family_members)
        self.family_real_size=cuda.to_device(self.family_real_size)
        self.geoinfo.land_use=cuda.to_device(self.geoinfo.land_use)
        self.family_location=cuda.to_device(self.family_location)
        self.work_location=cuda.to_device(self.work_location)
        self.agent_work=cuda.to_device(self.agent_work)
        self.work_members=cuda.to_device(self.work_members)
        self.work_real_size=cuda.to_device(self.work_real_size)
        self.agent_activity_duration=cuda.to_device(self.agent_activity_duration)
        self.new_event_agent=cuda.to_device(self.new_event_agent)
        self.new_event_type = cuda.to_device(self.new_event_type)
        self.new_event_delay = cuda.to_device(self.new_event_delay)
        self.new_event_mutex = cuda.to_device(self.new_event_mutex)
        self.new_event_pointer = cuda.to_device(self.new_event_pointer)
        self.subarea_agents=cuda.to_device(self.subarea_agents)
        #self.agent_infected_status=cuda.to_device(self.agent_infected_status)
        self.agent_initial_points=cuda.to_device(self.agent_initial_points)

    @staticmethod
    def assign_agent_to_family(self):
        rng_states = create_xoroshiro128p_states(1024*math.ceil(len(self.agents)/1024), seed=time.time())
        p=np.zeros(self.family_size.sum()).astype(int)
        pointer=0
        for i in range(0,self.family_size.shape[0]):
            for j in range(0,self.family_size[i]):
                p[pointer]=i
                pointer+=1
        family_mutex=np.zeros(len(self.families)).astype(int)
        family_members_pointer=np.zeros(len(self.families)).astype(int)
        t0=time.time()
        family_mutex=cuda.to_device(family_mutex)
        family_members_pointer=cuda.to_device(family_members_pointer)
        p=cuda.to_device(p)
        assign_agent_to_family_gpu[math.ceil(len(self.agents)/1024),1024](rng_states,p,family_mutex,family_members_pointer,self.family_real_size,self.family_members,self.agent_family,len(self.agents))
        t1 = time.time()
        cuda.synchronize()
        print('assign_family done,total',t1-t0)

    @staticmethod
    def assign_work_to_location(self):
        rng_states = create_xoroshiro128p_states(1024 * math.ceil(len(self.works) / 1024), seed=time.time())
        assign_work_to_location_gpu[math.ceil(len(self.works)/1024),1024](rng_states,self.geoinfo.land_use,self.work_location,self.geoinfo.n_sub,len(self.works))
        cuda.synchronize()

    @staticmethod
    def assign_family_to_household(self):
        rng_states = create_xoroshiro128p_states(1024 * math.ceil(len(self.families) / 1024), seed=time.time())
        assign_family_to_location_gpu[math.ceil(len(self.families) / 1024), 1024](rng_states, self.geoinfo.land_use, self.family_location,self.geoinfo.n_sub, len(self.families))
        cuda.synchronize()

    @staticmethod
    def assign_agent_to_work(self):
        rng_states = create_xoroshiro128p_states(1024 * math.ceil(len(self.agents) / 1024), seed=time.time())
        p = np.zeros(self.work_size.sum()).astype(int)
        pointer = 0
        for i in range(0, self.work_size.shape[0]):
            for j in range(0, self.work_size[i]):
                p[pointer] = i
                pointer += 1
        work_mutex = np.zeros(len(self.works)).astype(int)
        work_members_pointer = np.zeros(len(self.works)).astype(int)
        p=cuda.to_device(p)
        work_mutex=cuda.to_device(work_mutex)
        work_members_pointer=cuda.to_device(work_members_pointer)
        assign_agent_to_work_gpu[math.ceil(len(self.agents) / 1024), 1024](rng_states, p, work_mutex,
                                                                             work_members_pointer,
                                                                             self.work_real_size, self.work_members,
                                                                             self.agent_work, len(self.agents))
        cuda.synchronize()
        print('assign work done')

    #根据agent的household和workplace填充部分activity_center
    @staticmethod
    def fill_agent_activity_center(self):
        fill_agent_activiry_center_gpu[math.ceil(len(self.agents) / 1024), 1024](self.agent_family,self.family_location,self.agent_work,self.work_location,self.agent_activity_center,len(self.agents))
        cuda.synchronize()

    @staticmethod
    def init_subarea_free_list(self):
        N = self.geoinfo.n_grids * self.geoinfo.n_sub * self.geoinfo.n_grids * self.geoinfo.n_sub
        init_subarea_free_list_gpu[math.ceil(N/1024),1024](self.subarea_agents_free_list,self.subarea_agents_free_list_front,self.subarea_agents_free_list_rear,N)

    def init_agent_position(self):
        for i in range(0,len(self.agents)):
            self.agent_position[i][0]=self.agent_activity_center[i][0][0]
            self.agent_position[i][1] = self.agent_activity_center[i][0][1]

    #为初始感染者注册状态转移事件
    @staticmethod
    def init_infected_trasition_events(self):
        init_infected_trasition_events_gpu[math.ceil(len(self.agents)/1024),1024](self.agent_infected_status,self.agent_next_infected_status,self.new_event_mutex,self.new_event_pointer,self.new_event_type,self.new_event_agent,self.new_event_delay,len(self.agents))

    #注册初始事件
    @staticmethod
    def init_events(self):
        init_events_gpu[math.ceil(len(self.agents)/1024),1024](self.agent_activity_duration,self.new_event_mutex,self.new_event_pointer, self.new_event_type,
                                                             self.new_event_delay, self.new_event_agent,len(self.agents))
        cuda.synchronize()

    #一步迭代
    def update(self):
        self.event_handler.to_numpy()
        # 触发一般事件，生成新的一般事件
        self.event_step(self)
        # 触发交通事件，生成新的一般事件
        arrive_agents, agents_now_postion = self.traffic.update()
        self.generate_walking_events(self,arrive_agents, agents_now_postion)
        self.update_infected_points(self)
        self.statis_infected_status()
        #将新生成的一般事件统一注册到event_handler
        self.event_handler.insert_new_events(self.new_event_pointer,self.new_event_type,self.new_event_agent,self.new_event_delay)
        self.new_event_pointer[0] = 0
        self.update_agent_position(self)
        self.current_time=self.current_step*self.interval
        if self.current_time>0 and self.current_time%24==0:    #每24小时更新agent的感染状态，根据每日接触列表
            self.update_infected_status()
        self.visualize()
        print('step',self.current_step,'done')
        print('now infected cnt:',self.agent_infected_status[self.agent_infected_status==1].shape[0])

    @staticmethod
    def event_step(self):
        if self.event_handler.now_event_type.shape[0]==0 or self.event_handler.now_event_type[0]==-1:
            return
        transport_agents = np.zeros(len(self.agents)).astype(int)
        transport_mutex = np.zeros(1).astype(int)
        transport_pointer = np.zeros(1).astype(int)
        transport_agents_target=np.zeros([len(self.agents),2])
        rng_states = create_xoroshiro128p_states(1024 * math.ceil(self.event_handler.now_event_type.shape[0] / 1024), seed=time.time())
        event_step_gpu[math.ceil(self.event_handler.now_event_type.shape[0]/ 1024), 1024](self.event_handler.now_event_type, self.event_handler.now_event_agent, self.new_event_mutex,self.new_event_pointer, self.new_event_type
                                                            , self.new_event_agent, self.new_event_delay,self.agent_current_activity_index,
                                                            self.agent_activity_type, self.agent_activity_center,self.agent_activity_duration,
                                                            self.agent_infected_status,
                                                            transport_mutex,transport_pointer,transport_agents,transport_agents_target,
                                                                                          rng_states,
                                                                                          self.agent_next_infected_status,
                                                                                          self.trasition_graph_degree,
                                                                                          self.trasition_graph_prob,
                                                                                          self.trasition_graph_node,
                                                                                          self.trasition_graph_delay,
                                                            self.event_handler.now_event_type.shape[0])
        cuda.synchronize()
        #将等待运输的agent交由traffic处理
        transport_agent_index=transport_agents[0:transport_pointer[0]].tolist()
        if len(transport_agent_index)>0:
           self.traffic.transport_agents(self.traffic,transport_agent_index,self.agent_position[transport_agent_index],transport_agents_target[0:transport_pointer[0]])  #索引有问题

    #agent下车后，为其生成步行到目的地事件
    @staticmethod
    def generate_walking_events(self,arrive_agents, agents_now_postion):
        if arrive_agents[0]==-1:
            return
        self.new_event_mutex[0]=0
        #此处agent是一小部分，即agent的全局索引=arrive_agents[idx]
        agents_current_activity_index=self.agent_current_activity_index[arrive_agents]
        agents_activity_center=self.agent_activity_center[arrive_agents]
        agents_target=np.zeros([arrive_agents.shape[0],2])
        for i in range(0,arrive_agents.shape[0]):  #有问题
            agents_target[i]=agents_activity_center[i][(agents_current_activity_index[i]+1)%agents_activity_center.shape[1]]
        generate_walking_events_gpu[math.ceil(arrive_agents.shape[0]/1024),1024](arrive_agents,agents_now_postion,agents_target,self.new_event_mutex,self.new_event_pointer, self.new_event_type,
                                                            self.new_event_delay, self.new_event_agent,arrive_agents.shape[0])
        cuda.synchronize()

    @staticmethod
    def update_infected_points(self):
        N=self.geoinfo.n_grids*self.geoinfo.n_sub*self.geoinfo.n_grids*self.geoinfo.n_sub
        rng_states = create_xoroshiro128p_states(1024 * math.ceil(N / 1024), seed=time.time())
        temp=np.zeros(self.subarea_agents.shape).astype(int)
        update_infected_points_gpu[math.ceil(N/1024),1024](self.agent_initial_points,self.agent_infected_status,self.subarea_agents,self.new_event_mutex,self.new_event_pointer,self.new_event_type,self.new_event_agent,self.new_event_delay,rng_states,self.subarea_agents_free_list_front,self.subarea_agents_free_list_rear,self.agent_next_infected_status,temp,N)
        cuda.synchronize()

    def statis_infected_status(self):
        now_step=self.current_step
        for i in range(0,self.step_infected_status_cnt.shape[1]):
            self.step_infected_status_cnt[now_step][i]=(self.agent_infected_status[self.agent_infected_status==i]).shape[0]

    @staticmethod
    def update_agent_position(self):
        rng_states = create_xoroshiro128p_states(1024 * math.ceil(len(self.agents) / 1024), seed=time.time())
        subarea_mutex=np.zeros([self.subarea_agents.shape[0],self.subarea_agents.shape[1],1]).astype(int)
        update_agent_position_gpu[math.ceil(len(self.agents) / 1024), 1024](rng_states,self.agent_position,self.agent_current_activity_index,
                                                                            self.agent_activity_type,self.agent_activity_range,self.agent_activity_center,
                                  subarea_mutex,self.subarea_agents,self.subarea_agents_free_list,
                                  self.subarea_agents_free_list_front,self.subarea_agents_free_list_rear,len(self.agents))
        cuda.synchronize()

    def update_infected_status(self):
        pass

    def visualize(self):
        # self.plt.clf()
        xs, ys = zip(*self.agent_position)
        # self.plt.scatter(xs, ys,s=0.1,alpha=0.5)
        #self.plt.show()
        #self.plt.pause(0.5)
        # print('Agent0 current activity index:',self.agent_current_activity_index[0])
        # print('agent0:',self.agent_position[0][0],self.agent_position[0][1])

    def step(self):
        self.current_step+=1
        self.traffic.step()
        self.event_handler.step()

    @staticmethod
    def draw_population_heatmap(self):
        temp = np.zeros([100, 100]).astype(int)
        temp_mutex = np.zeros([100, 100,1]).astype(int)
        temp_statis_population_grid[math.ceil(len(self.agents) / 1024), 1024](self.agent_family, self.family_location,
                                                                              temp_mutex,temp, len(self.agents))
        cuda.synchronize()
        plt.imshow(temp, cmap=plt.cm.hot, vmin=0, vmax=temp.max())
        plt.colorbar()
        plt.show()

    @staticmethod
    def draw_household_heatmap(self):
        temp = np.zeros([100, 100]).astype(int)
        temp_mutex=np.zeros([100,100,1]).astype(int)
        self.family_location = self.family_location.copy_to_host()
        temp_statis_household_gird[math.ceil(len(self.families) / 1024), 1024](self.family_location,
                                                                        temp_mutex,temp, len(self.families))
        cuda.synchronize()
        plt.imshow(temp, cmap=plt.cm.hot, vmin=0, vmax=temp.max())
        plt.colorbar()
        plt.show()

    def show_infected_status_cnt(self):
        xx=np.linspace(0,self.total_steps-1,self.total_steps).astype(int)
        for i in range(1,3):
            self.plt.plot(xx,self.step_infected_status_cnt[:,i])
        print('before show')
        #print(self.step_infected_status_cnt[:,0])
        # print(self.step_infected_status_cnt[:,1])
        # print(self.step_infected_status_cnt[:,2])
        self.plt.show()
        self.plt.pause(3600*3)
        print('after show')

    @staticmethod
    def statis_region_infected_cnt(self):
        temp = np.zeros([100, 100]).astype(int)
        temp_mutex = np.zeros([100, 100, 1]).astype(int)
        statis_region_infected_cnt_gpu[math.ceil(len(self.agents)/1024),1024](self.agent_position,self.agent_infected_status,temp,temp_mutex,len(self.agents))
        cuda.synchronize()
        print('before imshow')
        self.plt.imshow(temp, cmap=plt.cm.hot, vmin=0, vmax=temp.max())
        self.plt.colorbar()
        self.plt.show()
        #self.plt.pause(3600 * 3)
        #self.plt.savefig('heatmaps/step_'+str(self.current_step)+'.jpg')