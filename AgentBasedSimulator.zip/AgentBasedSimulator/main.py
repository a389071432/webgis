from Simulator import Simulator
from utils import generate_human_agents,get_traffic_data,get_trasition_graph
from GeoInfo import GeoInfo
from CustomScenes.EpidemicSceneGPU import EpidemicSceneGPU
from EventHandler import EventHandler
from Traffic.Traffic import Traffic
from DataProcess.DataImport import get_geoinfo

city_code=310100
n_grids=100
n_sub=10
data=None
traffic_data=None
interval=1

agents,families,works=generate_human_agents(data)
info=get_geoinfo()
trasition_graph=get_trasition_graph()
geoinfo=GeoInfo(city_code,info,30000*30000,n_grids,n_sub)
stops,lines=get_traffic_data(traffic_data)
event_handler_scene=EventHandler()
event_handler_traffic=EventHandler()
traffic=Traffic(event_handler_traffic,10000000,geoinfo,None,stops,lines)
scene=EpidemicSceneGPU(event_handler_scene,agents,families,works,geoinfo,traffic,trasition_graph,1,60*24)
simulator=Simulator(scene,duration=60*24,interval=interval)
simulator.start()

