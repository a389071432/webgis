
class HumanAgent:
    def __init__(self):
        self.id=None
        self.position_x=None
        self.position_y=None

class EstateAgent:
    def __init__(self,size):
        self.id=None
        self.location_x=None
        self.location_y=None
        self.size=size   #规模


