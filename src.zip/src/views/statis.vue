<template>
<div>
  <HeadNav></HeadNav>
  <leftMenu></leftMenu>
  <div id="chart" ></div>
</div>
</template>

<script>
import * as echarts from 'echarts';
import axios from "axios";
import LeftMenu from "../components/LeftMenu";
import HeadNav from "../components/HeadNav";

export default {
  name: "statis",
  components: {
    LeftMenu,
    HeadNav
  },
  data(){
    return{
      mychart:null,
      n_nodes:0,
      node_name:[],
      series:null,
      has_set_interval:false //是否已设置过定时函数,

    };
  },
  created() {
    console.log('created')
    this.$root.$on('on_simulation',()=>{    //监听仿真启动事件(启动or继续)
      if(this.has_set_interval===true)
        return
      setInterval(this.update_chart,3000)
      this.has_set_interval=true
      this.seris=[{},{},{},{},{}]
    })
  },
  mounted() {
    this.init()
    this.$root.$on('on_simulation',()=>{    //监听仿真启动事件(启动or继续)
      if(this.has_set_interval===true)
        return
      setInterval(this.update_chart,3000)
      this.has_set_interval=true
      this.seris=[{},{},{},{},{}]
    })
  },
  activated() {
    if(this.has_set_interval===true)
      return
    this.$root.$on('on_simulation',()=>{    //监听仿真启动事件(启动or继续)
      if(this.has_set_interval===true)
        return
      setInterval(this.update_chart,3000)
      console.log('set set')
      this.has_set_interval=true
    })
  },
  methods:{
    init:function (){
      this.chart = echarts.init(document.getElementById('chart'))
      let option = {
        title: {
          top:30,
          text: '感染状态曲线',//主标题
          textStyle:{
            color:"skyblue",//主标题颜色
            fontSize:'20',//主标题大小
          },
          sublink: 'http://oa.piesat.cn/seeyon/main.do?method=index',//副标题链接
          subtarget:'blank',//self/blank
          subtextStyle:{
            color:'#0f0',
            fontSize:'30'
          },
          left: 'center',//位置
          show: true,//是否显示true/false
          textAlign:'left',//水平对齐：auto/left,right,center
          textVerticalAlign: 'auto',//垂直对齐：auto，top,middle,bottom
        },
        tooltip: {
          trigger: 'axis'
        },
        legend: {
          data: ['Susceptible', 'Exposured', 'Infected','Quarantine' ,'Recovered']
        },
        xAxis: {
          name:'时间步',
          nameTextStyle: {
            fontWeight: 600,
            fontSize: 18
          }
        },
        yAxis: {
          type: 'value',
          name: '人数',
          nameTextStyle: {
            fontWeight: 600,
            fontSize: 18
          }
        }
      }
      this.chart.setOption(option)
      //从后端获取n_node和node_name信息
      let that=this
      axios.get('http://127.0.0.1:5000/get_nodes_info').then( function(response) {
        let info = response.data
        that.n_nodes = info['n_nodes']
        that.node_name = info['node_name']
      })
    },
    update_chart:function(){
      let that=this
      axios.get('http://127.0.0.1:5000/get_statis').then(function(response){
        let data = response.data
        that.seris=[]
        for(let i=0;i<that.n_nodes;i++)
          that.seris.push({name:that.node_name[i],data:[],type:'line'})
        for(let key in data){
          for(let k=0; k<that.seris.length;k++){
            that.series[k].data.push([key,data[key][that.node_name[k]]])
          }
        }
        that.chart.setOption({series:that.seris})
      })
    },
  }
}
</script>
<style scoped>
#chart{
  position: relative;
  width: 1400px;
  height:1000px;
  left:200px;
  top:50px;
}
</style>
