<template>
<div>
  <HeadNav></HeadNav>
  <leftMenu></leftMenu>
  <div id='container'>
  <el-tabs v-model="active" type="border-card">
    <el-tab-pane label="状态数统计" name=0>
      <div id="chart" ></div>
    </el-tab-pane>
    <el-tab-pane label="转化数统计" name=1>
      <div id="chart1" ></div>
    </el-tab-pane>
  </el-tabs>
  </div>
</div>
</template>

<script>
import * as echarts from 'echarts';
import axios from "axios";
import LeftMenu from "../components/LeftMenu";
import HeadNav from "../components/HeadNav";
import Utils from "./utils";

export default {
  name: "statis",
  components: {
    LeftMenu,
    HeadNav
  },
  data(){
    return{
      active:0,
      timer:null,
      chart:null,
      chart1:null,
      n_nodes:0,
      node_name:[],
      edges:[],
      series:null,
      series1:null,
      has_set_interval:false, //是否已设置过定时函数,
      on_simulation:false,
    };
  },
  created() {
    // this.$root.$on('on_simulation',()=>{    //监听仿真启动事件(启动or继续)
    //   if(this.has_set_interval===true)
    //     return
    //   this.timer=setInterval(this.update_chart,3000)
    //   this.has_set_interval=true
    // })
  },
  mounted() {
    let that=this
    this.$root.eventHub.$on('broadcast', (param)=>{
      console.log('broadcast',param)
    } )
    Utils.$on('start_simulation', function () {
      that.on_simulation=true
      that.timer=setInterval(that.update_chart,4000)
      console.log('received cmd start')
    })
    Utils.$on('continue_simulation', function () {
      that.on_simulation=true
      that.timer=setInterval(that.update_chart,4000)
    })
    Utils.$on('pause_simulation', function () {
      that.on_simulation=false
      clearTimeout(that.timer)
    })
    Utils.$on('reset', function () {
      console.log('received cmd reset')
      that.reset()
    })
    this.init()
    // this.$root.$on('on_simulation',()=>{    //监听仿真启动事件(启动or继续)
    //   if(this.has_set_interval===true)
    //     return
    //   this.timer=setInterval(this.update_chart,3000)
    //   this.has_set_interval=true
    // })
  },
  activated() {
    // if(this.has_set_interval===true)
    //   return
    // this.$root.$on('on_simulation',()=>{    //监听仿真启动事件(启动or继续)
    //   if(this.has_set_interval===true)
    //     return
    //   this.timer=setInterval(this.update_chart,3000)
    //   this.has_set_interval=true
    // })
  },
  methods:{
    reset:function () {
      clearTimeout(this.timer)
      this.series=[]
      this.chart.setOption({series:this.series})
      this.has_set_interval=false
    },
    init:function (){
      const setEchartWH = { //设置控制图表大小变量
        width: 1100,
        height: 640
      };
      this.chart = echarts.init(document.getElementById('chart'),null,setEchartWH )
      let option = {
        title: {
          top:30,
          text: '感染状态人数统计',//主标题
          textStyle:{
            color:"skyblue",//主标题颜色
            fontSize:'20',//主标题大小
          },
          sublink: 'http://oa.piesat.cn/seeyon/main.do?method=index',//副标题链接
          subtarget:'blank',//self/blank
          subtextStyle:{
            color:'#0f0',
            fontSize:'30'
          },
          left: 'center',//位置
          show: true,//是否显示true/false
          textAlign:'left',//水平对齐：auto/left,right,center
          textVerticalAlign: 'auto',//垂直对齐：auto，top,middle,bottom
        },
        tooltip: {
          trigger: 'axis'
        },
        legend: {
          data: []
        },
        xAxis: {
          name:'时间步',
          nameTextStyle: {
            fontWeight: 600,
            fontSize: 18
          }
        },
        yAxis: {
          type: 'value',
          name: '人数',
          nameTextStyle: {
            fontWeight: 600,
            fontSize: 18
          }
        }
      }
      this.chart1 = echarts.init(document.getElementById('chart1'),null,setEchartWH )
      let option1 = {
        title: {
          top:30,
          text: '状态转化人数统计',//主标题
          textStyle:{
            color:"skyblue",//主标题颜色
            fontSize:'20',//主标题大小
          },
          sublink: 'http://oa.piesat.cn/seeyon/main.do?method=index',//副标题链接
          subtarget:'blank',//self/blank
          subtextStyle:{
            color:'#0f0',
            fontSize:'30'
          },
          left: 'center',//位置
          show: true,//是否显示true/false
          textAlign:'left',//水平对齐：auto/left,right,center
          textVerticalAlign: 'auto',//垂直对齐：auto，top,middle,bottom
        },
        tooltip: {
          trigger: 'axis'
        },
        legend: {
          data: []
        },
        xAxis: {
          name:'时间步',
          nameTextStyle: {
            fontWeight: 600,
            fontSize: 18
          }
        },
        yAxis: {
          type: 'value',
          name: '人数',
          nameTextStyle: {
            fontWeight: 600,
            fontSize: 18
          }
        }
      }
      //从后端获取n_node和node_name信息
      let that=this
      axios.get('http://127.0.0.1:5000/get_nodes_info').then( function(response) {
        let info = response.data
        that.n_nodes = info['n_nodes']
        that.node_name = info['node_name']
        that.edges=info['edges']
        for(let x=0;x<that.n_nodes;x++)
          option.legend.data.push(that.node_name[x])
        for(let x=0;x<that.edges.length;x++){
          let node0=that.node_name[that.edges[x][0]]
          let node1=that.node_name[that.edges[x][1]]
          option1.legend.data.push(node0+'->'+node1)
        }
        that.chart.setOption(option)
        that.chart1.setOption(option1)
      })
    },
    update_chart:function(){
      let that=this
      axios.get('http://127.0.0.1:5000/get_statis').then(function(response){
        let data = response.data['status']
        let data1 = response.data['trasition']
        that.series=[]
        that.series1=[]
        for(let i=0;i<that.n_nodes;i++)
          that.series.push({name:that.node_name[i],data:[],type:'line'})
        for(let x=0;x<that.edges.length;x++){
          let node0=that.node_name[that.edges[x][0]]
          let node1=that.node_name[that.edges[x][1]]
          that.series1.push({name:node0+'->'+node1,data:[],type:'line'})
        }
        for(let key in data){
          for(let k=0; k<that.series.length;k++){
            that.series[k].data.push([key,data[key][that.node_name[k]]])
          }
        }
        for(let key in data1){
          for(let k=0; k<that.series1.length;k++){
            let node0=that.node_name[that.edges[k][0]]
            let node1=that.node_name[that.edges[k][1]]
            that.series1[k].data.push([key,data1[key][node0+'->'+node1]])
          }
        }
        that.chart.setOption({series:that.series})
        that.chart1.setOption({series:that.series1})
      })
    },
  }
}
</script>
<style scoped>

#container {
  position: relative;
  left:188px;
  z-index: 1;
  width: 1515px;  /*1515px;*/
  height: 500px;
  top:8px;
  border-radius: 4px;
  padding-left: 4px;
  padding-top: 4px;
  box-shadow: -2px -2px 4px #aaaaaa;
  background: #ffffff;
}

#chart{
  position: relative;
  left:0px;
  top:0px;
}

#chart1{
  position: relative;
  left:0px;
  top:0px;
}
</style>
