<template>
<div>
  <HeadNav></HeadNav>
  <leftMenu></leftMenu>
  <div id="chart" style="width: 900px;height:600px;left:200px;top:150px;"></div>
</div>
</template>

<script>
import * as echarts from 'echarts';
import axios from "axios";
import LeftMenu from "../components/LeftMenu";
import HeadNav from "../components/HeadNav";

export default {
  name: "statis",
  components: {
    LeftMenu,
    HeadNav
  },
  data(){
    return{
      mychart:null,
      series:null,
      has_set_interval:false //是否已设置过定时函数
    };
  },
  created() {
    console.log('created')
    this.$root.$on('on_simulation',()=>{    //监听仿真启动事件(启动or继续)
      if(this.has_set_interval===true)
        return
      setInterval(this.update_chart,3000)
      console.log('set set')
      this.has_set_interval=true
      this.seris=[{},{},{},{},{}]
    })
  },
  mounted() {
    this.init()
    this.$root.$on('on_simulation',()=>{    //监听仿真启动事件(启动or继续)
      if(this.has_set_interval===true)
        return
      setInterval(this.update_chart,3000)
      this.has_set_interval=true
      this.seris=[{},{},{},{},{}]
    })
  },
  activated() {
    if(this.has_set_interval===true)
      return
    this.$root.$on('on_simulation',()=>{    //监听仿真启动事件(启动or继续)
      if(this.has_set_interval===true)
        return
      setInterval(this.update_chart,3000)
      console.log('set set')
      this.has_set_interval=true
    })
  },
  methods:{
    init:function (){
      this.chart = echarts.init(document.getElementById('chart'))
      let option = {
        title: {
          top:30,
          text: '感染状态曲线',//主标题
          textStyle:{
            color:"skyblue",//主标题颜色
            fontSize:'20',//主标题大小
          },
          sublink: 'http://oa.piesat.cn/seeyon/main.do?method=index',//副标题链接
          subtarget:'blank',//self/blank
          subtextStyle:{
            color:'#0f0',
            fontSize:'30'
          },
          left: 'center',//位置
          show: true,//是否显示true/false
          textAlign:'left',//水平对齐：auto/left,right,center
          textVerticalAlign: 'auto',//垂直对齐：auto，top,middle,bottom
        },
        tooltip: {
          trigger: 'axis'
        },
        legend: {
          data: ['Susceptible', 'Exposured', 'Infected','Quarantine' ,'Recovered']
        },
        xAxis: {
          name:'时间步',
          nameTextStyle: {
            fontWeight: 600,
            fontSize: 18
          }
        },
        yAxis: {
          type: 'value',
          name: '人数',
          nameTextStyle: {
            fontWeight: 600,
            fontSize: 18
          }
        }
      }
      this.chart.setOption(option)
    },
    update_chart:function(){
      let that=this
      axios.get('http://127.0.0.1:5000/get_statis').then(function(response){
        let data = response.data
        that.seris=[{name:'Susceptible',data:[],type:'line'},{name:'Exposured',data:[],type:'line'},
          {name:'Infected',data:[],type:'line'},{name:'Quarantine',data:[],type:'line'},{name:'Recovered',data:[],type:'line'}]
        console.log(that.seris)
        for(let key in data){
          that.seris[0].data.push([key,data[key]['S']])
          that.seris[1].data.push([key,data[key]['E']])
          that.seris[2].data.push([key,data[key]['I']])
          that.seris[3].data.push([key,data[key]['Q']])
          that.seris[4].data.push([key,data[key]['R']])
        }
        that.chart.setOption({series:that.seris})

      })
    },
  }
}
</script>
<style scoped>

</style>
