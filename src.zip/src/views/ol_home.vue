<template>
  <div>
    <HeadNav></HeadNav>
    <leftMenu></leftMenu>
    <div @mouseleave="mouseleave" class="right-d" id="daoh" v-show="isshow" style="z-index: -10">
      <el-table :data="layer_name" stripe border style="width:100%" highlight-current-row>
        <el-table-column prop="name" label="图层名" align="center" min-width="80">
          　　</el-table-column>
        　　<el-table-column label="操作" align="center" min-width="100">
        　　　　<template v-slot="scope">
                    <el-button type="text" @click="show_layer(scope.$index)">显示</el-button>
                    <el-button type="text" @click="hide_layer(scope.$index)">隐藏</el-button>
        　　　　</template>
        　　</el-table-column>
      </el-table>
    </div>
    <div id="follow" class="follow"  @mouseenter="mousein()" style="height:22px;width:100%;background:#F0FFFF;">
       <div class="caret"></div>
    </div>
    <el-dialog class="dialog-file" id="dialog-file" :visible.sync="dialog_file_visible" center>
          <p>请选择本地文件上传（支持xlsx,csv,txt格式）</p>
          <p>文件内容应是数据集合，每条数据代表一个隔离点的信息，格式为(经度，维度，容量)</p>
          <p></p>
          <p></p>
          <input ref="fileRef" type="file" @change="fileChange">
          <div class="dialog_btn">
            <p></p>
            <p></p>
            <p></p>
            <p></p>
            <el-button @click="readFile">确认</el-button>
            <el-button @click="close">取消</el-button>
          </div>
    </el-dialog>
    <div id="popup0" class="ol-popup0">
      <p>请输入该隔离点的容量:</p>
      <div id="popup0-msg"></div>
      <div id="popup0-content"></div>
      <input id="popup0-input">
      <a href="#" id="popup0-button" class="ol-popup0-button"></a>
    </div>
    <div id="popup1" class="ol-popup1">
      <a href="#" id="popup1-closer" class="ol-popup1-closer"></a>
      <div id="popup1-msg"></div>
      <div id="popup1-content11"></div>
      <div id="popup1-content12"></div>
      <a href="#" id="popup1-edit" class="ol-popup1-edit"></a>
      <a href="#" id="popup1-delete" class="ol-popup1-delete"></a>
    </div>
    <div id="popup2" class="ol-popup2">
      <a href="#" id="popup2-closer" class="ol-popup2-closer"></a>
      <p>请输入容量</p>
      <div id="popup2-msg"></div>
      <div id="popup2-content"></div>
      <input id="popup2-input">
      <a href="#" id="popup2-button" class="ol-popup2-button"></a>
    </div>
    <el-button v-on:click="start_simulation" class='button' type="primary" >启动仿真</el-button>
    <el-button v-on:click="pause" class='button' type="primary" icon="el-icon-caret-right">暂停</el-button>
    <el-button v-on:click="go_on" class='button' type="primary" icon="el-icon-caret-right">继续</el-button>
    <el-button v-on:click="hospital_mode" class='button' type="primary" icon="el-icon-bell">开启医疗资源部署</el-button>
    <el-button v-on:click="go_on" class='button' type="primary" >确认配置方案</el-button>
  <div id="olmap" ref="olmap" style="width: 100%; height: 700px;position: absolute;">
    <el-select class="mapselect" v-model="value" placeholder="切换地图底图" @change="changeBaseMap(value)">
      <el-option-group v-for="group in options" :key="group.label" :label="group.label">
        <el-option
          v-for="item in group.options"
          :key="item.value"
          :label="item.label"
          :value="item.value"
        ></el-option>
      </el-option-group>
    </el-select>
  </div>
  </div>
</template>

<script>
import Map from 'ol/Map'
import View from 'ol/View'
import Feature from 'ol/Feature'
import Point from 'ol/geom/Point'
import TileLayer from 'ol/layer/Tile'
import { OSM, TileArcGISRest } from 'ol/source/OSM'
import Overlay from 'ol/Overlay';
import VectorLayer from 'ol/layer/Vector';
import VectorSource from 'ol/source/Vector';
import {Fill, Stroke, Style,Circle} from 'ol/style';
import Heatmap from "ol/layer/Heatmap";
import XYZ from 'ol/source/XYZ'
import { transform } from 'ol/proj'
import mapSources from './modules/maplist'

import HeadNav from "../components/HeadNav";
import LeftMenu from "../components/LeftMenu";
import TileWMS from "ol/source/TileWMS";
import axios from 'axios'

export default {
  components: {
    LeftMenu,
    HeadNav
  },
  data() {
    return {
      isshow:false,
      dialog_file_visible:false,
      options: mapSources.basemapLabel,
      value: '',
      control:null,
      googledz: mapSources.googledz,
      googledx: mapSources.googledx,
      googlewx: mapSources.googlewx,
      tdtdz: mapSources.tdtdz,
      tdtlabeldz: mapSources.tdtlabeldz,
      tdtwx: mapSources.tdtwx,
      tdtlabelwx: mapSources.tdtlabelwx,
      baidudz: mapSources.baidudz,
      baiduwx: mapSources.baiduwx,
      baidulabelwx: mapSources.baidulabelwx,
      gaodedz: mapSources.gaodedz,
      gaodewx: mapSources.gaodewx,
      gaodelabelwx: mapSources.gaodelabelwx,
      qqmapdz: mapSources.qqmapdz,
      qqmapdx: mapSources.qqmapdx,
      qqmaplabledx: mapSources.qqmaplabledx,
      qqmapwx: mapSources.qqmapwx,
      qqmaplablewx: mapSources.qqmaplablewx,
      geoqcs: mapSources.geoqcs,
      geoqns: mapSources.geoqns,
      geoqhs: mapSources.geoqhs,
      geoqlh: mapSources.geoqlh,
      proj: 'EPSG:4326', //定义wgs84地图坐标系
      proj_m: 'EPSG:3857', //定义墨卡托地图坐标系
      map: null,
      mapLayer: null,
      mapLayerlabel: null,
      //hospital相关
      hospitals:null, //hospital:{lon,lat}
      hospital_valid:null,
      hospital_cnt:0,
      hospital_mode_on:false,
      hosp_layer:null,
      heat_E:null,
      heat_I:null,
      heat_R:null,
      //ui相关
      container0: null,
      content0: null,
      done_button0: null,
      input_capacity0: null,
      msg0: null,

      container1: null,
      content1: null,
      edit_button1: null,
      delete_button1: null,
      msg1: null,
      closer1: null,

      container2: null,
      content2: null,
      done_button2: null,
      msg2: null,
      input_capacity2: null,
      closer2: null,

      overlay0:null,
      overlay1:null,
      overlay2:null,

      selected_coordinate:null,//当前选中的坐标
      selected_hosp:null,  //当前选中的hospital(featureObject)
      selected_id:-1,    //当前选中的hospital id

      on_simulation:false,  //当前是否处于仿真状态
      T:-1,  //仿真时长
      current_step:0,
      has_started:false,  //标记是否已经启动过
      layer_name:[],
      has_on:false,  //是否已监听
    }
  },
  created() {
  },
  mounted() {
    //初始化
    this.init()
    //监听添加图层事件(与upload_show_layers同步)
    // this.$root.$on('update_layers', (layers) => {
    //   //添加新图层
    //   this.map.setLayers([layers])
    //   this.map.addLayer(this.heat_E)
    //   this.map.addLayer(this.heat_I)
    //   this.map.addLayer(this.heat_R)
    //   this.map.addLayer(this.hosp_layer)
    // })
  },
  activated() {  //每次重新进入页面时触发,重新挂载layers
    if(this.has_on===true)
      return
    this.has_on=true
    //监听添加图层事件(与upload_show_layers同步)
    this.$root.$on('update_layers', (args) => {
      let layers=args['layers']
      let lyr_name=args['layer_names']
      //添加新图层
      this.map.getLayers().clear()
      this.map.addLayer(this.mapLayer)
      this.map.addLayer(this.mapLayerlabel)
      let that=this
      layers.forEach(function (lyr) {
        that.map.addLayer(lyr)
      })
      this.map.addLayer(this.heat_E)
      this.map.addLayer(this.heat_I)
      this.map.addLayer(this.heat_R)
      this.map.addLayer(this.hosp_layer)
      console.log(lyr_name)
      this.layer_name=lyr_name
      this.layer_name.push({'name':'heat_E'},{'name':'heat_I'},{'name':'heat_R'},{'name':'hospital'})
    })
  },
  deactivated() {
    if(this.on_simulation===true){
      let that=this
      setTimeout(function (){
        that.$root.$emit('on_simulation')
      },1000)
    }
  },
  methods: {
    init: function(){
      //初始化交互相关
      this.control=document.getElementById("control")
      this.container0 = document.getElementById('popup0');
      this.content0 = document.getElementById('popup0-content');
      this.done_button0=document.getElementById('popup0-button');
      this.input_capacity0=document.getElementById('popup0-input');
      this.msg0=document.getElementById('popup0-msg');

      this.container1 = document.getElementById('popup1');
      this.content11 = document.getElementById('popup1-content11');
      this.content12 = document.getElementById('popup1-content12');
      this.edit_button1=document.getElementById('popup1-edit');
      this.delete_button1=document.getElementById('popup1-delete');
      this.msg1=document.getElementById('popup1-msg');
      this.closer1=document.getElementById('popup1-closer');

      this.container2 = document.getElementById('popup2');
      this.content2 = document.getElementById('popup2-content');
      this.done_button2=document.getElementById('popup2-button');
      this.msg2=document.getElementById('popup2-msg');
      this.input_capacity2=document.getElementById('popup2-input');
      this.closer2=document.getElementById('popup2-closer');

      this.closer1.onclick =this.cl1_click
      this.closer2.onclick =this.cl2_click
      this.done_button0.onclick =this.dn0_click
      this.done_button2.onclick =this.dn2_click
      this.edit_button1.onclick =this.ed1_click
      this.delete_button1.onclick =this.del1_click

      this.overlay0=new Overlay({
        element: this.container0,
        autoPan: {
          animation: {
            duration: 250,
          },
        },
      });
      this.overlay1=new Overlay({
        element: this.container1,
        autoPan: {
          animation: {
            duration: 250,
          },
        },
      });
      this.overlay2=new Overlay({
        element: this.container2,
        autoPan: {
          animation: {
            duration: 250,
          },
        },
      });
      //初始化map对象
      this.map = new Map({
        target: 'olmap',
        projection: this.proj,
        overlays: [this.overlay0,this.overlay1,this.overlay2],
        view: new View({
          projection:'EPSG:4326',
          center:[121.473701 ,31.230416],
          zoom: 5
        })
      })
      //初始化地图图层
      this.mapLayer = new TileLayer({
        source: this.gaodedz,
        projection: this.proj
      })
      //初始化标签图层
      this.mapLayerlabel = new TileLayer({
        source: this.tdtlabelwx,
        projection: this.proj
      })
      //初始化热力图图层
      this.heat_E = new Heatmap({   //heatmap图层
        source:new VectorSource({}),
        blur: 15,
        radius:5,
        opacity: .5
      })
      this.heat_I = new Heatmap({
        source:new VectorSource({}),
        blur: 15,
        radius:5,
        opacity: .5
      })
      this.heat_R = new Heatmap({
        source:new VectorSource({}),
        blur: 15,
        radius:5,
        opacity: .5
      })
      //初始化hosp图层
      let hosp_source=new VectorSource({});
      this.hosp_layer=new VectorLayer({     //hospital图层
        source: hosp_source,
        style: new Style({
          image: new Circle({
            radius: 15,
            fill: new Fill({color: '#666666'}),
            stroke: new Stroke({color: '#bada55', width: 1}),
          }),
        }),
      })
      //命名图层
      this.heat_E.set('name','heat_E')
      this.heat_I.set('name','heat_I')
      this.heat_R.set('name','heat_R')
      this.hosp_layer.set('name','hospital')
      //将图层加载到地图对象
      this.map.addLayer(this.mapLayer)
      this.map.addLayer(this.mapLayerlabel)
      this.map.addLayer(this.heat_E)
      this.map.addLayer(this.heat_I)
      this.map.addLayer(this.heat_R)
      this.map.addLayer(this.hosp_layer)
      //为map注册事件
      this.map.on('dblclick',this.set_a_hospital);
      this.map.on('singleclick',this.check_a_hospital);
      this.layer_name.push({'name':'heat_E'},{'name':'heat_I'},{'name':'heat_R'},{'name':'hospital'})
      //初始化hospital相关变量
      this.hospitals=new Array()
      this.hospital_valid=new Array()
    },
    //鼠标移入
    mousein:function() {
      //clearTimeout(this.timer);
      this.isshow = true;
    },
    //鼠标移出
    mouseleave:function (){
      this.timer = setTimeout(() => {
        this.isshow = false;
      }, 100);
    },
    /******************地图切换方法***************/
    changeBaseMap: function(value) {
      console.log(value)
      this.map.removeLayer(this.mapLayer)
      this.map.removeLayer(this.mapLayerlabel)
      switch (value) {
        case 'googledz':
          this.mapLayer = new TileLayer({
            source: this.googledz,
            projection: this.proj
          })
          this.map.addLayer(this.mapLayer)
          break;
        case 'googledx':
          this.mapLayer = new TileLayer({
            source: this.googledx,
            projection: this.proj
          })
          this.map.addLayer(this.mapLayer)
          break;
        case 'googlewx':
          this.mapLayer = new TileLayer({
            source: this.googlewx,
            projection: this.proj
          })
          this.mapLayerlabel = new TileLayer({
            source: this.tdtlabeldz,
            projection: this.proj
          })
          this.map.addLayer(this.mapLayer)
          this.map.addLayer(this.mapLayerlabel)
          break;
        case 'tdtdz':
          this.mapLayer = new TileLayer({
            source: this.tdtdz,
            projection: this.proj
          })
          this.mapLayerlabel = new TileLayer({
            source: this.tdtlabeldz,
            projection: this.proj
          })
          this.map.addLayer(this.mapLayer)
          this.map.addLayer(this.mapLayerlabel)
          break;
        case 'tdtwx':
          this.mapLayer = new TileLayer({
            source: this.tdtwx,
            projection: this.proj
          })
          this.mapLayerlabel = new TileLayer({
            source: this.tdtlabelwx,
            projection: this.proj
          })
          this.map.addLayer(this.mapLayer)
          this.map.addLayer(this.mapLayerlabel)
          break;
        case 'gaodedz':
          this.mapLayer = new TileLayer({
            source: this.gaodedz,
            projection: this.proj
          })
          this.map.addLayer(this.mapLayer)
          console.log(this.map.getLayers())
          break;
        case 'gaodewx':
          this.mapLayer = new TileLayer({
            source: this.gaodewx,
            projection: this.proj
          })
          this.mapLayerlabel = new TileLayer({
            source: this.gaodelabelwx,
            projection: this.proj
          })
          this.map.addLayer(this.mapLayer)
          this.map.addLayer(this.mapLayerlabel)
          break;
        case 'baidudz':
          this.mapLayer = new TileLayer({
            source: this.baidudz,
            projection: this.proj
          })
          this.map.addLayer(this.mapLayer)
          break;
        case 'baiduwx':
          this.mapLayer = new TileLayer({
            source: this.baiduwx,
            projection: this.proj
          })
          this.mapLayerlabel = new TileLayer({
            source: this.baidulabelwx,
            projection: this.proj
          })
          this.map.addLayer(this.mapLayer)
          this.map.addLayer(this.mapLayerlabel)
          break;
        case 'qqmapdz':
          this.mapLayer = new TileLayer({
            source: this.qqmapdz,
            projection: this.proj
          })
          this.map.addLayer(this.mapLayer)
          break;
        case 'qqmapdx':
          this.mapLayer = new TileLayer({
            source: this.qqmapdx,
            projection: this.proj
          })
          this.mapLayerlabel = new TileLayer({
            source: this.qqmaplabledx,
            projection: this.proj
          })
          this.map.addLayer(this.mapLayer)
          this.map.addLayer(this.mapLayerlabel)
          break;
        case 'qqmapwx':
          this.mapLayer = new TileLayer({
            source: this.qqmapwx,
            projection: this.proj
          })
          this.mapLayerlabel = new TileLayer({
            source: this.qqmaplablewx,
            projection: this.proj
          })
          this.map.addLayer(this.mapLayer)
          this.map.addLayer(this.mapLayerlabel)
          break;
        case 'geoqcs':
          this.mapLayer = new TileLayer({
            source: this.geoqcs,
            projection: this.proj
          })
          this.map.addLayer(this.mapLayer)
          break;
        case 'geoqns':
          this.mapLayer = new TileLayer({
            source: this.geoqns,
            projection: this.proj
          })
          this.map.addLayer(this.mapLayer)
          break;
        case 'geoqhs':
          this.mapLayer = new TileLayer({
            source: this.geoqhs,
            projection: this.proj
          })
          this.map.addLayer(this.mapLayer)
          break;
        case 'geoqlh':
          this.mapLayer = new TileLayer({
            source: this.geoqlh,
            projection: this.proj
          })
          this.map.addLayer(this.mapLayer)
          break;
      }
      this.map.removeLayer(this.heat_E)
      this.map.addLayer(this.heat_E)
      this.map.removeLayer(this.heat_I)
      this.map.addLayer(this.heat_I)
      this.map.removeLayer(this.heat_R)
      this.map.addLayer(this.heat_R)
      //保证hosp_layer一直处于最上层
      this.map.removeLayer(this.hosp_layer)
      this.map.addLayer(this.hosp_layer)

    },
    start_simulation:function(){  //开启仿真
      if(this.on_simulation===true)
        return
      //检查仿真信息是否完整(目前没有)

      this.has_started=true
      this.T=100
      this.on_simulation=true
      //向后台发送启动仿真的消息
      axios.get('http://127.0.0.1:5000/begin',{
        params:{
          total_step:this.T
        }
      })
      //设置定时函数，定时从后端获取heatmap
      let that=this
      setInterval(function (){
        axios.get('http://127.0.0.1:5000/get_heat').then( function(response) {
          let data = response.data
          //更新ol的Heatmap
          let E=data['E']
          let features = []
          for(let key in E){
            features.push(new Feature({geometry: new Point([121.12548861+(121.66357585-121.12548861)*E[key]['lon'],31.0827875+(31.41700379-31.0827875)*E[key]['lat']]),weight:E[key]['cnt']}));
          }
          that.heat_E.getSource().clear()
          that.heat_E.getSource().addFeatures(features)

          let I=data['I']
          features = [];
          for(let key in I){
            features.push(new Feature({geometry: new Point([121.12548861+(121.66357585-121.12548861)*I[key]['lon'],31.0827875+(31.41700379-31.0827875)*I[key]['lat']]),weight:I[key]['cnt']}));
          }
          that.heat_I.getSource().clear()
          that.heat_I.getSource().addFeatures(features)

          let R=data['R']
          features = [];
          for(let key in R){
            features.push(new Feature({geometry: new Point([121.12548861+(121.66357585-121.12548861)*R[key]['lon'],31.0827875+(31.41700379-31.0827875)*R[key]['lat']]),weight:R[key]['cnt']}));
          }
          that.heat_R.getSource().clear()
          that.heat_R.getSource().addFeatures(features)

        }).catch(function (error) {
          //alert('Error ' + error);
        })
        },3000)
      //广播仿真启动的消息
      this.$root.$emit('on_simulation')
      console.log('emit emit')
    },
    pause:function(){
      this.on_simulation=false
      axios.post('http://127.0.0.1:5000/paus')
    },
    go_on:function(){
      if(this.has_started===false)
        return
      axios.post('http://127.0.0.1:5000/continue')
      this.on_simulation=true
    },
    hospital_mode:function(){
      this.pause()
      this.dialog_file_visible=true
    },
    set_a_hospital:function(e){                          //双击坐标添加一个hospital
      if(this.hospital_mode_on===false)
        return
      this.selected_coordinate=e.coordinate
      let lon=e.coordinate[0]
      let lat=e.coordinate[1]
      let feature=new Feature({'geometry': new Point([lon,lat])});
      feature.setId(this.hospital_cnt);
      this.hosp_layer.getSource().addFeature(feature);
      this.overlay0.setPosition(e.coordinate)
    },
    check_a_hospital:function(e) {
      //用户选中某个hosp
      this.selected_coordinate=e.coordinate
      let selected_hosps=this.map.getFeaturesAtPixel(e.pixel, function (layer) {
        if(layer.get('name')==='hospital')
          return true
        else
          return false
      })
      if(selected_hosps.length===0)
        return
      this.selected_hosp=selected_hosps[0]
      this.selected_id=this.selected_hosp.getId()
      //弹出选项框
      this.overlay1.setPosition(e.coordinate)
      //this.content11.innerHTML='<p>容量：</p><code>'+String(this.hospitals[this.selected_id]['capacity'])+'</code>'
      this.content11.innerHTML='容量:     '+String(this.hospitals[this.selected_id]['capacity'])
      let q=Math.ceil(Math.random()*this.hospitals[this.selected_id]['capacity']*0.2)
      this.content12.innerHTML='当前收容人数:      '+String(q)
    },
    cl1_click:function () {
      this.overlay1.setPosition(undefined)
      this.closer1.blur()
      return false
    },
    cl2_click:function () {
      this.overlay2.setPosition(undefined)
      this.closer2.blur()
      return false
    },
    dn0_click:function(){
      let number=parseInt(this.input_capacity0.value,10)
      if(isNaN(number)){
        this.msg0.innerHTML="输入无效，请输入正整数"
        return
      }
      let lon=this.selected_coordinate[0]
      let lat=this.selected_coordinate[1]
      this.hospitals[this.hospital_cnt]={'lon':lon,'lat':lat,'capacity':number};
      this.hospital_valid[this.hospital_cnt]=1;
      this.hospital_cnt+=1;
      this.msg0.innerHTML="编辑完成";
      this.overlay0.setPosition(undefined);
      //done_button0.blur();
      return false;
    },
    dn2_click:function(){
      let number=parseInt(this.input_capacity2.value,10);
      if(isNaN(number)){
        this.msg2.innerHTML="输入无效，请输入数字";
        return;
      }
      this.hospitals[this.selected_id]['capacity']=number;
      this.msg2.innerHTML="编辑完成";
//   overlay2.setPosition(undefined);
//   done_button2.blur();
      return false;
    },
    ed1_click:function(){
      if(this.hospital_mode===false){
        this.msg1.innerHTML='请开启医疗资源配置模式!';
        return;
      }
      this.overlay1.setPosition(undefined);
      this.overlay2.setPosition(this.selected_coordinate);
    },
    del1_click:function(){
      if(this.hospital_mode===false){
        this.msg1.innerHTML='请开启医疗资源配置模式!'
        return
      }
      this.hospital_valid[this.selected_id]=0
      this.hosp_layer.getSource().removeFeature(this.selected_hosp)
      this.msg1.innerHTML='已移除该隔离点'
      this.overlay1.setPosition(undefined)
    },
    fileChange:function(){

    },
    readFile:function(){
      let dlon=121.66357585-121.12548861
      let dlat=31.41700379-31.0827875
      for(let i=0;i<20;i++){
        let lon=121.12548861+0.25*dlon+Math.random()*dlon*0.5
        let lat=31.0827875+0.25*dlat+Math.random()*dlat*0.5
        let feature=new Feature({'geometry': new Point([lon,lat])});
        feature.setId(this.hospital_cnt)
        this.hospitals[this.hospital_cnt]={'lon':lon,'lat':lat,'capacity':150}
        this.hospital_cnt+=1
        this.hosp_layer.getSource().addFeature(feature)
      }
      this.hospital_mode_on=true
      this.dialog_file_visible=false
    },
    close:function(){
      this.dialog_file_visible=false
    },
    show_layer:function(index){
      let name=this.layer_name[index]['name']
      let layer=null
      this.map.getLayers().forEach(function (lyr) {
        if (name === lyr.get('name')) {
          layer = lyr
        }
      })
      layer.setVisible(true)

    },
    hide_layer:function(index){
      let name=this.layer_name[index]['name']
      let layer=null
      this.map.getLayers().forEach(function (lyr) {
        if (name === lyr.get('name')) {
          layer = lyr
        }
      })
      layer.setVisible(false)
    },
  }
}
</script>

<style scoped>
#olmap {
  position: relative;
  z-index: 1;
}
.mapselect {
  position: absolute;
  top: 3%;
  right: 2%;
  z-index: 2;
}
.ol-popup0 {
  position: absolute;
  background-color: white;
  box-shadow: 0 1px 4px rgba(0,0,0,0.2);
  padding: 15px;
  border-radius: 10px;
  border: 1px solid #cccccc;
  bottom: 12px;
  left: -50px;
  min-width: 280px;
}
.ol-popup0:after, .ol-popup:before {
  top: 100%;
  border: solid transparent;
  content: " ";
  height: 0;
  width: 0;
  position: absolute;
  pointer-events: none;
}
.ol-popup0:after {
  border-top-color: white;
  border-width: 10px;
  left: 48px;
  margin-left: -10px;
}
.ol-popup0:before {
  border-top-color: #cccccc;
  border-width: 11px;
  left: 48px;
  margin-left: -11px;
}
.ol-popup0-button {
  text-decoration: none;
  position: absolute;
  top: 25px;
  right: 8px;
}
.ol-popup0-button:after {
  content: "√";
}


.ol-popup1 {
  position: absolute;
  background-color: white;
  box-shadow: 0 1px 4px rgba(0,0,0,0.2);
  padding: 15px;
  border-radius: 10px;
  border: 1px solid #cccccc;
  bottom: 12px;
  left: -50px;
  min-width: 280px;
}
.ol-popup1:after, .ol-popup:before {
  top: 100%;
  border: solid transparent;
  content: " ";
  height: 0;
  width: 0;
  position: absolute;
  pointer-events: none;
}
.ol-popup1:after {
  border-top-color: white;
  border-width: 10px;
  left: 48px;
  margin-left: -10px;
}
.ol-popup1:before {
  border-top-color: #cccccc;
  border-width: 11px;
  left: 48px;
  margin-left: -11px;
}
.ol-popup1-closer {
  text-decoration: none;
  position: absolute;
  top: 2px;
  right: 8px;
}
.ol-popup1-closer:after {
  content: "✖";
}
.ol-popup1-edit {
  text-decoration: none;
  position: absolute;
  top: 25px;
  right: 8px;
}
.ol-popup1-edit:after {
  content: "编辑";
}
.ol-popup1-delete {
  text-decoration: none;
  position: absolute;
  top: 50px;
  right: 8px;
}
.ol-popup1-delete:after {
  content: "移除";
}

.ol-popup2 {
  position: absolute;
  background-color: white;
  box-shadow: 0 1px 4px rgba(0,0,0,0.2);
  padding: 15px;
  border-radius: 10px;
  border: 1px solid #cccccc;
  bottom: 12px;
  left: -50px;
  min-width: 280px;
}
.ol-popup2:after, .ol-popup:before {
  top: 100%;
  border: solid transparent;
  content: " ";
  height: 0;
  width: 0;
  position: absolute;
  pointer-events: none;
}
.ol-popup2:after {
  border-top-color: white;
  border-width: 10px;
  left: 48px;
  margin-left: -10px;
}
.ol-popup2:before {
  border-top-color: #cccccc;
  border-width: 11px;
  left: 48px;
  margin-left: -11px;
}
.ol-popup2-closer {
  text-decoration: none;
  position: absolute;
  top: 2px;
  right: 8px;
}
.ol-popup2-closer:after {
  content: "✖";
}
.ol-popup2-button {
  text-decoration: none;
  position: absolute;
  top: 25px;
  right: 8px;
}
.ol-popup2-button:after {
  content: "√";
}

.caret {
  display: inline-block;
  width: 0;
  height: 0;
  border-left: 10px solid transparent;
  border-top: 10px solid;
  border-right: 10px solid transparent;
}
</style>
