<template>
  <div>
    <HeadNav></HeadNav>
    <leftMenu></leftMenu>
    <div class="control-panel" v-drag id="drag" v-if="isShowDrag">
      <label style="position: relative;left: 85px;height:26px;top:3px;">图层选项</label>
      <div class="control_options" style="position: relative;left:13px;">
        <el-button-group >
          <el-button size="mini" @click="show_heat_options">热力图</el-button>
          <el-button size="mini" @click="show_grid_options">网格图</el-button>
          <el-button size="mini" @click="show_trip_options">旅行图</el-button>
        </el-button-group>
      </div>
      <div class="control-container">
        <div class="heat_options_content" id="heat_options_content" v-show="this.control_show===0">
        </div>
        <div class="grid_content" v-show="this.control_show===1"></div>
        <div class="trip_content" v-show="this.control_show===2"></div>
      </div>
      <form style="position: relative;left:20px;top:45px;">
        <label for="radius">radius size</label>
        <input id="radius" type="range" min="1" max="50" step="1" value="5"/>
        <label for="blur">blur size</label>
        <input id="blur" type="range" min="1" max="50" step="1" value="15"/>
      </form>
    </div>
    <div class="button_group">
    <el-button v-on:click="start_simulation" class='button' >启动仿真</el-button>
    <el-button v-on:click="pause" class='button' >暂停</el-button>
    <el-button v-on:click="go_on" class='button' >继续</el-button>
    </div>
  <div id="olmap" ref="olmap">
    <el-select class="mapselect" v-model="value" placeholder="切换地图底图" @change="changeBaseMap(value)">
      <el-option-group v-for="group in options" :key="group.label" :label="group.label">
        <el-option
          v-for="item in group.options"
          :key="item.value"
          :label="item.label"
          :value="item.value"
        ></el-option>
      </el-option-group>
    </el-select>
  </div>
    <el-dialog  :visible.sync="dialog_visible" center  >
      <div style="height:500px;"></div>
      <el-button style="margin-top:12px;" @click="sure_to_reset">确认</el-button>
      <div style="width:70px"></div>
      <el-button id="next" style="margin-top:12px;" @click="close">取消</el-button>
    </el-dialog>
  </div>
</template>

<script>
import Map from 'ol/Map'
import View from 'ol/View'
import Feature from 'ol/Feature'
import Point from 'ol/geom/Point'
import TileLayer from 'ol/layer/Tile'
import { OSM, TileArcGISRest } from 'ol/source/OSM'
import Overlay from 'ol/Overlay';
import VectorLayer from 'ol/layer/Vector';
import VectorSource from 'ol/source/Vector';
import {Fill, Stroke, Style,Circle} from 'ol/style';
import Heatmap from "ol/layer/Heatmap";
import XYZ from 'ol/source/XYZ'
import { transform,fromLonLat } from 'ol/proj'
import mapSources from './modules/maplist'
import HeadNav from "../components/HeadNav";
import LeftMenu from "../components/LeftMenu";
import TileWMS from "ol/source/TileWMS";
import axios from 'axios'
import * as echarts from 'echarts';
import 'echarts/extension/bmap/bmap'
import ADLayer from 'openlayers_echart'
import EChartsLayer from 'ol-echarts'
import Utils from "./utils";


export default {
  components: {
    LeftMenu,
    HeadNav,
  },
  data() {
    return {
      timer:null,
      dialog_visible:false,
      blur:null,
      radius:null,
      mutex:0,
      onSlide:false,
      isShowDrag:true,
      show_panel:0,
      pie:null,
      chart_option:null,
      chart:null,
      grid_size:1000,
      lonExtent:null,
      latExtent:null,
      cellSizelonlat:null,
      cellCount:null,
      isshow:false,
      options: mapSources.basemapLabel,
      value: '',
      control:null,
      arcgis:mapSources.arcgis,
      googledz: mapSources.googledz,
      googledx: mapSources.googledx,
      googlewx: mapSources.googlewx,
      tdtdz: mapSources.tdtdz,
      tdtlabeldz: mapSources.tdtlabeldz,
      tdtwx: mapSources.tdtwx,
      tdtlabelwx: mapSources.tdtlabelwx,
      baidudz: mapSources.baidudz,
      baiduwx: mapSources.baiduwx,
      baidulabelwx: mapSources.baidulabelwx,
      gaodedz: mapSources.gaodedz,
      gaodewx: mapSources.gaodewx,
      gaodelabelwx: mapSources.gaodelabelwx,
      qqmapdz: mapSources.qqmapdz,
      qqmapdx: mapSources.qqmapdx,
      qqmaplabledx: mapSources.qqmaplabledx,
      qqmapwx: mapSources.qqmapwx,
      qqmaplablewx: mapSources.qqmaplablewx,
      geoqcs: mapSources.geoqcs,
      geoqns: mapSources.geoqns,
      geoqhs: mapSources.geoqhs,
      geoqlh: mapSources.geoqlh,
      proj: 'EPSG:4326', //定义wgs84地图坐标系
      proj_m: 'EPSG:3857', //定义墨卡托地图坐标系
      map: null,
      mapLayer: null,
      mapLayerlabel: null,

      n_heats:null,
      heat_name:null,
      heat_layers:[],

      selected_coordinate:null,//当前选中的坐标
      selected_hosp:null,  //当前选中的hospital(featureObject)
      selected_id:-1,    //当前选中的hospital id

      on_simulation:false,  //当前是否处于仿真状态
      T:-1,  //仿真时长
      current_step:0,
      has_started:false,  //标记是否已经启动过
      layer_name:[],
      has_on:false,  //是否已监听
      control_show:0,

      infected_model_form:null,
    }
  },
  //自定义指令
  directives: {
    drag: {
      // 指令的定义
      bind: function(el,binding,vnode) {
        let oDiv = el;  // 获取当前元素
        oDiv.onmousedown = (e) => {
          // 算出鼠标相对元素的位置
          let disX = e.clientX - oDiv.offsetLeft;
          let disY = e.clientY - oDiv.offsetTop;

          document.onmousemove = (e) => {
            if(vnode.context.onSlide===true)
              return
            // 用鼠标的位置减去鼠标相对元素的位置，得到元素的位置
            let left = e.clientX - disX;
            let top = e.clientY - disY;

            oDiv.style.left = left + 'px';
            oDiv.style.top = top + 'px';

          };

          document.onmouseup = (e) => {
            vnode.context.onSlide=false
            document.onmousemove = null;
            document.onmouseup = null;
          }
        }
      }
    }
  },
  created() {
  },
  mounted() {
    //挂载点击事件，从而实现动态为控件绑定onclick
    window.show_hide_layer = this.show_hide_layer
    //初始化
    this.init()
  },
  deactivated() {
    let that=this
    //向statis页面发送仿真启动的消息
    if(this.on_simulation===true){
      setTimeout(function (){
        that.$root.$emit('on_simulation')
      },1000)
    }
    //向感染模型编辑页面发送表格
    setTimeout(function (){
      that.$root.$emit('infected_model_form',{'table_data':that.infected_model_form})
    },1000)
  },
  methods: {
    init: function(){
      // document.body.onmousemove = function() {
      //   this.onSlide=true
      // }
      document.body.onmouseup = function() {
        this.onSlide=false
        console.log('released')
      }
      this.blur = document.getElementById('blur')
      this.radius = document.getElementById('radius')
      this.blur.addEventListener('input', this.blurHandlerInput)
      //this.blur.addEventListener('change', this.blurHandler)
      this.radius.addEventListener('input', this.radiusHandlerInput)
      //this.radius.addEventListener('change', this.radiusHandler)
      //接收infected_model表格，传给edit_infected_model界面
      this.infected_model_form=this.$route.params.table_data
      console.log('form in ol_home:',this.infected_model_form)
      //初始化map对象
      this.map = new Map({
        target: 'olmap',
        projection: this.proj,
        view: new View({
          projection:'EPSG:3857',
          center:fromLonLat([121.4806,31.2167]),
          zoom: 11
        })
      })
      //初始化地图图层
      this.mapLayer = new TileLayer({
        source: this.gaodedz,
        projection: this.proj
      })
      //初始化标签图层
      this.mapLayerlabel = new TileLayer({
        source: this.tdtlabelwx,
        projection: this.proj
      })
      this.map.addLayer(this.mapLayer)
      this.map.addLayer(this.mapLayerlabel)
      //从后端获取n_node和node_name信息
      let that=this
      axios.get('http://127.0.0.1:5000/get_nodes_info').then( function(response) {
        let info = response.data
        that.n_heats=info['n_nodes']
        that.heat_name=info['node_name']
        //初始化热力图图层
        for(let i=0;i<that.heat_name.length;i++){
          let heat_layer=new Heatmap({   //heatmap图层
            source:new VectorSource({}),
            blur: parseInt(that.blur.value, 10),
            radius: parseInt(that.radius.value, 10),
            opacity: .5
          })
          heat_layer.set('name',that.heat_name[i])
          that.heat_layers.push(heat_layer)
          that.map.addLayer(that.heat_layers[i])
        }
        //在下拉框显示图层名称
        for(let i=0;i<that.n_heats;i++)
          that.layer_name.push({'name':that.heat_name[i]})
        //初始化图层选项框（动态创建条目）
        for(let i=0;i<that.n_heats;i++){
          let heat_options_contents=document.getElementById('heat_options_content')
          let div_item=document.createElement('div')
          let label=document.createElement('label')
          label.innerText=that.heat_name[i]
          label.style.position='relative'
          label.style.color='black'
          label.style.fontWeight='bold'
          let label_text=document.createElement('label')
          label_text.style.position='relative'
          label_text.style.right=String(-86)+'px'
          label_text.style.color='black'
          label_text.setAttribute('class','control-item-text')
          label_text.innerText='显示/隐藏'
          let input=document.createElement('input')
          input.setAttribute('type','checkbox')
          input.setAttribute('class','control-checkbox')
          input.setAttribute('id',that.heat_name[i])
          input.setAttribute('onclick',"show_hide_layer(this)")
          input.style.position='relative'
          input.style.right=String(-90)+'px'
          input.style.top=String(2)+'px'
          div_item.appendChild(label)
          div_item.appendChild(label_text)
          div_item.appendChild(input)
          div_item.style.position='relative'
          div_item.style.top=String(15+15*i)+'px'
          div_item.style.right=String(-30)+'px'
          heat_options_contents.appendChild(div_item)
        }
      })
    },
    show_hide_layer:function(obj){  //点击checkbox显示或隐藏图层
      let name=obj.getAttribute('id')
      let layer=null
      this.map.getLayers().forEach(function (lyr) {
        if (name === lyr.get('name')) {
          layer = lyr
        }
      })
      if(obj.checked===true)
        layer.setVisible(true)
      else
        layer.setVisible(false)
    },
    //鼠标移入
    mousein:function() {
      //clearTimeout(this.timer);
      this.isshow = true;
    },
    //鼠标移出
    mouseleave:function (){
      this.timer = setTimeout(() => {
        this.isshow = false;
      }, 100);
    },
    /******************地图切换方法***************/
    changeBaseMap: function(value) {
      this.map.removeLayer(this.mapLayer)
      this.map.removeLayer(this.mapLayerlabel)
      switch (value) {
        case 'arcgis':
          this.mapLayer=new TileLayer({
            source:this.arcgis,
            projection:this.proj
          })
          this.map.addLayer(this.mapLayer)
          break;
        case 'googledz':
          this.mapLayer = new TileLayer({
            source: this.googledz,
            projection: this.proj
          })
          this.map.addLayer(this.mapLayer)
          break;
        case 'googledx':
          this.mapLayer = new TileLayer({
            source: this.googledx,
            projection: this.proj
          })
          this.map.addLayer(this.mapLayer)
          break;
        case 'googlewx':
          this.mapLayer = new TileLayer({
            source: this.googlewx,
            projection: this.proj
          })
          this.mapLayerlabel = new TileLayer({
            source: this.tdtlabeldz,
            projection: this.proj
          })
          this.map.addLayer(this.mapLayer)
          this.map.addLayer(this.mapLayerlabel)
          break;
        case 'tdtdz':
          this.mapLayer = new TileLayer({
            source: this.tdtdz,
            projection: this.proj
          })
          this.mapLayerlabel = new TileLayer({
            source: this.tdtlabeldz,
            projection: this.proj
          })
          this.map.addLayer(this.mapLayer)
          this.map.addLayer(this.mapLayerlabel)
          break;
        case 'tdtwx':
          this.mapLayer = new TileLayer({
            source: this.tdtwx,
            projection: this.proj
          })
          this.mapLayerlabel = new TileLayer({
            source: this.tdtlabelwx,
            projection: this.proj
          })
          this.map.addLayer(this.mapLayer)
          this.map.addLayer(this.mapLayerlabel)
          break;
        case 'gaodedz':
          this.mapLayer = new TileLayer({
            source: this.gaodedz,
            projection: this.proj
          })
          this.map.addLayer(this.mapLayer)
          console.log(this.map.getLayers())
          break;
        case 'gaodewx':
          this.mapLayer = new TileLayer({
            source: this.gaodewx,
            projection: this.proj
          })
          this.mapLayerlabel = new TileLayer({
            source: this.gaodelabelwx,
            projection: this.proj
          })
          this.map.addLayer(this.mapLayer)
          this.map.addLayer(this.mapLayerlabel)
          break;
        case 'baidudz':
          this.mapLayer = new TileLayer({
            source: this.baidudz,
            projection: this.proj
          })
          this.map.addLayer(this.mapLayer)
          break;
        case 'baiduwx':
          this.mapLayer = new TileLayer({
            source: this.baiduwx,
            projection: this.proj
          })
          this.mapLayerlabel = new TileLayer({
            source: this.baidulabelwx,
            projection: this.proj
          })
          this.map.addLayer(this.mapLayer)
          this.map.addLayer(this.mapLayerlabel)
          break;
        case 'qqmapdz':
          this.mapLayer = new TileLayer({
            source: this.qqmapdz,
            projection: this.proj
          })
          this.map.addLayer(this.mapLayer)
          break;
        case 'qqmapdx':
          this.mapLayer = new TileLayer({
            source: this.qqmapdx,
            projection: this.proj
          })
          this.mapLayerlabel = new TileLayer({
            source: this.qqmaplabledx,
            projection: this.proj
          })
          this.map.addLayer(this.mapLayer)
          this.map.addLayer(this.mapLayerlabel)
          break;
        case 'qqmapwx':
          this.mapLayer = new TileLayer({
            source: this.qqmapwx,
            projection: this.proj
          })
          this.mapLayerlabel = new TileLayer({
            source: this.qqmaplablewx,
            projection: this.proj
          })
          this.map.addLayer(this.mapLayer)
          this.map.addLayer(this.mapLayerlabel)
          break;
        case 'geoqcs':
          this.mapLayer = new TileLayer({
            source: this.geoqcs,
            projection: this.proj
          })
          this.map.addLayer(this.mapLayer)
          break;
        case 'geoqns':
          this.mapLayer = new TileLayer({
            source: this.geoqns,
            projection: this.proj
          })
          this.map.addLayer(this.mapLayer)
          break;
        case 'geoqhs':
          this.mapLayer = new TileLayer({
            source: this.geoqhs,
            projection: this.proj
          })
          this.map.addLayer(this.mapLayer)
          break;
        case 'geoqlh':
          this.mapLayer = new TileLayer({
            source: this.geoqlh,
            projection: this.proj
          })
          this.map.addLayer(this.mapLayer)
          break;
      }
      for(let i=0;i<this.n_heats;i++){
        this.map.removeLayer(this.heat_layers[i])
        this.map.addLayer(this.heat_layers[i])
      }

    },
    start_simulation:function(){  //开启仿真
      if(this.on_simulation===true)
        return
      this.has_started=true
      this.T=600
      this.on_simulation=true
      let that=this
      //向后台发送启动仿真的消息
      axios.get('http://127.0.0.1:5000/start_simulation',{
        params:{
          total_step:this.T
        }
      }).then(function(response){

        }
      )
      //设置定时函数，定时从后端获取heatmap
      this.timer=setInterval(function (){
        axios.get('http://127.0.0.1:5000/get_heats').then( function(response) {
          let data = response.data
          //更新ol的Heatmap
          for(let i=0;i<that.n_heats;i++){
            let now_heat=data[that.heat_name[i]]
            let features = []
            for(let key in now_heat){
              let feature=new Feature({geometry: new Point([now_heat[key]['lon'],now_heat[key]['lat']]),weight:now_heat[key]['cnt']})
              let src = 'EPSG:4326'
              let des = 'EPSG:3857'
              feature.getGeometry().transform(src, des)
              features.push(feature)
            }

            that.heat_layers[i].getSource().clear()
            that.heat_layers[i].getSource().addFeatures(features)

          }
        }).catch(function (error) {
          //alert('Error ' + error);
        })
        },5000)
      //广播仿真启动的消息
      this.$root.$emit('on_simulation')
    },
    pause:function(){
      this.on_simulation=false
      axios.post('http://127.0.0.1:5000/pause_simuation')
    },
    go_on:function(){
      if(this.has_started===false)
        return
      axios.post('http://127.0.0.1:5000/continue_simulation')
      this.on_simulation=true
    },
    blurHandler:function () {
      if(this.mutex=== 1)
        return
      this.onSlide=false
    },
    blurHandlerInput:function () {
      this.onSlide=true
      for(let i=0;i<this.n_heats;i++)
        this.heat_layers[i].setBlur(parseInt(this.blur.value, 10))
    },
    radiusHandler : function () {
      console.log(this.mutex)
      if(this.mutex===1)
        return
      this.onSlide=false
    },
    radiusHandlerInput : function () {
      this.onSlide=true
      for(let i=0;i<this.n_heats;i++)
        this.heat_layers[i].setRadius(parseInt(this.radius.value, 10))
    },
    show_layer:function(index){
      let name=this.layer_name[index]['name']
      let layer=null
      this.map.getLayers().forEach(function (lyr) {
        if (name === lyr.get('name')) {
          layer = lyr
        }
      })
      layer.setVisible(true)
    },
    hide_layer:function(index){
      let name=this.layer_name[index]['name']
      let layer=null
      this.map.getLayers().forEach(function (lyr) {
        if (name === lyr.get('name')) {
          layer = lyr
        }
      })
      layer.setVisible(false)
    },
    show_heat_options:function () {
      this.control_show=0
    },
    show_grid_options:function () {
      this.control_show=1
    },
    show_trip_options:function () {
      this.control_show=2
    },
    sure_to_reset:function(){//重置仿真进度
      this.dialog_visible=false
      //卸载定时器
      clearTimeout(this.timer)
      //清空可视化显示
      for(let i=0;i<this.heat_layers.length;i++)
        this.heat_layers[i].getSource().clear()
      //清空其他page的可视化显示
      Utils.$emit('reset')
      //重置后端
      let that=this
      axios.post('http://127.0.0.1:5000/reset_simulation').then( function(response) {

      })
    },
    close:function(){
      this.dialog_visible=false
    },
  }
}
</script>

<style scoped>
#olmap {
  position: relative;
  z-index: 1;
  width: 1515px;  /*1515px;*/
  height: 700px;
  left:185px;
  top:11px;
  border-radius: 4px;
  padding-left: 4px;
  padding-top: 4px;
  box-shadow: 2px 2px 4px #aaaaaa;
  background: #ffffff;
}

.mapselect {
  position: absolute;
  top: 2%;
  left: 5%;
  z-index: 2;
}

.caret {
  display: inline-block;
  width: 0;
  height: 0;
  border-left: 10px solid transparent;
  border-top: 10px solid;
  border-right: 10px solid transparent;
}

.button_group{
  position: relative;
  top:4px;
  padding-left: 250px;
  background: #ffffff;
  box-shadow: 2px 2px 4px #aaaaaa;
  height:39px;
  width:1500px;
  left:185px;
  border-radius: 4px;
  z-index: 5;
}

.button{
  position: relative;
  top:4px;
  height:31px;
  text-align: center;
  vertical-align:middle;
  font-size: 14px;
  box-shadow: 0px 0px 2px #cccccc;
}


.control-panel{
  font: 14px / 20px UberMove, Helvetica, Arial, sans-serif;
  position: absolute;
  top: 0px;
  right: 15px;
  width: 230px;
  height:260px;
  background: rgb(255, 255, 255);
  outline: none;
  z-index: 15;
  border-radius: 3px;
  box-shadow: 2px 2px 4px #aaaaaa;
}
.control_options {
  position:relative;
  width:100%;
  top:6px;
  left:30px;
}
.control-container {
  position:relative;
  width:100%;
  top:15px;
  height: 100px;
}
.control-item {
  position:relative;
  top:5px;
  left:40px;
}

label{
  color:black;
  position: relative;
}

.control-item-text{
  position:relative;
  left:45px;
}

.control-checkbox {
  position:relative;
  left:30px;
  top:3px;
}

</style>
