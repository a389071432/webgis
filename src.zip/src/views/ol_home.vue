<template>
  <div style="height: 720px;">
    <div style="height: 70px;">
    <HeadNav></HeadNav>
    <button class="basic return" @click="show_return">返回</button>
    </div>
    <SideMenu></SideMenu>
    <div class="control-panel"  v-drag id="drag" v-if="isShowDrag">
      <label style="position: relative;left: 85px;height:26px;top:15px;font-size: 17px;font-weight: bold">图层选项</label>
      <div class="control-container">
        <div  v-show="this.control_show===0">
        <div class="heat_options_content" id="heat_options_content"></div>
        <form style="position: relative;left:20px;top:70px;">
          <label for="radius">radius size</label>
          <input id="radius" type="range" min="1" max="50" step="1" value="5"/>
          <label for="blur">blur size</label>
          <input id="blur" type="range" min="1" max="50" step="1" value="15"/>
        </form>
        </div>
      </div>
    </div>
    <div class="button_group">
      <div style="position: relative;left:-210px;">
    <el-button v-on:click="start_simulation" class='button' ><p style="position:relative;top:-3px;  font-size: 15px;">启动仿真</p></el-button>
    <el-button v-on:click="pause" class='button' ><p style="position:relative;top:-3px;  font-size: 15px;">暂停</p></el-button>
    <el-button v-on:click="go_on" class='button' ><p style="position:relative;top:-3px;  font-size: 15px;">继续</p></el-button>
      <el-button v-on:click="show_set_status" class='button' ><p style="position:relative;top:-3px;  font-size: 15px;">初始状态人数</p></el-button>
      <el-button v-on:click="whether_to_reset" class='button' ><p style="position:relative;top:-3px;  font-size: 15px;">重置进度</p></el-button>
      </div>
      <div style="position: relative;left:700px;top:-30px;">
      <label style="position: relative;top:6px;font-weight: bold">仿真时长 :</label>
      <input class="input_step" id="input_step"></input>
      </div>
    </div>
    <div class="range-slider">
      <input class="range-slider__range" id="process" type="range" min="0">
      <span class="range-slider__value" id="now_step">0</span>
    </div>
  <div id="olmap" ref="olmap">
    <el-select class="mapselect" v-model="value" placeholder="切换地图底图" @change="changeBaseMap(value)">
      <el-option-group v-for="group in options" :key="group.label" :label="group.label">
        <el-option
          v-for="item in group.options"
          :key="item.value"
          :label="item.label"
          :value="item.value"
        ></el-option>
      </el-option-group>
    </el-select>
  </div>
    <el-dialog  :visible.sync="return_visible" center  >
      <p>您确定返回吗？当前仿真进度将丢失</p>
      <el-button style="margin-top:12px;" @click="sure_to_return">确认</el-button>
      <div style="width:70px"></div>
      <el-button  style="margin-top:12px;" @click="close3" @close="close3">取消</el-button>
    </el-dialog>
    <el-dialog  :visible.sync="set_status_visible" center :width="width_set_status" >
      <p id="warning_set_status" style="position:relative;left:20px;top:-10px;"></p>
      <div id="set_status_contents">
      </div>
      <div style="position: relative;top: 20px;left:55px;height: 40px;">
      <el-button size="mini" @click="ok2" @close="close2">确认</el-button>
      </div>
    </el-dialog>
    <el-dialog  :visible.sync="warning_visible" center  >
      <div style="height:500px;">
        <p id="warning_text"></p>
      </div>
      <el-button style="margin-top:12px;" @close="close1" @click="close1">确认</el-button>
    </el-dialog>
    <el-dialog  :visible.sync="dialog_visible" center  >
      <div style="height:500px;"></div>
      <el-button style="margin-top:12px;" @click="sure_to_reset">确认</el-button>
      <div style="width:70px"></div>
      <el-button id="next" style="margin-top:12px;" @click="close" @close="close">取消</el-button>
    </el-dialog>
  </div>
</template>

<script>
import Map from 'ol/Map'
import View from 'ol/View'
import Feature from 'ol/Feature'
import Point from 'ol/geom/Point'
import TileLayer from 'ol/layer/Tile'
import { OSM, TileArcGISRest } from 'ol/source/OSM'
import Overlay from 'ol/Overlay';
import VectorLayer from 'ol/layer/Vector';
import VectorSource from 'ol/source/Vector';
import {Fill, Stroke, Style,Circle} from 'ol/style';
import Heatmap from "ol/layer/Heatmap";
import XYZ from 'ol/source/XYZ'
import { transform,fromLonLat } from 'ol/proj'
import mapSources from './modules/maplist'
import HeadNav from "../components/HeadNav";
import LeftMenu from "../components/LeftMenu";
import SideMenu from "../components/SideMenu";
import white from "../components/white"
import TileWMS from "ol/source/TileWMS";
import axios from 'axios'
import * as echarts from 'echarts';
import 'echarts/extension/bmap/bmap'
import ADLayer from 'openlayers_echart'
import EChartsLayer from 'ol-echarts'
import Utils from "./utils";


export default {
  components: {
    LeftMenu,
    HeadNav,
    SideMenu,
    white
  },
  data() {
    return {
      width_set_status:"230px",
      return_visible:false,
      build_cnt:0,  //记录当前是第几次重新构建，在activated内根据该值决定是否刷新
      on_progress:false,  //仅当重置进度时设为false
      status_cnt:[],
      has_set_status:false,
      set_status_visible:false,
      warning_visible:false,
      timer:null,
      dialog_visible:false,
      blur:null,
      radius:null,
      mutex:0,
      onSlide:false,
      isShowDrag:true,
      show_panel:0,
      pie:null,
      chart_option:null,
      chart:null,
      grid_size:1000,
      lonExtent:null,
      latExtent:null,
      cellSizelonlat:null,
      cellCount:null,
      isshow:false,
      options: mapSources.basemapLabel,
      value: '',
      control:null,
      arcgis:mapSources.arcgis,
      googledz: mapSources.googledz,
      googledx: mapSources.googledx,
      googlewx: mapSources.googlewx,
      tdtdz: mapSources.tdtdz,
      tdtlabeldz: mapSources.tdtlabeldz,
      tdtwx: mapSources.tdtwx,
      tdtlabelwx: mapSources.tdtlabelwx,
      baidudz: mapSources.baidudz,
      baiduwx: mapSources.baiduwx,
      baidulabelwx: mapSources.baidulabelwx,
      gaodedz: mapSources.gaodedz,
      gaodewx: mapSources.gaodewx,
      gaodelabelwx: mapSources.gaodelabelwx,
      qqmapdz: mapSources.qqmapdz,
      qqmapdx: mapSources.qqmapdx,
      qqmaplabledx: mapSources.qqmaplabledx,
      qqmapwx: mapSources.qqmapwx,
      qqmaplablewx: mapSources.qqmaplablewx,
      geoqcs: mapSources.geoqcs,
      geoqns: mapSources.geoqns,
      geoqhs: mapSources.geoqhs,
      geoqlh: mapSources.geoqlh,
      proj: 'EPSG:4326', //定义wgs84地图坐标系
      proj_m: 'EPSG:3857', //定义墨卡托地图坐标系
      map: null,
      mapLayer: null,
      mapLayerlabel: null,

      n_heats:null,
      heat_name:null,
      heat_layers:[],

      selected_coordinate:null,//当前选中的坐标
      selected_hosp:null,  //当前选中的hospital(featureObject)
      selected_id:-1,    //当前选中的hospital id

      on_simulation:false,  //当前是否处于仿真状态
      T:-1,  //仿真时长
      current_step:0,
      has_started:false,  //标记是否已经启动过
      layer_name:[],
      has_on:false,  //是否已监听
      control_show:0,

      infected_model_form:null,
    }
  },
  //自定义指令
  directives: {
    drag: {
      // 指令的定义
      bind: function(el,binding,vnode) {
        let oDiv = el;  // 获取当前元素
        oDiv.onmousedown = (e) => {
          // 算出鼠标相对元素的位置
          let disX = e.clientX - oDiv.offsetLeft;
          let disY = e.clientY - oDiv.offsetTop;

          document.onmousemove = (e) => {
            if(vnode.context.onSlide===true)
              return
            // 用鼠标的位置减去鼠标相对元素的位置，得到元素的位置
            let left = e.clientX - disX;
            let top = e.clientY - disY;

            oDiv.style.left = left + 'px';
            oDiv.style.top = top + 'px';

          };

          document.onmouseup = (e) => {
            vnode.context.onSlide=false
            document.onmousemove = null;
            document.onmouseup = null;
          }
        }
      }
    }
  },
  created() {
  },
  mounted() {
    //挂载点击事件，从而实现动态为控件绑定onclick
    window.show_hide_layer_ol = this.show_hide_layer
    //初始化
    this.init()
  },
  activated() {
    if(Object.keys(this.$route.params).length>0){
      if(this.build_cnt!==this.$route.params.build_cnt){
        this.build_cnt=this.$route.params.build_cnt
        this.init()
      }
    }
  },
  deactivated() {
    let that=this
    //向statis页面发送仿真启动的消息
    if(this.on_simulation===true){
      setTimeout(function (){
        that.$root.$emit('on_simulation')
      },1000)
    }
    //向感染模型编辑页面发送表格
    setTimeout(function (){
      that.$root.$emit('infected_model_form',{'table_data':that.infected_model_form})
    },1000)
  },
  methods: {
    init: function(){
      // document.body.onmousemove = function() {
      //   this.onSlide=true
      // }
      document.body.onmouseup = function() {
        this.onSlide=false
      }
      this.blur = document.getElementById('blur')
      this.radius = document.getElementById('radius')
      this.blur.addEventListener('input', this.blurHandlerInput)
      //this.blur.addEventListener('change', this.blurHandler)
      this.radius.addEventListener('input', this.radiusHandlerInput)
      document.getElementById('process').addEventListener('input', this.stepHandlerInput)
      //this.radius.addEventListener('change', this.radiusHandler)
      //接收infected_model表格，传给edit_infected_model界面
      this.infected_model_form=this.$route.params.table_data
      //初始化map对象
      this.map = new Map({
        target: 'olmap',
        projection: this.proj,
        view: new View({
          projection:'EPSG:3857',
          center:fromLonLat([121.4806,31.2167]),
          zoom: 11
        })
      })
      //初始化地图图层
      this.mapLayer = new TileLayer({
        source: this.gaodedz,
        projection: this.proj
      })
      //初始化标签图层
      this.mapLayerlabel = new TileLayer({
        source: this.tdtlabelwx,
        projection: this.proj
      })
      this.map.addLayer(this.mapLayer)
      this.map.addLayer(this.mapLayerlabel)
      //从后端获取n_node和node_name信息
      let that=this
      axios.get('http://222.94.162.146:5000/get_nodes_info').then( function(response) {
        let info = response.data
        that.n_heats=info['n_nodes']
        that.heat_name=info['node_name']
        //初始化热力图图层
        for(let i=0;i<that.heat_name.length;i++){
          let heat_layer=new Heatmap({   //heatmap图层
            source:new VectorSource({}),
            blur: parseInt(that.blur.value, 10),
            radius: parseInt(that.radius.value, 10),
            opacity: .5
          })
          heat_layer.set('name',that.heat_name[i])
          heat_layer.setVisible(false)
          that.heat_layers.push(heat_layer)
          that.map.addLayer(that.heat_layers[i])
        }
        //在下拉框显示图层名称
        for(let i=0;i<that.n_heats;i++)
          that.layer_name.push({'name':that.heat_name[i]})
        document.getElementById('drag').style.height=String(35*that.n_heats+160)+'px'
        //初始化图层选项框（动态创建条目）
        for(let i=0;i<that.n_heats;i++){
          let heat_options_contents=document.getElementById('heat_options_content')
          let div_item=document.createElement('div')
          let label=document.createElement('label')
          label.innerText=that.heat_name[i]
          label.style.position='relative'
          label.style.color='black'
          label.style.fontWeight='bold'
          label.style.width='90px'
          let label_text=document.createElement('label')
          label_text.style.position='relative'
          label_text.style.left='5px'
          label_text.style.color='black'
          label_text.setAttribute('class','control-item-text')
          label_text.innerText='显示/隐藏'
          let input=document.createElement('input')
          input.setAttribute('type','checkbox')
          input.setAttribute('class','control-checkbox')
          input.setAttribute('id',that.heat_name[i])
          input.setAttribute('onclick',"show_hide_layer_ol(this)")
          input.style.position='relative'
          input.style.left='10px'
          input.style.top=String(2)+'px'
          div_item.appendChild(label)
          div_item.appendChild(label_text)
          div_item.appendChild(input)
          div_item.style.position='relative'
          div_item.style.top=String(20+15*i)+'px'
          div_item.style.right=String(-30)+'px'
          heat_options_contents.appendChild(div_item)
        }
      })
    },
    show_set_status:function (){
       if(this.on_progress===true){
         this.warning_visible=true
           document.getElementById('warning_text').innerText='仿真进行中不可更改，若更改请重置进度'
       }
       this.set_status_visible=true
       let that=this
       setTimeout(function(){
         //清除
         document.getElementById('set_status_contents').innerHTML=''
         document.getElementById('warning_set_status').style.color='black'
         document.getElementById('warning_set_status').innerText='请输入各状态的初始人数：'
         //动态创建set_status_dialog的条目
         for(let i=0;i<that.n_heats;i++){
           let set_status_contents=document.getElementById('set_status_contents')
           let div_item=document.createElement('div')
           let label=document.createElement('label')
           label.innerText=that.heat_name[i]
           label.style.width='35px'
           label.style.position='relative'
           label.style.color='black'
           label.style.fontWeight='bold'
           let input=document.createElement('input')
           input.setAttribute('class','control-checkbox')
           input.setAttribute('id','cnt'+that.heat_name[i])
           input.style.position='relative'
           input.style.left='10px'
           input.style.top='-3px'
           input.style.width='70px'
           input.style.border='none'
           input.style.borderBottom='1px solid #757575'
           div_item.appendChild(label)
           div_item.appendChild(input)
           div_item.style.position='relative'
           //div_item.style.top=String(15+5*i)+'px'
           div_item.style.height='40px'
           div_item.style.left='20px'
           set_status_contents.appendChild(div_item)
           if(that.status_cnt.length>0)
             input.value=that.status_cnt[i]
         }
       },10)

    },
    ok2:function(){
      let tag=true
      for(let i=0;i<this.heat_name.length;i++){
        let cnt=document.getElementById('cnt'+this.heat_name[i]).value
        if((cnt.length===0)||(isNaN(parseInt(cnt,10)))){
          tag=false
          break
        }
      }
      if(tag===false){
        document.getElementById('warning_set_status').innerText='请输入正整数!'
        document.getElementById('warning_set_status').style.color='red'
        return
      }
      this.status_cnt=[]
      for(let i=0;i<this.heat_name.length;i++){
        let cnt=parseInt(document.getElementById('cnt'+this.heat_name[i]).value,10)
        this.status_cnt.push(cnt)
      }
      this.set_status_visible=false
    },
    close2:function (){
      this.set_status_visible=false
    },
      show_hide_layer:function(obj){  //点击checkbox显示或隐藏图层
      let name=obj.getAttribute('id')
      let layer=null
      this.map.getLayers().forEach(function (lyr) {
        if (name === lyr.get('name')) {
          layer = lyr
        }
      })
      if(obj.checked===true){
        layer.setVisible(true)
      }
      else
        layer.setVisible(false)
    },
    /******************地图切换方法***************/
    changeBaseMap: function(value) {
      this.map.removeLayer(this.mapLayer)
      this.map.removeLayer(this.mapLayerlabel)
      switch (value) {
        case 'arcgis':
          this.mapLayer=new TileLayer({
            source:this.arcgis,
            projection:this.proj
          })
          this.map.addLayer(this.mapLayer)
          break;
        case 'googledz':
          this.mapLayer = new TileLayer({
            source: this.googledz,
            projection: this.proj
          })
          this.map.addLayer(this.mapLayer)
          break;
        case 'googledx':
          this.mapLayer = new TileLayer({
            source: this.googledx,
            projection: this.proj
          })
          this.map.addLayer(this.mapLayer)
          break;
        case 'googlewx':
          this.mapLayer = new TileLayer({
            source: this.googlewx,
            projection: this.proj
          })
          this.mapLayerlabel = new TileLayer({
            source: this.tdtlabeldz,
            projection: this.proj
          })
          this.map.addLayer(this.mapLayer)
          this.map.addLayer(this.mapLayerlabel)
          break;
        case 'tdtdz':
          this.mapLayer = new TileLayer({
            source: this.tdtdz,
            projection: this.proj
          })
          this.mapLayerlabel = new TileLayer({
            source: this.tdtlabeldz,
            projection: this.proj
          })
          this.map.addLayer(this.mapLayer)
          this.map.addLayer(this.mapLayerlabel)
          break;
        case 'tdtwx':
          this.mapLayer = new TileLayer({
            source: this.tdtwx,
            projection: this.proj
          })
          this.mapLayerlabel = new TileLayer({
            source: this.tdtlabelwx,
            projection: this.proj
          })
          this.map.addLayer(this.mapLayer)
          this.map.addLayer(this.mapLayerlabel)
          break;
        case 'gaodedz':
          this.mapLayer = new TileLayer({
            source: this.gaodedz,
            projection: this.proj
          })
          this.map.addLayer(this.mapLayer)
          console.log(this.map.getLayers())
          break;
        case 'gaodewx':
          this.mapLayer = new TileLayer({
            source: this.gaodewx,
            projection: this.proj
          })
          this.mapLayerlabel = new TileLayer({
            source: this.gaodelabelwx,
            projection: this.proj
          })
          this.map.addLayer(this.mapLayer)
          this.map.addLayer(this.mapLayerlabel)
          break;
        case 'baidudz':
          this.mapLayer = new TileLayer({
            source: this.baidudz,
            projection: this.proj
          })
          this.map.addLayer(this.mapLayer)
          break;
        case 'baiduwx':
          this.mapLayer = new TileLayer({
            source: this.baiduwx,
            projection: this.proj
          })
          this.mapLayerlabel = new TileLayer({
            source: this.baidulabelwx,
            projection: this.proj
          })
          this.map.addLayer(this.mapLayer)
          this.map.addLayer(this.mapLayerlabel)
          break;
        case 'qqmapdz':
          this.mapLayer = new TileLayer({
            source: this.qqmapdz,
            projection: this.proj
          })
          this.map.addLayer(this.mapLayer)
          break;
        case 'qqmapdx':
          this.mapLayer = new TileLayer({
            source: this.qqmapdx,
            projection: this.proj
          })
          this.mapLayerlabel = new TileLayer({
            source: this.qqmaplabledx,
            projection: this.proj
          })
          this.map.addLayer(this.mapLayer)
          this.map.addLayer(this.mapLayerlabel)
          break;
        case 'qqmapwx':
          this.mapLayer = new TileLayer({
            source: this.qqmapwx,
            projection: this.proj
          })
          this.mapLayerlabel = new TileLayer({
            source: this.qqmaplablewx,
            projection: this.proj
          })
          this.map.addLayer(this.mapLayer)
          this.map.addLayer(this.mapLayerlabel)
          break;
        case 'geoqcs':
          this.mapLayer = new TileLayer({
            source: this.geoqcs,
            projection: this.proj
          })
          this.map.addLayer(this.mapLayer)
          break;
        case 'geoqns':
          this.mapLayer = new TileLayer({
            source: this.geoqns,
            projection: this.proj
          })
          this.map.addLayer(this.mapLayer)
          break;
        case 'geoqhs':
          this.mapLayer = new TileLayer({
            source: this.geoqhs,
            projection: this.proj
          })
          this.map.addLayer(this.mapLayer)
          break;
        case 'geoqlh':
          this.mapLayer = new TileLayer({
            source: this.geoqlh,
            projection: this.proj
          })
          this.map.addLayer(this.mapLayer)
          break;
      }
      for(let i=0;i<this.n_heats;i++){
        this.map.removeLayer(this.heat_layers[i])
        this.map.addLayer(this.heat_layers[i])
      }

    },
    close1:function (){
      this.warning_visible=false
    },
      start_simulation:function(){  //开启仿真
      if(this.on_simulation===true)
        return
      let t=document.getElementById('input_step').value
      if(t.length===0){
        this.warning_visible=true
        return
      }
      if(parseInt(t,10)==='NaN'){
        this.warning_visible=true
        return
      }
      if(this.status_cnt.length===0){
        document.getElementById('warning_text').innerText='请输入有效的状态人数!'
        this.warning_visible=true
        return
      }
        this.on_progress=true
      document.getElementById('input_step').setAttribute('disabled','disabled')
        document.getElementById('process').setAttribute('disabled','disabled')
      this.has_started=true
      this.T=parseInt(document.getElementById('input_step').value)
        document.getElementById('process').setAttribute("max", this.T)
      this.on_simulation=true
      let that=this
      //向后台发送启动仿真的消息
      axios.post('http://222.94.162.146:5000/start_simulation',{
          total_step:this.T,
          status_cnt:this.status_cnt
      }).then(function(response){

        }
      )
      //设置定时函数，定时从后端获取heatmap
      this.timer=setInterval(function (){
        axios.get('http://222.94.162.146:5000/get_heats').then( function(response) {
          let ans = response.data
          let data=ans['heats']
          let now_step=ans['now_step']
          document.getElementById('now_step').innerText=String(now_step)+'/'+String(that.T)
          document.getElementById('process').setAttribute('value',String(now_step))
          //console.log('heats',data)
          //更新ol的Heatmap
          for(let i=0;i<that.n_heats;i++){
            let now_heat=data[that.heat_name[i]]
            let features = []
            for(let key in now_heat){
              let feature=new Feature({geometry: new Point([now_heat[key]['lon'],now_heat[key]['lat']]),weight:now_heat[key]['cnt']})
              let src = 'EPSG:4326'
              let des = 'EPSG:3857'
              feature.getGeometry().transform(src, des)
              features.push(feature)
            }

            that.heat_layers[i].getSource().clear()
            that.heat_layers[i].getSource().addFeatures(features)

          }
        }).catch(function (error) {
          //alert('Error ' + error);
        })
        },2500)
      //广播仿真启动的消息
      //this.$root.$emit('on_simulation')
        Utils.$emit('start_simulation')
       // this.$root.eventHub.$emit('broadcast','test')
    },
    pause:function(){
      this.on_simulation=false
      clearTimeout(this.timer)
      document.getElementById('process').removeAttribute('disabled')
      axios.post('http://222.94.162.146:5000/pause_simulation')
      Utils.$emit('pause_simulation')
    },
    go_on:function(){
      if(this.has_started===false)
        return
      document.getElementById('process').setAttribute('disabled','disabled')
      axios.post('http://222.94.162.146:5000/continue_simulation')
      this.on_simulation=true
      Utils.$emit('continue_simulation')
      let that=this
      this.timer=setInterval(function (){
        axios.get('http://222.94.162.146:5000/get_heats').then( function(response) {
          let ans = response.data
          let data=ans['heats']
          let now_step=ans['now_step']
          document.getElementById('now_step').innerText=String(now_step)+'/'+String(that.T)
          document.getElementById('process').setAttribute('value',String(now_step))
          //console.log('heats',data)
          //更新ol的Heatmap
          for(let i=0;i<that.n_heats;i++){
            let now_heat=data[that.heat_name[i]]
            let features = []
            for(let key in now_heat){
              let feature=new Feature({geometry: new Point([now_heat[key]['lon'],now_heat[key]['lat']]),weight:now_heat[key]['cnt']})
              let src = 'EPSG:4326'
              let des = 'EPSG:3857'
              feature.getGeometry().transform(src, des)
              features.push(feature)
            }

            that.heat_layers[i].getSource().clear()
            that.heat_layers[i].getSource().addFeatures(features)

          }
        }).catch(function (error) {
          //alert('Error ' + error);
        })
      },2500)
    },
    blurHandler:function () {
      if(this.mutex=== 1)
        return
      this.onSlide=false
    },
    blurHandlerInput:function () {
      this.onSlide=true
      for(let i=0;i<this.n_heats;i++)
        this.heat_layers[i].setBlur(parseInt(this.blur.value, 10))
    },
    radiusHandler : function () {
      if(this.mutex===1)
        return
      this.onSlide=false
    },
    radiusHandlerInput : function () {
      this.onSlide=true
      for(let i=0;i<this.n_heats;i++)
        this.heat_layers[i].setRadius(parseInt(this.radius.value, 10))
    },
    stepHandler:function () {
      if(this.mutex=== 1)
        return
      this.onSlide=false
    },
    stepHandlerInput:function () {
      this.onSlide=true
      let that=this
      let selected_step=parseInt(document.getElementById('process').value,10)
      axios.get('http://222.94.162.146:5000/get_heats_step',{  //params参数必写 , 如果没有参数传{}也可以
        params: {
          step:selected_step
       }
    }).then( function(response) {
        let data = response.data
        console.log('selected step data:',data)
        //更新ol的Heatmap
        for(let i=0;i<that.n_heats;i++){
          let now_heat=data[that.heat_name[i]]
          let features = []
          for(let key in now_heat){
            let feature=new Feature({geometry: new Point([now_heat[key]['lon'],now_heat[key]['lat']]),weight:now_heat[key]['cnt']})
            let src = 'EPSG:4326'
            let des = 'EPSG:3857'
            feature.getGeometry().transform(src, des)
            features.push(feature)
          }
          that.heat_layers[i].getSource().clear()
          that.heat_layers[i].getSource().addFeatures(features)

        }
      }).catch(function (error) {
        //alert('Error ' + error);
      })
    },
    show_layer:function(index){
      let name=this.layer_name[index]['name']
      let layer=null
      this.map.getLayers().forEach(function (lyr) {
        if (name === lyr.get('name')) {
          layer = lyr
        }
      })
      layer.setVisible(true)
    },
    hide_layer:function(index){
      let name=this.layer_name[index]['name']
      let layer=null
      this.map.getLayers().forEach(function (lyr) {
        if (name === lyr.get('name')) {
          layer = lyr
        }
      })
      layer.setVisible(false)
    },
    show_heat_options:function () {
      this.control_show=0
    },
    show_process_options:function () {
      this.control_show=1
    },
    whether_to_reset:function(){
      this.dialog_visible=true
    },
    show_return:function(){
      this.return_visible=true
    },
    sure_to_return(){   //返回重新构建场景
      this.return_visible=false
      this.sure_to_reset()
      this.$router.push({name:'build_scene'})
    },
    close3(){
      this.return_visible=false
    },
      sure_to_reset:function(){//重置仿真进度
      this.dialog_visible=false
      this.on_simulation=false
      this.on_progress=false
      this.status_cnt=[]
        document.getElementById('now_step').innerText='0'
      document.getElementById('input_step').removeAttribute('disabled')
       // document.getElementById('heat_options_content').innerHTML=''
      //卸载定时器
      clearTimeout(this.timer)
      //清空可视化显示
      for(let i=0;i<this.heat_layers.length;i++)
        this.heat_layers[i].getSource().clear()
      //清空其他page的可视化显示
      Utils.$emit('reset')
      //重置后端
      let that=this
      axios.post('http://222.94.162.146:5000/reset_simulation').then( function(response) {

      })
    },
    close:function(){
      this.dialog_visible=false
    },
    set_total_step:function (){
      this.T=parseInt(document.getElementById('input_step').value)
    }

  }
}
</script>

<style lang="scss" scoped>
#olmap {
  position: relative;
  z-index: 1;
  width: 1515px;  /*1515px;*/
  height: 700px;
  left:185px;
  top:-791px;
  border-radius: 4px;
  padding-left: 4px;
  padding-top: 4px;
  box-shadow: 2px 2px 4px #aaaaaa;
  background: #ffffff;
}

.mapselect {
  position: absolute;
  top: 2%;
  left: 5%;
  z-index: 2;
}

.caret {
  display: inline-block;
  width: 0;
  height: 0;
  border-left: 10px solid transparent;
  border-top: 10px solid;
  border-right: 10px solid transparent;
}

.button_group{
  position: relative;
  top:-795px;
  padding-left: 250px;
  background: #ffffff;
  box-shadow: 2px 2px 4px #aaaaaa;
  height:42px;
  width:1500px;
  left:185px;
  border-radius: 4px;
  z-index: 5;
}

.button{
  position: relative;
  top:4px;
  height:31px;
  text-align: center;
  vertical-align:middle;
  font-size: 14px;
  box-shadow: 0px 0px 2px #cccccc;
}


.control-panel{
  font: 14px / 20px UberMove, Helvetica, Arial, sans-serif;
  position: absolute;
  top: 0px;
  right: 15px;
  width: 240px;
  height:260px;
  background: rgb(255, 255, 255);
  outline: none;
  z-index: 100;
  border-radius: 3px;
  box-shadow: 2px 2px 4px #aaaaaa;
}
.control_options {
  position:relative;
  width:100%;
  top:19px;
  left:30px;
}
.control-container {
  position:relative;
  width:100%;
  top:15px;
  height: 100px;
}
.control-item {
  position:relative;
  top:5px;
  left:40px;
}

label{
  color:black;
  position: relative;
}

.control-item-text{
  position:relative;
  left:45px;
}

.control-checkbox {
  position:relative;
  left:30px;
  top:3px;
}

.input_step{
  -webkit-appearance: none;
  -moz-appearance: none;
  appearance:none ;
  outline: 0;
  padding:0 1px;
  box-shadow: 0 0px 0px 0px #ffffff;
  border-radius:10px;
  width:80px;
  height:25px;
  top:5px;
  position: relative;
}


.return, .return:before {
  background: rgba(5,118,255,1);
  background: -moz-linear-gradient(45deg, rgba(5,118,255,1) 0%, rgba(36,248,255,1) 100%);
  background: -webkit-linear-gradient(45deg, rgba(5,118,255,1) 0%, rgba(36,248,255,1) 100%);
  background: -o-linear-gradient(45deg, rgba(5,118,255,1) 0%, rgba(36,248,255,1) 100%);
  background: -ms-linear-gradient(45deg, rgba(5,118,255,1) 0%, rgba(36,248,255,1) 100%);
  background: linear-gradient(45deg, rgba(5,118,255,1) 0%, rgba(36,248,255,1) 100%);
  filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#0576ff', endColorstr='#24f8ff', GradientType=1 );
}

.basic {
  display: inline-block;
  position: relative;
  left:1500px;
  top:-80px;
  height:60px;
  width:100px;
 // border-radius: 1px;
  text-decoration: none;
  //padding: .1em;
  margin: .4em;
  font-size: 2em;
  font-weight: bold;
  transition: all .5s;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  z-index: 50;
  border: 1px;
}

.basic:after {
  z-index:50;
}

.basic:hover {
  text-shadow: 0px 0px 0px rgba(255, 255, 255, .75);
}
.basic:hover:after {
  //left: 100%;
  //top: 100%;
  //bottom: 100%;
  //right: 100%;
}
.basic:before {
  content: '';
  display: block;
  position: absolute;
  left: 800px;
  top: 0;
  bottom: 0;
  right: 0;
  z-index: 50;
 // border-radius: 1px;
  transition: all .5s;
}
.basic:after {
  content: '';
  display: block;
  position: absolute;
  left: 0px;
  top: 0px;
  bottom: 0px;
  right: 0px;
  z-index: 50;
  //border-radius: 1px;
  transition: all .5s;
}

// Base Colors
$shade-10: #2c3e50 !default;
$shade-1: #d7dcdf !default;
$shade-0: #fff !default;
$teal: #1abc9c !default;


// Reset
* {
  &,
  &:before,
  &:after {
    box-sizing: border-box;
  }
}


.range-slider {
  margin: 7px 0 0 0%;
  position: relative;
  left:220px;
  top:-798px;
}


// Range Slider
$range-width: 86% !default;

$range-handle-color: $shade-10 !default;
$range-handle-color-hover: $teal !default;
$range-handle-size: 15px !default;

$range-track-color: $shade-1 !default;
$range-track-height: 5px !default;

$range-label-color: $shade-10 !default;
$range-label-width: 70px !default;

.range-slider {
  width: $range-width;
}

.range-slider__range {
  -webkit-appearance: none;
  width: calc(100% - (#{$range-label-width + 13px}));
  height: $range-track-height;
  border-radius: 5px;
  background: $range-track-color;
  outline: none;
  padding: 0;
  margin: 0;

  // Range Handle
  &::-webkit-slider-thumb {
    appearance: none;
    width: $range-handle-size;
    height: $range-handle-size;
    border-radius: 50%;
    background: $range-handle-color;
    cursor: pointer;
    transition: background .15s ease-in-out;

    &:hover {
      background: $range-handle-color-hover;
    }
  }

  &:active::-webkit-slider-thumb {
    background: $range-handle-color-hover;
  }

  &::-moz-range-thumb {
    width: $range-handle-size;
    height: $range-handle-size;
    border: 0;
    border-radius: 50%;
    background: $range-handle-color;
    cursor: pointer;
    transition: background .15s ease-in-out;

    &:hover {
      background: $range-handle-color-hover;
    }
  }

  &:active::-moz-range-thumb {
    background: $range-handle-color-hover;
  }

  // Focus state
  &:focus {

    &::-webkit-slider-thumb {
      box-shadow: 0 0 0 3px $shade-0,
      0 0 0 6px $teal;
    }
  }
}


// Range Label
.range-slider__value {
  display: inline-block;
  position: relative;
  width: $range-label-width;
  color: $shade-0;
  line-height: 20px;
  text-align: center;
  border-radius: 3px;
  background: $range-label-color;
  padding: 5px 10px;
  margin-left: 8px;

  &:after {
    position: absolute;
    top: 8px;
    left: -7px;
    width: 0;
    height: 0;
    border-top: 7px solid transparent;
    border-right: 7px solid $range-label-color;
    border-bottom: 7px solid transparent;
    content: '';
  }
}


// Firefox Overrides
::-moz-range-track {
  background: $range-track-color;
  border: 0;
}

input::-moz-focus-inner,
input::-moz-focus-outer {
  border: 0;
}
</style>
