<template>
  <div>
    <HeadNav></HeadNav>
    <leftMenu></leftMenu>
    <div class="map_container">
      <TTT />
    </div>
  </div>
</template>

<script>
import TTT from './components/react_deckgl'
import HeadNav from "../components/HeadNav";
import LeftMenu from "../components/LeftMenu";
import HeadNav from "../components/LeftMenu";

export default {
  components:{
    HeadNav,
    LeftMenu,
    'TTT':TTT
  },
  name: "ThreeDVisualize",
}
</script>

<style scoped>
.map_container {
  position: relative;
  z-index: 1;
  width: 1518px;
  height: 725px;
  left:182px;
  top:3px;
  border-radius: 4px;
  padding-left: 4px;
  padding-top: 3px;
  box-shadow: 2px 2px 4px #aaaaaa;
  background: #ffffff;
}
</style>
