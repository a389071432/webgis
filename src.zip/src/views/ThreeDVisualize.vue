<template>
  <div>
    <HeadNav></HeadNav>
    <leftMenu></leftMenu>
    <div class="control-panel" v-drag id="drag" v-if="isShowDrag">
      <label style="position: relative;left: 85px;height:26px;top:3px;">图层选项</label>
      <div class="control_options" style="position: relative;left:13px;">
        <el-button-group >
          <el-button size="mini" @click="show_heat_options">热力图</el-button>
          <el-button size="mini" @click="show_grid_options">网格图</el-button>
          <el-button size="mini" @click="show_trip_options">通勤图</el-button>
        </el-button-group>
      </div>
      <div class="control-container">
        <div class="heat_options_content" id="heat_options_content" v-show="this.control_show===0">
        </div>
        <div class="grid_content" id="grid_content" v-show="this.control_show===1"></div>
        <div class="trip_content" v-show="this.control_show===2">
          <label>显示/隐藏</label>
          <input type="checkbox" id="scatter"   onclick="show_hide_layer(this)"></input>
        </div>
      </div>
    </div>
    <div class="map_container">
      <TTT :heatNames="heat_name" :heatData="heat_data"  :gridData="grid_data"  :tripData="trip_data"  :vHeat="visible_heat" :vGrid="visible_grid" :vScatter="visible_scatter" :radius="radius" />
    </div>
  </div>
</template>

<script>
import TTT from './components/react_deckgl'
import {renderToDOM} from "./components/react_deckgl";
import HeadNav from "../components/HeadNav";
import LeftMenu from "../components/LeftMenu";
import axios from "axios";
import Heatmap from "ol/layer/Heatmap";
import VectorSource from "ol/source/Vector";
import Utils from "./utils";

export default {
  components:{
    HeadNav,
    LeftMenu,
    'TTT':TTT
  },
  name: "ThreeDVisualize",
  data(){
    return{
      timer:null,
      isShowDrag:true,
      has_set_interval:false,
      has_set:0,  //记录react子组件是否设置过
      n_heats:0,
      heat_name:null,
      layer_name:[],
      test:[],
      heat_data:{},
      grid_data:{},
      control_show:1,
      visible_heat:null,
      visible_grid:null,
      visible_scatter:1,
      trip_data:null,
      radius:1000,
    }
  },
  //自定义指令
  directives: {
    drag: {
      // 指令的定义
      bind: function(el) {
        let oDiv = el;  // 获取当前元素
        oDiv.onmousedown = (e) => {
          // 算出鼠标相对元素的位置
          let disX = e.clientX - oDiv.offsetLeft;
          let disY = e.clientY - oDiv.offsetTop;

          document.onmousemove = (e) => {
            // 用鼠标的位置减去鼠标相对元素的位置，得到元素的位置
            let left = e.clientX - disX;
            let top = e.clientY - disY;

            oDiv.style.left = left + 'px';
            oDiv.style.top = top + 'px';

          };

          document.onmouseup = (e) => {
            document.onmousemove = null;
            document.onmouseup = null;
          }
        }
      }
    }
  },
  mounted() {
    //监听重置事件
    let that=this
    Utils.$on('reset', function () {
      that.reset()
    })
    //挂载点击事件，从而实现动态为控件绑定onclick
    window.show_hide_layer = this.show_hide_layer
    //初始化
    this.init()
    //监听事件
    this.$root.$on('on_simulation',()=>{    //监听仿真启动事件(启动or继续)
      if(this.has_set_interval===true)
        return
      setInterval(this.update_heats,4000)
      this.has_set_interval=true
    })
  },
  activated() {
    if(this.has_set_interval===true)
      return
    this.$root.$on('on_simulation',()=>{    //监听仿真启动事件(启动or继续)
      if(this.has_set_interval===true)
        return
      this.timer=setInterval(this.update_heats,2000)
      this.has_set_interval=true
    })
  },
  methods:{
    reset:function(){
      clearTimeout(this.timer)
      for(let i=0;i<this.n_heats;i++)
        this.heat_data[this.heat_name[i]]=[]
      this.grid_data={}
      this.visible_heat={}
      this.visible_grid={}
      for(let i=0;i<this.n_heats;i++)
        this.visible_heat[this.heat_name[i]]=0
      for(let i=0;i<this.n_heats;i++)
        this.visible_grid[this.heat_name[i]]=0
      this.has_set_interval=false
    },
    init:function(){
      //从后端获取n_node和node_name信息
      let that=this
      axios.get('http://127.0.0.1:5000/get_nodes_info').then( function(response) {
        let info = response.data
        that.n_heats=info['n_nodes']
        that.heat_name=info['node_name']
        for(let i=0;i<that.n_heats;i++)
          that.heat_data[that.heat_name[i]]=[]
        that.visible_heat={}
        that.visible_grid={}
        for(let i=0;i<that.n_heats;i++)
          that.visible_heat[that.heat_name[i]]=0
        for(let i=0;i<that.n_heats;i++)
          that.visible_grid[that.heat_name[i]]=0
        that.visible_scatter=1
        //初始化图层选项框（动态创建条目）
        for(let i=0;i<that.n_heats;i++){
          let grid_content=document.getElementById('grid_content')
          let div_item=document.createElement('div')
          let label=document.createElement('label')
          label.innerText=that.heat_name[i]
          label.style.position='relative'
          label.style.color='black'
          label.style.fontWeight='bold'
          let label_text=document.createElement('label')
          label_text.style.position='relative'
          label_text.style.right=String(-86)+'px'
          label_text.style.color='black'
          label_text.setAttribute('class','control-item-text')
          label_text.innerText='显示/隐藏'
          let input=document.createElement('input')
          input.setAttribute('type','checkbox')
          input.setAttribute('class','control-checkbox')
          input.setAttribute('id','grid'+that.heat_name[i])
          input.setAttribute('onclick',"show_hide_layer(this)")
          input.style.position='relative'
          input.style.right=String(-90)+'px'
          input.style.top=String(2)+'px'
          div_item.appendChild(label)
          div_item.appendChild(label_text)
          div_item.appendChild(input)
          div_item.style.position='relative'
          div_item.style.top=String(15+15*i)+'px'
          div_item.style.right=String(-30)+'px'
          grid_content.appendChild(div_item)
        }
      })
      axios.get('http://127.0.0.1:5000/get_trip_data').then( function(response) {
        let info = response.data
        that.trip_data=info
        console.log('trips in axios:',that.trip_data)
      })
    },
    update_heats:function () {
      let that=this
      axios.get('http://127.0.0.1:5000/get_heats_3d').then(function(response){
        let data = response.data
        that.heat_data=data['heat_data']
        that.grid_data=data['grid_data']
      })
    },
    show_hide_layer:function(obj){  //点击checkbox显示或隐藏图层
      let name=obj.getAttribute('id')
      if(name[0]==='g') {
        let ke=name.substr(4,name.length-4)
        if (obj.checked === true)
          this.visible_grid[ke] = 1
        else
          this.visible_grid[ke] = 0
      }
      else if(name[0]==='h') {
        let ke=name.substr(4,name.length-4)
        if (obj.checked === true)
          this.visible_heat[ke] = 1
        else
          this.visible_heat[ke] = 0
      }
      else if(name[0]==='s') {
        if (obj.checked === true)
          this.visible_scatter= 1
        else
          this.visible_scatter = 0
      }
      let names=Object.keys(this.visible_heat)
      let temp_heat={}
      for(let i=0;i<names.length;i++)
        temp_heat[names[i]]=this.visible_heat[names[i]]
      names=Object.keys(this.visible_grid)
      let temp_grid={}
      for(let i=0;i<names.length;i++)
        temp_grid[names[i]]=this.visible_grid[names[i]]
      this.visible_heat=temp_heat
      this.visible_grid=temp_grid
    },
    show_heat_options:function () {
      this.control_show=0
    },
    show_grid_options:function () {
      this.control_show=1
    },
    show_trip_options:function () {
      this.control_show=2
    },
  }
}

</script>

<style scoped>
.map_container {
  position: relative;
  z-index: 1;
  width: 1518px;
  height: 725px;
  left:182px;
  top:3px;
  border-radius: 4px;
  padding-left: 4px;
  padding-top: 3px;
  box-shadow: 2px 2px 4px #aaaaaa;
  background: #ffffff;
}

.control-panel{
  font: 14px / 20px UberMove, Helvetica, Arial, sans-serif;
  position: absolute;
  top: 0px;
  right: 15px;
  width: 230px;
  height:200px;
  background: rgb(255, 255, 255);
  outline: none;
  z-index: 15;
  border-radius: 3px;
  box-shadow: 2px 2px 4px #aaaaaa;
}
.control_options {
  position:relative;
  width:100%;
  top:6px;
  left:30px;
}
.control-container {
  position:relative;
  width:100%;
  top:15px;
  height: 100px;
}
</style>
