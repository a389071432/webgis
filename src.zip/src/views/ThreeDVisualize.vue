<template>
  <div>
    <HeadNav></HeadNav>
    <leftMenu></leftMenu>
    <div class="heat_options_content" id="heat_options_content">
    </div>
    <div class="map_container">
      <TTT :heatNames="heat_name" :heatData="heat_data"  :gridData="grid_data"  :tripData="trip_data"  :visible="visible" :radius="radius" />
    </div>
  </div>
</template>

<script>
import TTT from './components/react_deckgl'
import {renderToDOM} from "./components/react_deckgl";
import HeadNav from "../components/HeadNav";
import LeftMenu from "../components/LeftMenu";
import axios from "axios";
import Heatmap from "ol/layer/Heatmap";
import VectorSource from "ol/source/Vector";

export default {
  components:{
    HeadNav,
    LeftMenu,
    'TTT':TTT
  },
  name: "ThreeDVisualize",
  data(){
    return{
      has_set_interval:false,
      has_set:0,  //记录react子组件是否设置过
      n_heats:0,
      heat_name:null,
      layer_name:[],
      test:[],
      heat_data:{},
      grid_data:{},
      visible:{},
      trip_data:null,
      radius:1000,
    }
  },
  mounted() {
    //挂载点击事件，从而实现动态为控件绑定onclick
    window.show_hide_layer = this.show_hide_layer
    //初始化
    this.init()
    //监听事件
    this.$root.$on('on_simulation',()=>{    //监听仿真启动事件(启动or继续)
      if(this.has_set_interval===true)
        return
      setInterval(this.update_heats,4000)
      this.has_set_interval=true
    })
  },
  activated() {
    if(this.has_set_interval===true)
      return
    this.$root.$on('on_simulation',()=>{    //监听仿真启动事件(启动or继续)
      if(this.has_set_interval===true)
        return
      setInterval(this.update_heats,2000)
      this.has_set_interval=true
    })
  },
  methods:{
    init:function(){
      //从后端获取n_node和node_name信息
      let that=this
      axios.get('http://127.0.0.1:5000/get_nodes_info').then( function(response) {
        let info = response.data
        that.n_heats=info['n_nodes']
        that.heat_name=info['node_name']
        for(let i=0;i<that.n_heats;i++)
          that.heat_data[that.heat_name[i]]=[]
        for(let i=0;i<that.n_heats;i++)
          that.visible[that.heat_name[i]]=false
        that.visible['I']=true
        //在下拉框显示图层名称
        for(let i=0;i<that.n_heats;i++)
          that.layer_name.push({'name':that.heat_name[i]})
        //初始化图层选项框（动态创建条目）
        // for(let i=0;i<that.n_heats;i++){
        //   let heat_options_contents=document.getElementById('heat_options_content')
        //   let div_item=document.createElement('div')
        //   let label=document.createElement('label')
        //   label.innerText=that.heat_name[i]
        //   let label_text=document.createElement('label')
        //   label_text.setAttribute('class','control-item-text')
        //   label_text.innerText='显示/隐藏'
        //   let input=document.createElement('input')
        //   input.setAttribute('type','checkbox')
        //   input.setAttribute('class','control-checkbox')
        //   input.setAttribute('id',that.heat_name[i])
        //   input.setAttribute('onclick',"show_hide_layer(this)")
        //   div_item.appendChild(label)
        //   div_item.appendChild(label_text)
        //   div_item.appendChild(input)
        //   div_item.style.position='relative'
        //   div_item.style.top=String(15+35*i)+'px'
        //   heat_options_contents.appendChild(div_item)
        // }
      })
      axios.get('http://127.0.0.1:5000/get_nodes_info').then( function(response) {
        let info = response.data
        that.trip_data=info
      })
    },
    update_heats:function () {
      let that=this
      axios.get('http://127.0.0.1:5000/get_heats_3d').then(function(response){
        let data = response.data
        that.heat_data=data['heat_data']
        that.grid_data=data['grid_data']
      })
    },
    show_hide_layer:function(obj){  //点击checkbox显示或隐藏图层
      let name=obj.getAttribute('id')
      if(obj.checked===true)
        this.visible[name]=true
      else
        this.visible[name]=false
    },
  }
}

</script>

<style scoped>
.map_container {
  position: relative;
  z-index: 1;
  width: 1518px;
  height: 725px;
  left:182px;
  top:3px;
  border-radius: 4px;
  padding-left: 4px;
  padding-top: 3px;
  box-shadow: 2px 2px 4px #aaaaaa;
  background: #ffffff;
}
</style>
