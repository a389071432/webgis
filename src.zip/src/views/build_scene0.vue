<template>
  <div>
    <div class="step_container">
      <el-steps  :active="active" finish-status="success" align-center :space="520" style="width: 90%; margin-bottom: 12px;">
        <el-step title="构建Agent"></el-step>
        <el-step title="城市建筑数据"></el-step>
        <el-step title="城市用地数据"></el-step>
        <el-step title="人口分布数据"></el-step>
        <el-step title="感染模型"></el-step>
        <el-step title="参数设置"></el-step>
        <el-step title="场景构建完毕"></el-step>
      </el-steps>
    </div>
    <div class="main_container">
      <transition name="slide-fade" >
        <div  v-show="this.show0===1">
          <div class="box_container box_step00">
          <div class="tip" style="position: relative;top:30px">
            <i class="bb-title">上传人口数据</i>
            <img src="../assets/details.png" @click="show_details0" alt="说明" style="position:relative;left: 156px; top:-8px; width: 22px;height: 22px;">
          </div>
          <step0 class="step0" ref="step0"></step0>
          <el-dialog title="Agent数据" :visible.sync="visible0" center @close="close0" >
            <div style="height:400px;">
              <p>请按如下格式上传数据文件，该文件描述每个Agent的基本属性和活动模式：</p>
              <img src="../assets/tip_agent.png" style="width:700px;">
            </div>
          </el-dialog>
          </div>
          <div class="box_container box_step01">
            <div class="tip" style="position: relative;left:-30px;top:30px">
              <i class="bb-title">上传活动模式数据</i>
              <img src="../assets/details.png" @click="show_details0" alt="说明" style="position:relative;left: 156px; top:-8px; width: 22px;height: 22px;">
            </div>
            <step0 class="step0" ref="step0"></step0>
            <el-dialog title="Agent数据" :visible.sync="visible0" center @close="close0" >
              <div style="height:400px;">
                <p>请按如下格式上传数据文件，该文件描述每个Agent的基本属性和活动模式：</p>
                <img src="../assets/tip_agent.png" style="width:700px;">
              </div>
            </el-dialog>
          </div>
        </div>
      </transition>
      <transition name="slide-fade" >
        <div class="box_container box_step1" v-show="this.show1===1">
          <div class="tip">
            <i class="bb-title">上传城市建筑图层</i>
            <img src="../assets/details.png" @click="show_details1" alt="说明" style="position:relative;left: 156px; top:-8px; width: 22px;height: 22px;">
          </div>
          <step1 class="step1" ref="step1"></step1>
          <el-dialog title="城市建筑数据" :visible.sync="visible1" center @close="close1" >
            <div style="height:500px;">
              <p style="position: relative;left:200px;font-size: 15px;">请输入您存储在GeoServer服务器上的数据url地址，下图是一个示例：</p>
              <img src="../assets/tip_buildings.png" style="position:relative; left:200px;width: 350px;height: 210px;top:10px;">
            </div>
          </el-dialog>
        </div>
      </transition>
      <transition name="slide-fade">
        <div class="box_container box_step2" v-show="this.show2===1">
          <div class="tip">
            <i class="bb-title">上传城市用地图层</i>
            <img src="../assets/details.png" @click="show_details2" alt="说明" style="position:relative;left: 156px; top:-8px; width: 22px;height: 22px;">
          </div>
          <step2 class="step2" ref="step2"></step2>
          <el-dialog title="城用地数据" :visible.sync="visible2" center @close="close2" >
            <div style="height:500px;">
              <p style="position:relative;left: 150px;font-size: 15px;" >城市用地数据格式为shapefile，每个条目描述一个用地信息，下图是一个条目示例：</p>
              <img style="position:relative;left:120px; width: 600px;" src="../assets/tip_land.png">
              <p style="position:relative;left: 80px;font-size: 15px;">其中，'type'属性表示用地类型，0表示住宅用地，1表示商业用地，2表示公共单位用地，3表示休闲用地</p>
            </div>
          </el-dialog>
        </div>
      </transition>
      <transition name="slide-fade">
        <div class="box_container box_step2" v-show="this.show3===1">
          <div class="tip">
            <i class="bb-title">上传人口分布图层</i>
            <img src="../assets/details.png" @click="show_details3" alt="说明" style="position:relative;left: 156px; top:-8px; width: 22px;height: 22px;">
          </div>
          <step3 class="step1" ref="step33"></step3>
          <el-dialog title="人口分布数据" :visible.sync="visible3" center @close="close3" >
            <div style="height:500px;">
              <p style="position:relative;left: 150px;font-size: 15px;" >城市用地数据格式为shapefile，每个条目描述一个用地信息，下图是一个条目示例：</p>
              <img style="position:relative;left:120px; width: 600px;" src="../assets/tip_population.png">
              <p style="position:relative;left: 80px;font-size: 15px;">其中，'population'属性表示区域内人口数量</p>
            </div>
          </el-dialog>
        </div>
      </transition>
      <transition name="slide-fade">
        <div class="box_container box_step3" v-show="this.show4===1">
          <div style="left:470px;"  class="tip">
            <i class="bb-title">编辑感染模型</i>
            <img src="../assets/details.png" @click="show_details4" alt="说明" style="position:relative;left: 156px; top:-8px; width: 22px;height: 22px;">
          </div>
          <editable_form class="step3" ref="step3"></editable_form>
          <el-dialog title="感染状态模型" :visible.sync="visible4" center @close="close4" >
            <div style="height:500px;">
              <p>定义状态转移图：图中的每个结点表示一个状态，每个边表示两个状态间的转化关系
                下图是一个状态转移图的示例：</p>
              <img src="../assets/SIR.png">
              <p>您可编辑表格来定义状态转移图，表格中的每项描述一条边。上面的状态转移图可由下面的表格描述：</p>
              <img src="../assets/tip_model.png">
            </div>
          </el-dialog>
        </div>
      </transition>
      <transition name="slide-fade">
        <div class="box_container box_step4" v-show="this.show5===1">
          <div class="box_step4_0">
            <label style="font-size: 17px;font-weight: bold">接触频次设置</label>
            <div class="line"></div>
            <div class="control-item" style="position:relative;top:20px;">
              <label style="position: relative;top:3px;">住宅区：</label>
              <input type="text" id="input0" class="control-input" style="position:relative;top:2px;left:80px;width:40px;height:20px;"></input>
            </div>
            <div class="control-item" style="position:relative;top:45px;">
              <label style="position: relative;top:3px;">商业区：</label>
              <input type="text" id="input1" class="control-input" style="position:relative;top:2px;left:80px;width:40px;height:20px;"></input>
            </div>
            <div class="control-item" style="position:relative;top:80px;">
              <label style="position: relative;top:3px;">休闲区：</label>
              <input type="text" id="input2" class="control-input" style="position:relative;top:2px;left:80px;width:40px;height:20px;"></input>
            </div>
            <div class="control-item" style="position:relative;top:115px;">
              <label style="position: relative;top:3px;">公共区：</label>
              <input type="text"  id="input3" class="control-input" style="position:relative;top:2px;left:80px;width:40px;height:20px;"></input>
            </div>
            <label style="font-size: 17px; font-weight:bold; position:relative;top:165px;">接触传染概率设置</label>
            <div class="line" style="position: relative;top:170px;"></div>
            <div class="control-item" style="position:relative;top:200px;">
              <label>传染概率：</label>
              <input type="text" id="input4" class="control-input" style="position:relative;top:2px;left:67px;width:40px;height:20px;"></input>
            </div>
          </div>
          <div style="position: relative;left:200px;top:0px;">
            <div style="position: relative;left:530px;top:-240px;">
              <label style="font-size: 17px;font-weight: bold;width:80px;">状态</label>
              <label style="position: relative;left:0px;font-weight: bold">传染性</label>
              <label style="position: relative;left:16px;font-weight: bold">被隔离</label>
              <label style="position: relative;left:32px;font-weight: bold">免疫性</label>
              <div class="line" ></div>
            </div>
            <div class="box_step4_1" id="box_step4_1"></div>
          </div>
        </div>
      </transition>
    </div>
    <div class="button_container">
      <el-button style="margin-top:12px;" @click="pre">上一步</el-button>
      <div style="width:70px"></div>
      <el-button id="next" style="margin-top:12px;" @click="next">下一步</el-button>
    </div>
  </div>
</template>

<script>
import step0 from './components/step0'
import step1 from './components/step1'
import step2 from './components/step2'
import step3 from './components/step3'
import editable_form from "./editable_form";
import Editable_form from "./editable_form";
import axios from "axios";
import Feature from "ol/Feature";
import Point from "ol/geom/Point";

export default {
  name: "build_scene",
  components:{
    Editable_form,
    step0,
    step1,
    step2,
    step3,
    editable_form
  },

  data(){
    return{
      build_cnt:-1,
      active: 0,
      visible0:false,
      visible1:false,
      visible2:false,
      visible3:false,
      visible4:false,
      show0:1,
      show1:0,
      show2:0,
      show3:0,
      show4:0,
      show5:0,
      n_nodes:-1,
    };
  },
  async mounted() {
    await this.init()
  },
  methods:{
    async init(){
      let msg=await axios.post('http://222.94.162.146:5000/init_globvars')
    },
    async next(){
      let msg
      if(this.active===0){
        msg=await this.$refs.step0.submit()
        if(msg==='ok'){
          this.show0=0
          let that=this
          setTimeout(function () {
            that.show1=1
            that.active++
          }, 1000)
        }
        else{   //提示错误信息，待补充

        }
      }
      else if(this.active===1){
        msg=await this.$refs.step1.submitForm()
        if(msg==='ok'){
          this.show1=0
          let that=this
          setTimeout(function () {
            that.show2=1
            that.active++
          }, 1000)
        }
        else{   //提示错误信息，待补充

        }
      }
      else if(this.active===2){
        msg=await this.$refs.step2.submitForm()
        if(msg==='ok'){
          this.show2=0
          let that=this
          setTimeout(function () {
            that.show3=1
            that.active++
          }, 1000)
        }
        else{   //提示错误信息，待补充

        }
      }
      else if(this.active===3){
        msg=await this.$refs.step33.submitForm()
        if(msg==='ok'){
          this.show3=0
          let that=this
          setTimeout(function () {
            that.show4=1
            that.active++
          }, 1000)
        }
        else{   //提示错误信息，待补充

        }
      }
      else if(this.active===4){
        msg=await this.$refs.step3.submitForm()
        if(msg==='ok'){
          this.show4=0
          let that=this
          let table_data=this.$refs.step3.table_data
          //统计table_data的结点信息，用于下步渲染
          let n_nodes=0
          let node_name=[]
          let temp={}
          for(let k=0;k<table_data.length;k++){
            let node0=table_data[k].state0
            let node1=table_data[k].state1
            if(!temp.hasOwnProperty(node0)){
              temp[node0]=1
              n_nodes+=1
              node_name.push(node0)
            }
            if(!temp.hasOwnProperty(node1)){
              temp[node1]=1
              n_nodes+=1
              node_name.push(node1)
            }
          }
          this.n_nodes=n_nodes
          //动态生成结点列表
          let inter=35
          for(let k=0;k<node_name.length;k++){
            let div=document.createElement('div')
            div.setAttribute('class','control-item')
            div.style.position='relative'
            div.style.top=String(20+k*inter)+'px'
            let label=document.createElement('label')
            label.innerText=node_name[k]
            label.setAttribute('class','label')
            let input0=document.createElement('input')
            input0.setAttribute('type','checkbox')
            input0.setAttribute('class','checkbox0')
            input0.setAttribute('id','check'+String(k)+'0')
            let input1=document.createElement('input')
            input1.setAttribute('type','checkbox')
            input1.setAttribute('class','checkbox1')
            input1.setAttribute('id','check'+String(k)+'1')
            let input2=document.createElement('input')
            input2.setAttribute('type','checkbox')
            input2.setAttribute('class','checkbox2')
            input2.setAttribute('id','check'+String(k)+'2')
            label.style.position='relative'
            label.style.color='black'
            label.style.left='8px'
            label.style.width='100px'
            label.style.fontSize='16px'
            input0.style.position='relative'
            input0.style.left='0px'
            input1.style.position='relative'
            input1.style.left='55px'
            input2.style.position='relative'
            input2.style.left='110px'
            div.appendChild(label)
            div.appendChild(input0)
            div.appendChild(input1)
            div.appendChild(input2)
            document.getElementById('box_step4_1').appendChild(div)
          }
          setTimeout(function () {
            that.show5=1
            that.active++
          }, 1000);

        }
        else{   //提示错误信息，待补充

        }
      }
      else if(this.active===5){
        let c0=document.getElementById('input0').value
        let c1=document.getElementById('input1').value
        let c2=document.getElementById('input2').value
        let c3=document.getElementById('input3').value
        let p=document.getElementById('input4').value
        let node_infectivity=[]
        let node_quarantine=[]
        for(let x=0;x<this.n_nodes;x++){
          if(document.getElementById('check'+String(x)+'0').checked===true)
            node_infectivity.push(1)
          else
            node_infectivity.push(0)
          if(document.getElementById('check'+String(x)+'1').checked===true)
            node_quarantine.push(1)
          else
            node_quarantine.push(0)
        }
        msg=await new Promise((resolve,reject) => {
          axios.post('http://222.94.162.146:5000/upload_infected_params',{land_contacts:[c0,c1,c2,c3],p:p,node_infectivity:node_infectivity,node_quarantine:node_quarantine}).then(res => {
            resolve(res.data)
          }).catch(error => {

          })
        })
        if(msg==='ok'){
          this.active++
          console.log('完成')
          document.getElementById('next').innerText='完成'
        }
        else{   //提示错误信息，待补充

        }
      }
      else if(this.active===6){  //数据准备完毕
        //要求后端构建场景
        let that=this
        axios.get('http://222.94.162.146:5000/construct_scene').then( function(response) {
          let ans = response.data
          if(ans==='ok'){ //成功后跳转至仿真页面
            console.log('form in build_scene',that.$refs.step3.table_data)
            that.build_cnt+=1
            that.$router.push({name:'ol_home',params:{table_data:that.$refs.step3.table_data,build_cnt:that.build_cnt}})
          }
        }).catch(function (error) {
          //提示错误信息，待补充
        })

      }
      if(this.active>6)
        this.active = 0
    },
    pre() {
      if(this.active===6){
        document.getElementById('next').innerText='下一步';
        this.active--
      }
      if(this.active===5){
        this.show5=0
        let that=this
        document.getElementById('box_step4_1').innerHTML=''
        setTimeout(function () {
          that.show4=1
          that.active--
        }, 1000);
      }
      else if(this.active===4){
        this.show4=0
        let that=this
        setTimeout(function () {
          that.show3=1
          that.active--
        }, 1000);
      }
      else if(this.active===3){
        this.show3=0
        let that=this
        setTimeout(function () {
          that.show2=1
          that.active--
        }, 1000);
      }
      else if(this.active===2){
        this.show2=0
        let that=this
        setTimeout(function () {
          that.show1=1
          that.active--
        }, 1000);
      }
      else if(this.active===1){
        this.show1=0
        let that=this
        setTimeout(function () {
          that.show0=1
          that.active--
        }, 1000);
      }
    },
    show_details0(){
      this.visible0=true
    },
    show_details1(){
      this.visible1=true
    },
    show_details2(){
      this.visible2=true
    },
    show_details3(){
      this.visible3=true
    },
    show_details4(){
      this.visible3=true
    },
    close0(){
      this.visible0=false
    },
    close1(){
      this.visible1=false
    },
    close2(){
      this.visible2=false
    },
    close3(){
      this.visible3=false
    },
    close4(){
      this.visible4=false
    },
  }
}
</script>

<style scoped>

.step_container{
  position: relative;
  height: 100px;
  width: 100%;
  display: flex;
  justify-content: space-around;
  align-items: flex-end;
}
.main_container{
  position: relative;
  top:15px;
  width: 100%;
  height:535px;
}
.button_container{
  position: relative;
  display: flex;
  display: -webkit-flex;
  flex-direction: row;
  justify-content: center;
  align-content: center;
  width: 100%;
  left:-50px;
}
.box_container{

}
.box_step00{
  width: 100%;
  height:420px;
  padding-left: 590px;
  padding-top: 100px;
  position: relative;
  left:-270px;
}
.box_step01{
  width: 100%;
  height:420px;
  padding-left: 590px;
  padding-top: 100px;
  position: relative;
  top:-420px;
  left:300px;
}
.box_step1{
  width: 100%;
  height:420px;
  padding-left: 590px;
  padding-top: 100px;
}
.box_step2{
  width: 100%;
  height:420px;
  padding-left: 590px;
  padding-top: 100px;
}
.box_step3{
  width: 100%;
  height:420px;
  padding-left: 200px;
  padding-top: 100px;
}

.tip{
  position: relative;
  display: flex;
  display: -webkit-flex;
  flex-direction: row;
}
.bb-title{
  position:relative;
  top: -10px;
  left: 150px;
  font-size: 18px;
  font-weight: 700;
  color:black;
  padding-left: 16px;
}

.box_step3{
  width: 900px;
  height:420px;
  padding-left: 130px;
}

.box0{
  padding-left: 130px;
  padding-bottom: 0;
  padding-top: 0;
  width:45%;
  display: flex;
  flex-wrap: wrap;
  flex-direction: column;
  align-content: flex-start;
}
.box1{
  padding-left: 0px;
  padding-bottom: 0;
  padding-top: 0;
  width:55%;
}
.step1{
  position: relative;
  top:30px;
}
.step2{
  position: relative;
  top:30px;
}
.step3{
  position: relative;
  left:330px;
  top:30px;
}

.slide-fade-enter-active {
  transition: all .25s linear;
}
.slide-fade-leave-active {
  transition: all .25s linear;
}
.slide-fade-enter, .slide-fade-leave-to {
  transform: translateX(-200px);
  opacity: 0;
}


label{
  color:black;
}

.control-input {
  position:relative;
  left:30px;
  top:3px;
}

.box_step4_0 {
  position:relative;
  top:10px;
  left:210px;
  width:170px;
  height: 250px;
}

.box_step4_1 {
  position: relative;
  left:530px;
  top:-240px;
}
.box_step4 {
  position: relative;
  top:40px;
  left:180px;
}

.line{
  position: relative;
  top:4px;
  height:2px;
  width: 340px;
  background: gray;
}

</style>
