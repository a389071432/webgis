<template>
  <div>
  <HeadNav></HeadNav>
  <leftMenu></leftMenu>
    <div id="control-panel">
      <div>
        <label>Radius</label>
        <input id="radius" type="range" min="500" max="10000" step="500" value="1000"></input>
        <span id="radius-value"></span>
      </div>
      <div>
        <label>Coverage</label>
        <input id="coverage" type="range" min="0" max="1" step="0.1" value="1"></input>
        <span id="coverage-value"></span>
      </div>
      <div>
        <label>Upper Percentile</label>
        <input id="upperPercentile" type="range" min="90" max="100" step="1" value="100"></input>
        <span id="upperPercentile-value"></span>
      </div>
    </div>
  <div id="map" ref="rootmap"></div>
  </div>
</template>

<script>
import HeadNav from "../components/HeadNav";
import LeftMenu from "../components/LeftMenu";
import mapboxgl from '!mapbox-gl';
import 'mapbox-gl/dist/mapbox-gl.css'
import { ScreenGridLayer,HexagonLayer} from '@deck.gl/aggregation-layers';
import {ScatterplotLayer} from '@deck.gl/layers';
import { MapboxLayer } from "@deck.gl/mapbox";
import {Deck, MapView, OrthographicView} from '@deck.gl/core';
import * as d3 from "d3";
import React, {useState, useEffect} from 'react';
import {AmbientLight, PointLight, LightingEffect} from '@deck.gl/core';
import {ArcLayer} from '@deck.gl/layers';
import {LineLayer} from '@deck.gl/layers';
import {TripsLayer} from '@deck.gl/geo-layers';

export default {
  name: "visualization_3d",
  components:{
    HeadNav,
    LeftMenu
  },
  data() {
    return {
      tripLayer:null,
      scatterLayer:null,
      arcLayer:null,
      hexagonLayer:null,
      lineLayer:null,
      grid_size:4500,  //单个网格的尺寸（单位：米）
      commuting_data:null,  //城市通勤分布数据，目前随机生成
      grid_targets:null, //从单个城市网格出发的轨迹集合
      grid_info:null,    //每个城市网格的信息，格式[{position,流量}]
      heat_data:null,
      deck:null,
      map: null,
      OPTIONS: ['radius', 'coverage', 'upperPercentile'],
      COLOR_RANGE: [
        [255, 255, 178, 25],
        [254, 217, 118, 85],
        [254, 178, 76, 127],
        [253, 141, 60, 170],
        [240, 59, 32, 212],
        [189, 0, 38, 255]
      ],
      LIGHT_SETTINGS: {
        lightsPosition: [-0.144528, 49.739968, 8000, -3.807751, 54.104682, 8000],
        ambientRatio: 0.4,
        diffuseRatio: 0.6,
        specularRatio: 0.2,
        lightsStrength: [0.8, 0.0, 0.8, 0.0],
        numberOfLights: 2
      }
    }
  },
  mounted() {
    this.init()
  },
  methods: {
    init() {
      //初始化mapbox,用于存放底图
      mapboxgl.accessToken = 'pk.eyJ1IjoiYTM4OTA3MTQzMiIsImEiOiJjbDFza3p4ZWwwbXdnM2JvODU4ZDQ4ZXVuIn0.GZLKrxOW8KLL2gy0mTFpPA'
      this.map = new mapboxgl.Map({
        container: 'map',
        style: 'mapbox://styles/mapbox/dark-v10?optimize=true',
        center: [-1.4157, 52.2324],
        zoom: 10,
        maxZoom: 16,
        pitch: 40.5,
        antialias: true,
        bearing: 0
      });
      this.map.addControl(new mapboxgl.NavigationControl(), 'top-right')
      this.map.addControl(new mapboxgl.ScaleControl({ maxWidth: 80, unit: 'metric' }),'bottom-right')
      this.map.addControl(new mapboxgl.FullscreenControl({container: document.querySelector('map')}),'top-right')
      //初始化deck，存放其他可视化图层
      let colorRange = [
        [1, 152, 189],
        [73, 227, 206],
        [216, 254, 181],
        [254, 237, 177],
        [254, 173, 84],
        [209, 55, 78]
      ]
      let coverage=1
      let radius=1000
      let upperPercentile=100
      const material = {
        ambient: 0.64,
        diffuse: 0.6,
        shininess: 32,
        specularColor: [51, 51, 51]
      };
       this.heat_data=new Array()
      for(let i=0;i<200;i++)
        this.heat_data.push({lng:'-0.198465',lat:'51.505538'})
      for(let i=0;i<200;i++)
        this.heat_data.push({lng:'-1.110000',lat:'52.630000'})
      for(let i=0;i<100;i++)
        this.heat_data.push({lng:'-1.130000',lat:'52.950000'})
      const DATA_URL =
        'https://raw.githubusercontent.com/visgl/deck.gl-data/master/examples/3d-heatmap/heatmap-data.csv'
      require('d3-request').csv(DATA_URL, (error, response) => {
        if (!error) {
          const data = response.map(d => [Number(d.lng), Number(d.lat)]);
        }
      });

      //随机生成commuting数据
      this.generate_commuting_data()
      //将commuting数据注册到每个网格
      this.assign_commuting_data_to_grid()
      //初始化各图层
      this.initLayers()
      //注册滑动事件
      let OPTIONS = ['radius', 'coverage', 'upperPercentile'];
      OPTIONS.forEach(key => {
          document.getElementById(key).onchange = (evt) => {
            let value = Number(evt.target.value);
            document.getElementById(key + '-value').innerHTML = value;
            if (this.hexagonLayer) {
              this.hexagonLayer.setProps({
                [key]: value });
            }
          }
      })
    },
    generate_commuting_data(){
       this.commuting_data=[]
       for(let i=0;i<25000;i++){
         let lon=121.12548861+(121.66357585-121.12548861)*Math.random()
         let lat=31.0827875+(31.41700379-31.0827875)*Math.random()
         let from=[lon,lat]
         lon=121.12548861+(121.66357585-121.12548861)*Math.random()
         lat=31.0827875+(31.41700379-31.0827875)*Math.random()
         let to=[lon,lat]
         this.commuting_data.push({from:from,to:to})
       }
    },
    assign_commuting_data_to_grid(){
      let dlat=this.grid_size/(1000*111)
      let dlon=dlat
      let nlat=Math.ceil((31.41700379-31.0827875)/dlat)
      let nlon=Math.ceil((121.66357585-121.12548861)/dlon)
      this.grid_targets=new Array(nlat*nlon)  //索引index=y*nlon+x，x方向是经度，y方向是纬度
      for(let i=0;i<this.grid_targets.length;i++)
        this.grid_targets[i]=[]
      this.grid_info=new Array(nlat*nlon)
      for(let x=0;x<nlon;x++){
        for(let y=0;y<nlat;y++){
           let grid_index=x*nlat+y
           this.grid_info[grid_index]={position:[121.12548861+x*dlon,31.0827875+y*dlat],value:0}
        }
      }
      for(let i=0;i<this.commuting_data.length;i++){
        let from=this.commuting_data[i].from
        let to=this.commuting_data[i].to
        let grid_index=Math.floor((from[1]-31.0827875)/dlat)*nlon+Math.floor((from[0]-121.12548861)/dlon)
        this.grid_targets[grid_index].push({target:to,source:from})
        this.grid_info[grid_index].value+=1
      }
      console.log('assign done')
    },
    initLayers() {
      // migrate out
      const SOURCE_COLOR = [166, 3, 3]
      // migrate in
      const TARGET_COLOR = [35, 181, 184]
      //添加OD图层（3D），同时只渲染从一个网格出发的轨迹线
      this.arcLayer = new MapboxLayer({
        type: ArcLayer,
        id: 'arc',
        data: null,
        brushRadius: 100000,
        opacity: 1,
        getSourcePosition: d => d.source,
        getTargetPosition: d => d.target,
        getSourceColor: SOURCE_COLOR,
        getTargetColor: TARGET_COLOR
      });
      //添加OD图层（2D）
      this.lineLayer = new MapboxLayer({
        type:LineLayer,
        id: 'line',
        data:null,
        pickable: true,
        getWidth: 1,
        getSourcePosition: d => d.source,
        getTargetPosition: d => d.target,
        getColor: [255, 140, 0]
      });
      //添加散点图层，每个城市网格对应一个散点
      const RADIUS_SCALE = d3.scaleSqrt().domain([0, 800]).range([100, 1000]);
        this.scatterLayer = new MapboxLayer({
        type: ScatterplotLayer,
        id: 'scatter',
        data: this.grid_info,
        opacity: 1,
        pickable: true,
        onHover: (info, event) => that.show_arcs_by_grid(info),
        getPosition:d => d.position,
        getRadius: 120,
        getFillColor:d => [255, 140, 0]
      });
      //添加heatmap图层
      const DATA_URL =
        'https://raw.githubusercontent.com/visgl/deck.gl-data/master/examples/3d-heatmap/heatmap-data.csv'
      let that = this
      let deck=this.deck
      this.map.on('load', function() {
        //that.map.addLayer(new MapboxLayer({id: 'heatmap', deck}));
        let  h_data;
        const colorRange = [
          [1, 152, 189],
          [73, 227, 206],
          [216, 254, 181],
          [254, 237, 177],
          [254, 173, 84],
          [209, 55, 78]
        ];
        const LIGHT_SETTINGS = {
          lightsPosition: [-0.144528, 49.739968, 8000, -3.807751, 54.104682, 8000],
          ambientRatio: 0.4,
          diffuseRatio: 0.6,
          specularRatio: 0.2,
          lightsStrength: [0.8, 0.0, 0.8, 0.0],
          numberOfLights: 10
        };
        d3.csv(DATA_URL).then(
          function(data){
            h_data=data
              that.hexagonLayer= new MapboxLayer({
              type: HexagonLayer,
              id: 'heatmap',
              data: h_data,
              radius: 1000,
              coverage: 1,
              upperPercentile: 100,
              colorRange: colorRange,
              elevationRange: [0, 1000],
              elevationScale: 250,
              extruded: true,
              getPosition: d => [Number(d.lng), Number(d.lat)],
              lightSettings: LIGHT_SETTINGS,
              opacity: 0.6
            });
            that.map.addLayer(that.hexagonLayer);
            that.map.addLayer(that.scatterLayer);
            that.map.addLayer(that.arcLayer);
            that.map.addLayer(that.lineLayer);
       })

      })
    },
    show_arcs_by_grid(info){     //当鼠标放置在scatter上方时，显示轨迹线
      let coordinate=info.coordinate
      let dlat=this.grid_size/(1000*111)
      let dlon=dlat
      let nlat=Math.ceil((31.41700379-31.0827875)/dlat)
      let nlon=Math.ceil((121.66357585-121.12548861)/dlon)
      let grid_index=Math.floor((coordinate[1]-31.0827875)/dlat)*nlon+Math.floor((coordinate[0]-121.12548861)/dlon)
      this.arcLayer.setProps({data:this.grid_targets[grid_index]})
      //this.lineLayer.setProps({data:this.grid_targets[grid_index]})
    },
  }
}
</script>

<style scoped>
body {
  margin: 0;
  padding: 0;
}
#map {
  position: relative;
  z-index: 1;
  width: 1515px;
  height: 700px;
  left:183px;
  top:3px;
  border-radius: 4px;
  padding-left: 4px;
  padding-top: 3px;
  box-shadow: 2px 2px 4px #aaaaaa;
  background: #ffffff;
}
#control-panel {
  position: absolute;
  background: #fff;
  top: 0;
  left: 1320px;
  margin: 12px;
  padding: 20px;
  font-size: 12px;
  line-height: 1.5;
  z-index: 1;
}
label {
  display: inline-block;
  width: 140px;
  color:black;
}
span {
  display: inline-block;
  color:black;
}
</style>
