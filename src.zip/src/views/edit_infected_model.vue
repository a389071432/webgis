<template>
<div style="height: 720px;">
  <HeadNav></HeadNav>
  <SideMenu></SideMenu>
  <div class="content">
    <div class="control_options">
      <el-button-group >
        <el-button  @click="show_graph">图示</el-button>
        <el-button  @click="show_form">表格</el-button>
      </el-button-group>
    </div>
  <div class="graph_container" id='graph_container' style="left:150px;" v-show="this.show===0"></div>
  <div class="form_container" v-show="this.show===1">
    <editable_form_limited class="form" ref="form" ></editable_form_limited>
    <el-button style="position:relative;top:160px;left:450px;margin-top:12px;" @click="allow_modify">修改</el-button>
      <el-button style="position:relative;top:160px;left:600px;margin-top:12px;" @click="submit_modification">确认</el-button>
  </div>
  </div>
</div>
</template>

<script>
import Map from 'ol/Map'
import View from 'ol/View'
import Overlay from 'ol/Overlay';
import Heatmap from 'ol/layer/Heatmap';
import VectorSource from 'ol/source/Vector';
import * as olInteraction from 'ol/interaction'
import {jsPlumb} from "jsPlumb"
import $ from "jquery"
import 'jquery-ui-dist/jquery-ui'
import 'jquery-ui-dist/jquery-ui.min.css'
import 'bootstrap/dist/css/bootstrap.css'
import 'font-awesome/css/font-awesome.css'
import HeadNav from "../components/HeadNav";
import TileLayer from "ol/layer/Tile";
import TileWMS from "ol/source/TileWMS";
import Editable_form from "./editable_form";
import axios from "axios";
import Editable_form_limited from "./editable_form_limited";
import G6 from '@antv/g6';
import Utils from "./utils";
import SideMenu from "../components/SideMenu";



export default {
  name: "edit_infected_model",
  components:{
    SideMenu,
    Editable_form_limited,
    Editable_form,
    HeadNav
  },
  data(){
    return{
      table_data:null,
      show:0,
      graph_container:null,
      graph:null,
      on_simulation:false,
    }
  },
  created() {
  },
  activated() {

  },
  mounted() {
    let that=this
    Utils.$on('start_simulation', function () {
      that.on_simulation=true
    })
    Utils.$on('continue_simulation', function () {
      that.on_simulation=true
    })
    Utils.$on('pause_simulation', function () {
      that.on_simulation=false
    })
    Utils.$on('reset', function () {
      that.on_simulation=false
    })
    this.init()
  },
  methods: {
     init:function () {
       //初始化表格
       this.$root.$on('infected_model_form',(data)=>{    //监听表格数据传送事件
         console.log('listened on infected_model_form event')
         this.table_data=data['table_data']
         console.log('form in edit page',this.table_data)
         this.$refs.form.init_items(this.table_data)
         //初始化graph图示
         this.graph_container=document.getElementById('graph_container')
         const width = 1000
         const height = 640
         this.graph = new G6.Graph({
           container: 'graph_container',
           width,
           height,
           fitView: true,
           modes: {
             default: ['drag-canvas', 'drag-node'],
           },
           layout: {
             type: 'dagre',
             rankdir: 'LR',
             align: 'UL',
             controlPoints: true,
             nodesepFunc: () => 1,
             ranksepFunc: () => 1,
           },
           defaultNode: {
             size: [30, 20],
             type: 'rect',
             style: {
               lineWidth: 2,
               stroke: '#5B8FF9',
               fill: '#C6E5FF',
             },
           },
           defaultEdge: {
             type: 'polyline',
             size: 1,
             color: '#e2e2e2',
             style: {
               endArrow: {
                 path: 'M 0,0 L 8,4 L 8,-4 Z',
                 fill: '#e2e2e2',
               },
               radius: 20,
             },
           },
         })
         this.form_to_graph(this.table_data)
       })
     },
    form_to_graph:function(data){
       console.log('form_to_graph',data)
      let nodes=[]
      let edges=[]
      let node_name=[]
      let n_nodes=0
      let temp={}
      for(let k=0;k<data.length;k++){
        let node0=data[k].state0
        let node1=data[k].state1
        if(!temp.hasOwnProperty(node0)){
          node_name.push(node0)
          temp[node0]=n_nodes
          n_nodes+=1
        }
        if(!temp.hasOwnProperty(node1)) {
          node_name.push(node1)
          temp[node1] = n_nodes
          n_nodes+=1
        }
      }
      for(let k=0;k<node_name.length;k++)
        nodes.push({id:String(k),label:node_name[k]})
      console.log('nodes for G6:',nodes)
      for(let k=0;k<data.length;k++) {
        let node0 = data[k].state0
        let node1 = data[k].state1
        let id0=temp[node0]
        let id1=temp[node1]
        edges.push({source:String(id0),target:String(id1)})
      }
      console.log('edges for G6:',edges)
      let graph_data={nodes:nodes,edges:edges}
      this.graph.data(graph_data)
      this.graph.render()
    },
    allow_modify:function(){
      this.$refs.form.allow_modify()
    },
    async submit_modification(){
      //向后端提交表格修改
      let msg
      let ans = await new Promise((resolve,reject) => {
        axios.post('http://222.94.162.146:5000/modify_infected_model',
          {form:this.$refs.form.table_data}  //待修改前端，land_contacts和p应是用户输入
        ).then(res => {
          resolve(res.data)
        }).catch(error => {

        })
      })
      if(ans==='ok'){
        //更新graph
        this.form_to_graph(this.$refs.form.table_data)
        msg='ok'
      }
      else
        msg='网络错误，请重试'


    },
    show_graph:function () {
      this.show=0
    },
    show_form:function () {
      this.show=1
    }
  }
}
</script>

<style scoped>
.control_options{
  position:relative;
  left:650px;
  top:5px;
}
.content{
  position:relative;
  width: 1512px;
  height: 700px;
  left:188px;
  top:-796px;
  border-radius: 4px;
  padding-left: 4px;
  padding-top: 3px;
  box-shadow: -2px -2px 4px #aaaaaa;
}
.form_container{
  position: relative;
  top:70px;
  width:1300px;
  left:100px;
}
</style>
