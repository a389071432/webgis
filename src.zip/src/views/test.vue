<template>
<div></div>
</template>

<script>
export default {
  name: "test",
  mounted() {
    const DATA_URL = 'https://raw.githubusercontent.com/uber-common/deck.gl-data/master/examples/arc/counties.json';
    d3.json(DATA_URL).then(loadData);

  },
  methods:{
    loadData:function(){
      const arcs = [];
      const counties = [];
      const pairs = {};

      data.features.forEach((county, i) => {
        const {flows, centroid: targetCentroid} = county.properties;
        const value = {gain: 0, loss: 0};

        Object.keys(flows).forEach(toId => {
          value[flows[toId] > 0 ? 'gain' : 'loss'] += flows[toId];

          const pairKey = i < toId ? `${i}-${toId}` : `${toId}-${i}`;
          const sourceCentroid = data.features[toId].properties.centroid;
          const gain = Math.sign(flows[toId]);

          // eliminate duplicates arcs
          if (pairs[pairKey]) {
            return;
          }

          pairs[pairKey] = true;

          arcs.push({
            target: gain > 0 ? targetCentroid : sourceCentroid,
            source: gain > 0 ? sourceCentroid : targetCentroid,
            value: Math.abs(flows[toId])
          });
        });

        // add point at arc target
        counties.push({
          ...value,
          position: targetCentroid,
          net: value.gain + value.loss,
          total: value.gain - value.loss,
          name: county.properties.name
        });
      });

      // sort counties by radius large -> small
      counties.sort((a, b) => Math.abs(b.net) - Math.abs(a.net));

      renderLayers({arcs, counties});
    },
  }
}
</script>

<style scoped>

</style>
