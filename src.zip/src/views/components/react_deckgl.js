import React, {useState, useEffect} from 'react';
import {render} from 'react-dom';
import {Map} from 'react-map-gl';
import {AmbientLight, PointLight, LightingEffect} from '@deck.gl/core';
import DeckGL from '@deck.gl/react';
import {PolygonLayer} from '@deck.gl/layers';
import {TripsLayer} from '@deck.gl/geo-layers';
import {HexagonLayer} from '@deck.gl/aggregation-layers';
import {ScreenGridLayer} from '@deck.gl/aggregation-layers';
import {ScatterplotLayer} from '@deck.gl/layers';

const DATA_URL =
  'https://raw.githubusercontent.com/visgl/deck.gl-data/master/examples/3d-heatmap/heatmap-data.csv'; // eslint-disable-line



export default  class TTT extends React.Component{
  constructor(props) {
    super(props)
    this.state = {
     Layers:[],
    }
    this.lightingEffect=null
    this.INITIAL_VIEW_STATE=null
    this.material=null
    this.heatNames=[]
    this.heatData={}
    this.gridData={}
    this.tripData=null
    this.minLat=31.0827875
    this.maxLat=31.41700379
    this.minLon=121.12548861
    this.maxLon=121.6635758
    this.gridSize=4500
    this.trailLength = 300
    this.time=0
    this.dlat=this.gridSize/(1000*111)
    this.dlon=this.dlat
    this.nlat=Math.ceil((this.maxLat-this.minLat)/this.dlat)
    this.nlon=Math.ceil((this.maxLon-this.minLon)/this.dlon)
    this.gridInfo=new Array(this.nlat*this.nlon)
    for(let x=0;x<this.nlat;x++){
      for(let y=0;y<this.nlon;y++){
        let gridIndex=x*this.nlon+y
        this.gridInfo[gridIndex]={position:[this.minLon+y*this.dlon,this.minLat+x*this.dlat],value:0}
      }
    }
    console.log('n scatters:',this.gridInfo.length)
    this.gridClickedState=new Array(this.nlat*this.nlon)
    this.gridDataPos=new Array(this.nlat*this.nlon)   //记录某index网格在gridData中的位置
    this.tripDataOnShow=[]   //正在显示的tripData集合
    for(let x=0;x<this.nlat*this.nlon;x++)
      this.gridDataPos[x]=-1
    for(let x=0;x<this.nlat*this.nlon;x++)
      this.gridClickedState[x]=0
    this.theme=null
    this.loopLength=200
    this.animationSpeed=3
  }
  componentDidMount(){
      let ambientLight = new AmbientLight({
      color: [255, 255, 255],
      intensity: 1.0
    })

     let pointLight1 = new PointLight({
      color: [255, 255, 255],
      intensity: 0.8,
      position: [-0.144528, 49.739968, 80000]
    })

     let pointLight2 = new PointLight({
      color: [255, 255, 255],
      intensity: 0.8,
      position: [-3.807751, 54.104682, 8000]
    })

     let lightingEffect = new LightingEffect({ambientLight, pointLight1, pointLight2});

      let material = {
      ambient: 0.64,
      diffuse: 0.6,
      shininess: 32,
      specularColor: [51, 51, 51]
    }

      let INITIAL_VIEW_STATE = {
      longitude: 121.6842,
      latitude: 31.3145,
      zoom: 6.6,
      minZoom: 5,
      maxZoom: 15,
      pitch: 40.5,
      bearing: -27
    }

    let colorRange = [
      [1, 152, 189],
      [73, 227, 206],
      [216, 254, 181],
      [254, 237, 177],
      [254, 173, 84],
      [209, 55, 78]
    ]
    let theme={
      buildingColor: [74, 80, 87],
      trailColor0: [253, 128, 93],
      trailColor1: [23, 184, 190],
      material,
      effects: [lightingEffect]
    }
    this.lightingEffect=lightingEffect
    this.INITIAL_VIEW_STATE=INITIAL_VIEW_STATE
    this.material=material
    this.colorRange=colorRange
    this.theme=theme

    window.requestAnimationFrame(this.updateTripTime)

    //临时测试trips
    let data=[
         {
             // waypoints: [
             //    {coordinates: [-122.3907988, 37.7664413], timestamp: 0},
             // //   {coordinates: [-122.3908298,37.7667706], timestamp: 10},
             // {coordinates: [-122.4485672, 37.8040182], timestamp: 200},
             //   ]
           "path": [
             [121.6842, 31.3145],
             //   {coordinates: [-122.3908298,37.7667706], timestamp: 10},
             [121.6842, 31.4145]
           ],
           "timestamps": [0,200]
         }
   ]
    const layer = new TripsLayer({
      id: 'trips-layer',
      data:data,
      getPath: d => d.path,//d => d.waypoints.map(p => p.coordinates),
      // deduct start timestamp from each data point to avoid overflow
      getTimestamps: d => d.timestamps,//d => d.waypoints.map(p => p.timestamp),
      getColor: [253, 128, 93],
      opacity: 0.8,
      widthMinPixels: 5,
      rounded: true,
      fadeTrail: true,
      trailLength: 50,
      currentTime: 200
    })
    this.setState({Layers:[layer]})
  }
    componentWillReceiveProps(nextProps) {
      this.heatNames=nextProps.heatNames
      this.heatData=nextProps.heatData
      this.gridData=nextProps.gridData
      this.tripData=nextProps.tripData
      this.updateLayers()
    }
  updateTripTime=()=>{
    this.time=(this.time + this.animationSpeed) % this.loopLength
    this.updateLayers()
    window.requestAnimationFrame(this.updateTripTime)

  }
    updateLayers=()=>{
      let newLayers=[]
      //重新创建heat图层
      let names=Object.keys(this.heatData)
      for(let i=0;i<names.length;i++){
        let nowName=names[i]
        let nowData=[]
        for(let k=0;k<this.heatData[nowName].length;k++)
          nowData.push(this.heatData[nowName][k])
        let heatLayer=new HexagonLayer({
          id: 'heat'+nowName,
          colorRange: this.colorRange,
          coverage: 0.5,
          data: nowData,
          elevationRange: [0, 3000],
          elevationScale: nowData && nowData.length? 50:0,
          extruded: true,
          getPosition: d => [Number(d.lng), Number(d.lat)],
          pickable: true,
          radius: 1000,
          visible:false,
          upperPercentile: 100,
          material: this.material,
          transitions: {
            elevationScale: 3000
          }
        })
        newLayers.push(heatLayer)
      }
      //重新创建grid图层
      names=Object.keys(this.gridData)
      for(let i=0;i<names.length;i++){
        let nowName=names[i]
        let nowData=[]
        for(let k=0;k<this.gridData[nowName].length;k++)
          nowData.push(this.gridData[nowName][k])
        let gridLayer=new ScreenGridLayer({
          id: 'grid'+nowName,
          data:nowData,
          pickable: false,
          opacity: 0.9,
          cellSizePixels: 20,
          colorRange: [
            [0, 25, 0, 25],
            [0, 85, 0, 85],
            [0, 127, 0, 127],
            [0, 170, 0, 170],
            [0, 190, 0, 190],
            [0, 255, 0, 255]
          ],
          getPosition: d => d.COORDINATES,
          getWeight: d => d.CNT
        })
        newLayers.push(gridLayer)
      }
      //重新创建scatter图层
      let scatterLayer=new ScatterplotLayer({
        id: 'scatterplot-layer',
        data:this.gridInfo,
        pickable: true,
        opacity: 0.8,
        stroked: true,
        filled: true,
        radiusScale: 3,
        radiusMinPixels: 1,
        radiusMaxPixels: 100,
        lineWidthMinPixels: 1,
        getPosition: d => d.position,
        getRadius: d => 120,
        getFillColor: d => [255,140,0],
        getLineColor: d => [0, 0, 0],
        onClick: (info, event) => this.showTrips(info),
      })
      newLayers.push(scatterLayer)
      //重新创建trip图层
      let data=[]
      for(let i=0;i<this.tripDataOnShow.length;i++)
        data.push(this.tripDataOnShow[i])
      let tripLayer=new TripsLayer({
        id: 'trips',
        data: data,
        getPath: d => d.path,
        getTimestamps: d => d.timestamps,
        getColor: [253, 128, 93],
        opacity: 0.6,
        widthMinPixels: 2,
        rounded: true,
        trailLength:this.trailLength,
        currentTime: this.time,
        shadowEnabled: false
      })
      console.log('trip be created',this.tripDataOnShow)
      newLayers.push(tripLayer)
      //更新state
      this.setState({Layers: newLayers})
      //console.log('OnShow',this.tripDataOnShow)
    }
    showTrips=(info)=>{
      this.time=0
      let coordinate=info.coordinate
      let x=Math.ceil((coordinate[1]-this.minLat)/this.dlat)
      let y=Math.ceil((coordinate[0]-this.minLon)/this.dlon)
      let index=x*this.nlon+y
      let nowTripData=this.tripData[index.toString()]
      if(this.gridClickedState[index]===0){   //显示某grid
        this.gridDataPos[index]=this.tripDataOnShow.length
        for(let i=0;i<nowTripData.length;i++)
          this.tripDataOnShow.push(nowTripData[i])
        this.gridClickedState[index]=1
      }
      else if(this.gridClickedState[index]===1){  //hide某grid
        this.tripDataOnShow.splice(this.gridDataPos[index],nowTripData.length)
        for(let i=0;i<this.gridDataPos.length;i++){
          let pos=this.gridDataPos[i]
          if((pos!==-1)&&(pos>this.gridDataPos[index]))
            this.gridDataPos[i]-=nowTripData.length
        }
        this.gridClickedState[index]=0
        this.gridDataPos[index]=-1
      }
      this.updateLayers()
    }
  getTooltip=({object})=> {
    if (!object) {
      return null
    }
    const lat = object.position[1];
    const lng = object.position[0];
    const count = object.points.length;
    return `\
    latitude: ${Number.isFinite(lat) ? lat.toFixed(6) : ''}
    longitude: ${Number.isFinite(lng) ? lng.toFixed(6) : ''}
    ${count} Accidents`
  }
  render() {
    return (
      <DeckGL
        layers={this.state.Layers}
        effects={[this.lightingEffect]}
        initialViewState={this.INITIAL_VIEW_STATE}
        controller={true}
        //getTooltip={this.getTooltip}
      >
        <Map reuseMaps style={{width: 600, height: 400}} mapboxAccessToken='pk.eyJ1IjoiYTM4OTA3MTQzMiIsImEiOiJjbDFza3p4ZWwwbXdnM2JvODU4ZDQ4ZXVuIn0.GZLKrxOW8KLL2gy0mTFpPA' mapStyle='mapbox://styles/mapbox/dark-v10?optimize=true' preventStyleDiffing={true} />
      </DeckGL>
    )
  }
}

