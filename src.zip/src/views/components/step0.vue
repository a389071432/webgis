<template>
   <div>
     <div style="font-size: 20px; margin-left: 32px; margin-top: 24px;" >
     <div style="margin-bottom: 6px;">上传水文数据</div>
     <el-upload
       class="upload-demo"
       drag
       action
       name="waters"
       :on-change="upload"
       :auto-upload="false"
       multiple
     >
       <i class="el-icon-upload"></i>
       <div class="el-upload__text">
         将文件拖到此处，或
         <em>点击上传</em>
       </div>
       <div
         class="el-upload__tip"
         slot="tip"
       >请上传csv、xlsx格式文件</div>
     </el-upload>
   </div>
   </div>
</template>

<script>
export default {
  name: "step0",
  methods:{
    upload(){
      //只暂存文件路径，点击“下一步”后再提交（待补充）

    },
    submit(){
      //先检查路径和文件内容，若无效，返回false（待补充）

      //返回true
      return true
    }
  }
}
</script>

<style scoped>
.upload-demo{
  width: 200px;
  height:200px;
}
</style>
