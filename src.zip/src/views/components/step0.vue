<template>
   <div>
     <div style="font-size: 20px; margin-left: 32px; margin-top: 24px;" >
     <div style="margin-bottom: 6px;">上传水文数据</div>
     <el-upload
       class="upload-demo"
       drag
       action
       name="file"
       :on-change="upload"
       :auto-upload="false"
       multiple
     >
       <i class="el-icon-upload"></i>
       <div class="el-upload__text">
         将文件拖到此处，或
         <em>点击上传</em>
       </div>
       <div
         class="el-upload__tip"
         slot="tip"
         style="position: relative;left:100px"
       >请上传csv、xlsx格式文件</div>
     </el-upload>
   </div>
   </div>
</template>

<script>
import axios from "axios";
import Feature from "ol/Feature";
import Point from "ol/geom/Point";

export default {
  name: "step0",
  data() {
    return {
      file:null,
    }
  },
  methods:{
    upload(file){
      //只暂存文件路径，点击“下一步”后再提交（待补充）
      this.file=file.raw
    },
    async submit(){
      let msg
      let formData=new FormData()
      formData.append('file',this.file)
      let config={
        headers:{'Content-Type':'multipart/form-data'}
      }
      //向后端提交agents文件，成功则返回'ok'，否则返回错误信息
      let ans = await new Promise((resolve,reject) => {
          axios.post('http://222.94.162.146:5000/submit_agent_file',formData,config).then(res => {
          resolve(res.data)
        }).catch(error => {

        })
      })
      if(ans==='ok')
        msg='ok'
      else
        msg='网络错误，请重试'
      return msg
    }
  }
}
</script>

<style scoped>
.upload-demo{
  width: 200px;
  height:200px;
}
</style>
