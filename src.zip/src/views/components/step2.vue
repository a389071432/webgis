<template>
  <div class="content">
    <el-form :model="ruleForm2"  ref="ruleForm2" label-width="100px" class="demo-ruleForm" status-icon :rules="rules2">

      <el-form-item label="服务器地址" prop="url_server">
        <el-input v-model="ruleForm2.url_server"></el-input>
      </el-form-item>

      <el-form-item label="工作区" prop="url_workspace">
        <el-input v-model="ruleForm2.url_workspace"></el-input>
      </el-form-item>

      <el-form-item label="图层" prop="url_layer">
        <el-input v-model="ruleForm2.url_layer"></el-input>
      </el-form-item>

      <el-form-item label=" 命名" prop="name">
        <el-input v-model="ruleForm2.name"></el-input>
      </el-form-item>
    </el-form>

  </div>
</template>
<script>
export default {
  name: "step1",
  data(){
    return {
      url_server:'',
      url_workspace:'',
      url_layer:'',
      ruleForm2: {
        url_server: '',
        url_workspace: '',
        url_layer: '',
        name:''
      },
      rules2: {
        url_server: [
          { required:true,type:'string', trigger: 'blur' ,message:'不能为空'}
        ],
        url_workspace: [
          { required:true,type:'string', trigger: 'blur' ,message:'不能为空'}
        ],
        url_layer: [
          { required:true,type:'string', trigger: 'blur' ,message:'不能为空'}
        ],
        name: [
          { required:true,type:'string', trigger: 'blur' ,message:'不能为空'}
        ],
      },
      tableData:[],
      layer_name:[],
      control:null,
      map:null,
      isshow: false,
      loading:false,
      dialogFormVisible: false,
      form: {
        name: '',
        type: [],
        resource: '',
        desc: ''
      },
      formLabelWidth: '120px',
    };
  },

  methods: {

//提交url，获取图层
    submitForm() {
      let url=this.ruleForm2.url_server+'/'+this.ruleForm2.url_workspace+'/wms'
      let url_layer=this.ruleForm2.url_workspace+':'+this.ruleForm2.url_layer
      let ans=false;
      this.$refs.ruleForm2.validate((valid) => {
        if (valid) {
          ans=true
        }
        else {    //提示输入无效
          ans=false
        }
      });
      return ans
    },

  }
}
</script>

<style scoped>
.content{
  width:400px;
}
</style>
