<template>
  <div>
    <div id="myself">
      <div id='pop0' class="pop0" >
        <p>请输入结点名称</p>
        <p id='msg0'></p>
        <input id='input0'/>
        <a href="#" id="done0" class="done0"></a>
      </div>

      <div id='pop1' class="pop1" >
        <a href="#" id="closer1" class="closer1"></a>
        <div id="content1"></div>
        <a href="#" id="edit1" class="edit1"></a>
        <a href="#" id="remove1" class="remove1"></a>
      </div>

      <div id='pop2' class="pop2">
        <p>请输入结点名称</p>
        <p id='msg2'></p>
        <input id='input2'/>
        <a href="#" id="done2" class="done2"></a>
        <a href="#" id="closer2" class="closer2"></a>
      </div>

      <div id='pop3' class="pop3" >
        <p id='msg3'>请输入转移概率和转移时延</p>
        <input id='input3_p0' placeholder="青少年转移概率"/>
        <input id='input3_p1' placeholder="中青年转移概率"/>
        <input id='input3_p2' placeholder="老年人转移概率"/>
        <input id='input3_t0' placeholder="青少年转移时延"/>
        <input id='input3_t1' placeholder="中青年移时延"/>
        <input id='input3_t2' placeholder="老年人转移时延"/>
        <a href="#" id="done3" class="done3"></a>
      </div>

      <div id='pop4' class="pop4" >
        <p id="p0"></p>
        <p id="p1"></p>
        <p id="p2"></p>
        <p id="t0"></p>
        <p id="t1"></p>
        <p id="t2"></p>
        <a href="#" id="edit4" class="edit4"></a>
        <a href="#" id="remove4" class="remove4"></a>
        <a href="#" id="closer4" class="closer4"></a>
      </div>

      <div id='pop5' class="pop5">
        <p id='msg5'>请输入转移概率和转移时延</p>
        <input id='input5_p0' placeholder="青少年转移概率"/>
        <input id='input5_p1' placeholder="中青年转移概率"/>
        <input id='input5_p2' placeholder="老年人转移概率"/>
        <input id='input5_t0' placeholder="青少年转移时延"/>
        <input id='input5_t1' placeholder="中青年移时延"/>
        <input id='input5_t2' placeholder="老年人转移时延"/>
        <a href="#" id="done5" class="done5"></a>
        <a href="#" id="closer5" class="closer5"></a>
      </div>

      <div class="node_container">
              <h5>拖动图标可新建结点</h5>
              <div class="btn" id="btn">
                <img src="../../assets/node_icon.png" alt="新建结点" style="width: 90px;height: 90px;">
              </div>
          <div class="map" id="drop-bg"></div>
      </div>
    </div>
  </div>
</template>

<script>
import Map from 'ol/Map'
import View from 'ol/View'
import Overlay from 'ol/Overlay';
import Heatmap from 'ol/layer/Heatmap';
import VectorSource from 'ol/source/Vector';
import * as olInteraction from 'ol/interaction'
import {jsPlumb} from "jsPlumb"
import $ from "jquery"
import TileLayer from "ol/layer/Tile";
import TileWMS from "ol/source/TileWMS";
import {ScaleLine, defaults as defaultControls} from 'ol/control';

export default {
  name: "step3",
  data(){
    return{
      //交互相关
      area : 'drop-bg',
      areaId : null,
      jsp:null,
      container0:null,
      container1:null,
      container2:null,
      container3:null,
      container4:null,
      container5:null,

      msg0:null,
      msg2:null,
      msg3:null,
      msg5:null,

      content1:null,

      input0:null,
      input2:null,

      done0:null,
      done2:null,
      done3:null,
      done5:null,

      edit1:null,
      edit4:null,

      remove1:null,
      remove4:null,

      closer1:null,
      closer2:null,
      closer4:null,
      closer5:null,

      overlay0 : null,
      overlay1 : null,
      overlay2 : null,
      overlay3 : null,
      overlay4 : null,
      overlay5 : null,

      node_name:null,
      conn_p0:null,
      conn_p1:null,
      conn_p2:null,
      conn_t0:null,
      conn_t1:null,
      conn_t2:null,
      map:null,
      selected_node:-1,
      connectorPaintStyle : {
        lineWidth: 2,
        strokeStyle: '#61B7CF',
        joinstyle: 'round',
        fill: 'pink',
        outlineColor: '',
        outlineWidth: ''
      },
      connectorHoverStyle : {
        lineWidth: 2,
        strokeStyle: 'red',
        outlineWidth: 10,
        outlineColor: ''
      },
      common : {
        isSource: true, // 是否可以拖动（作为连线起点）
        isTarget: true, // 是否可以放置（连线终点）
        deleteEndpointsOnDetach:false,
        endpoint: ['Dot', {
          radius: 6,
          fill: 'pink'
        }],     // 端点的形状
        connectorStyle: this.connectorPaintStyle, // 连接线的颜色，大小样式
        connectorHoverStyle: this.connectorHoverStyle,
        paintStyle: {
          strokeStyle: '#1e8151',
          stroke: '#7AB02C',
          fill: 'pink',
          fillStyle: '#1e8151',
          radius: 6,
          lineWidth: 2
        },
        hoverPaintStyle: { stroke: 'blue' },
        connector: ['Flowchart', { gap: 10, cornerRadius: 5, alwaysRespectStubs: true }],  // 连接线的样式种类有[Bezier],[Flowchart],[StateMachine ],[Straight ]
        maxConnections: -1, // 设置连接点最多可以连接几条线
        connectorOverlays: [
          ['Arrow', {
            width: 10,
            length: 10,
            location: 1
          }],
          ['Arrow', {
            width: 10,
            length: 10,
            location: 0.2
          }],
          ['Arrow', {
            width: 10,
            length: 10,
            location: 0.7
          }]]
      },
      node_cnt:0,  //结点计数（编号）
      v:new Array(), //v用于判断是否存在重复连接
      edge:new Array(), //用于标记[source][target]对应于哪条边
      edge_cnt:0 , //边计数（编号）
      selected_source:-1,     //当前所选中边的两个端点
      selected_target:-1,
      selected_conn:null,    //当前选中的边
    }
  },
  created() {
    //this.createMap()
  },
  mounted() {
    this.init()
  },
  methods: {
    init: function(){
      //初始化交互
      this.areaId='#drop-bg'
      this.container0=document.getElementById('pop0')
      this.container1=document.getElementById('pop1')
      this.container2=document.getElementById('pop2')
      this.container3=document.getElementById('pop3')
      this.container4=document.getElementById('pop4')
      this.container5=document.getElementById('pop5')

      this.content1=document.getElementById('content1')

      this.msg0=document.getElementById('msg0')
      this.msg2=document.getElementById('msg2')
      this.msg3=document.getElementById('msg3')
      this.msg4=document.getElementById('msg5')

      this.input0=document.getElementById('input0')
      this.input2=document.getElementById('input2')

      this.done0=document.getElementById('done0')
      this.done2=document.getElementById('done2')
      this.done3=document.getElementById('done3')
      this.done5=document.getElementById('done5')

      this.edit1=document.getElementById('edit1')
      this.edit4=document.getElementById('edit4')

      this.remove1=document.getElementById('remove1')
      this.remove4=document.getElementById('remove4')

      this.closer1=document.getElementById('closer1')
      this.closer2=document.getElementById('closer2')
      this.closer4=document.getElementById('closer4')
      this.closer5=document.getElementById('closer5')

      this.overlay0=new Overlay({
        element: this.container0,
        autoPan: {
          animation: {
            duration: 250,
          },
        },
      })
      this.overlay1=new Overlay({
        element: this.container1,
        autoPan: {
          animation: {
            duration: 250,
          },
        },
      })
      this.overlay2=new Overlay({
        element: this.container2,
        autoPan: {
          animation: {
            duration: 250,
          },
        },
      })
      this.overlay3=new Overlay({
        element: this.container3,
        autoPan: {
          animation: {
            duration: 250,
          },
        },
      })
      this.overlay4=new Overlay({
        element: this.container4,
        autoPan: {
          animation: {
            duration: 250,
          },
        },
      })
      this.overlay5=new Overlay({
        element: this.container5,
        autoPan: {
          animation: {
            duration: 250,
          },
        },
      })

      //初始化map
      this.map=new Map({
        target: 'drop-bg',
        overlays: [this.overlay0, this.overlay1, this.overlay2, this.overlay3, this.overlay4, this.overlay5],
        view: new View({
          projection: 'EPSG:4326',
          center: [0, 0],
          zoom: 2,
        }),
        controls: defaultControls({
          zoom: false,
          rotate: false,
          attribution: false
        }).extend([
          new ScaleLine({
            //设置比例尺单位，degrees、imperial、us、nautical、metric（度量单位）
            units: "metric"
          })
          //interactions: olInteraction.defaults({mouseWheelZoom:false}),
        ])
      })
      this.map.addLayer(
        new Heatmap({   //heatmap图层
          source:new VectorSource({}),
          blur: 15,
          radius:5,
          opacity: .5
        })
      )
      this.map.on('singleclick',this.map_click)
      for(let x=0;x<1000;x++){
        this.v.push({});
      }
      //初始化jsplumb
      this.jsp=jsPlumb.getInstance()
      this.jsp.importDefaults({
        ConnectionsDetachable: false
      })
      //this.jsp.ready(this.jsp_ready_func)
      this.jsp_ready_func()
      this.jsp.bind('connection', this.after_conn)
      this.jsp.bind('click', this.conn_click)
      this.jsp.bind('beforeDrop',this.before_drop)
      //初始化交互
      this.done0.onclick=this.dn0
      this.done2.onclick=this.dn2
      this.done3.onclick=this.dn3
      this.done5.onclick=this.dn5
      this.edit1.onclick=this.ed1
      this.edit4.onclick=this.ed4
      this.remove1.onclick=this.del1
      this.remove4.onclick=this.del4
      this.closer1.onclick=this.cl1
      this.closer2.onclick=this.cl2
      this.closer4.onclick=this.cl4
      this.closer5.onclick=this.cl5

      //初始化边和结点信息
      this.node_name=new Array(1000)
      this.conn_p0=new Array()
      this.conn_p1=new Array()
      this.conn_p2=new Array()
      this.conn_t0=new Array()
      this.conn_t1=new Array()
      this.conn_t2=new Array()

    },
    dn3:function() {   //编辑边完成时
      //记录边属性
      console.log(this.edge)
      if(this.edge.hasOwnProperty(this.selected_target)===false)
        this.edge[this.selected_source]={}
      this.edge[this.selected_source][this.selected_target]=this.edge_cnt
      this.conn_p0[this.edge_cnt]=document.getElementById('input3_p0').value
      this.conn_p1[this.edge_cnt]=document.getElementById('input3_p1').value
      this.conn_p2[this.edge_cnt]=document.getElementById('input3_p2').value
      this.conn_t0[this.edge_cnt]=document.getElementById('input3_t0').value
      this.conn_t1[this.edge_cnt]=document.getElementById('input3_t1').value
      this.conn_t2[this.edge_cnt]=document.getElementById('input3_t2').value
      this.edge_cnt+=1
      //关闭窗口
      this.overlay3.setPosition(undefined)
      document.getElementById('drop-bg').style.zindex=-1
      //向后端发送（待补充）

    },
    dn5:function() {   //编辑边完成时
      //记录边属性
      this.edge[this.selected_source][this.selected_target]=this.edge_cnt
      this.conn_p0[this.edge_cnt]=document.getElementById('input5_p0').value
      this.conn_p1[this.edge_cnt]=document.getElementById('input5_p1').value
      this.conn_p2[this.edge_cnt]=document.getElementById('input5_p2').value
      this.conn_t0[this.edge_cnt]=document.getElementById('input5_t0').value
      this.conn_t1[this.edge_cnt]=document.getElementById('input5_t1').value
      this.conn_t2[this.edge_cnt]=document.getElementById('input5_t2').value
      this.edge_cnt+=1
      //关闭窗口
      this.overlay5.setPosition(undefined)
      //向后端发送（待补充）

    },
    map_click:function(e){
      let pixel=this.map.getPixelFromCoordinate(e.coordinate)
    },
    jsp_ready_func:function(){
      this.jsp.setContainer('myself')
      $("#btn").draggable({
        helper: 'clone',
        scope: 'ss'
      })
      //放置结点（新建结点）
      $("#drop-bg").droppable({
        scope: 'ss',
        drop: (event, ui)=> {
          console.log(event)
          //在指定位置创建新结点
          let position=ui.position
          let coord_top=position['top']
          let coord_left=position['left']
          let new_node=document.createElement("div")
          document.getElementById('myself').appendChild(new_node);
          new_node.setAttribute("id",this.node_cnt)
          this.node_cnt+=1;
          new_node.setAttribute("Style","width:80px;height:80px;border:3px solid black")
          new_node.style.position="absolute";
          new_node.style.top=String(coord_top)+'px';
          new_node.style.left=String(coord_left)+'px';
          let that=this
          new_node.addEventListener('click',function(event){
            let elem=event.target
            that.selected_node=elem.getAttribute("id")
            let coord_top=parseInt(elem.style.top)
            let coord_left=parseInt(elem.style.left)
            //弹出窗口，要求用户编辑结点属性（待补充）
            let coordinate=that.map.getCoordinateFromPixel([coord_left,coord_top])
            that.overlay1.setPosition(coordinate)
            that.content1.innerHTML="状态名称:    "+that.node_name[that.selected_node]
          })
          //new_node.setAttribute("click",this.onNodeClick(new_node))
          //初始化新结点的jsPlumb属性
          let ep=this.jsp.addEndpoint(new_node, {anchors: ['Right']}, this.common)
          ep._deleteOnDetach = false
          ep=this.jsp.addEndpoint(new_node, {anchors: ['Left']}, this.common)
          ep._deleteOnDetach = false;
          ep=this.jsp.addEndpoint(new_node, {anchors: ['Top']}, this.common)
          ep._deleteOnDetach = false;
          ep=this.jsp.addEndpoint(new_node, {anchors: ['Bottom']}, this.common)
          ep._deleteOnDetach = false;
          this.jsp.draggable(new_node)
          // let coordinate=this.map.getCoordinateFromPixel([coord_left,coord_top]);
          // this.overlay0.setPosition(coordinate);
          // this.selected_node=new_node.getAttribute('id');
          // this.overlay1.setPosition(undefined)
        }
      })
    },
    onNodeClick:function(elem){
      console.log('111')
      this.selected_node=elem.getAttribute("id")
      let coord_top=parseInt(elem.style.top)
      let coord_left=parseInt(elem.style.left)
      //弹出窗口，要求用户编辑结点属性（待补充）
      let coordinate=this.map.getCoordinateFromPixel([coord_left,coord_top])
      this.overlay1.setPosition(coordinate)
    },
    after_conn:function(info){                                //连接建立后触发
      this.selected_source=info.sourceId
      this.selected_target=info.targetId
      //弹出框，要求编辑边属性
      let  elem0=document.getElementById(this.selected_source)
      let  elem1=document.getElementById(this.selected_target)
      let coord_top0=parseInt(elem0.style.top)
      let coord_left0=parseInt(elem0.style.left)
      let coord_top1=parseInt(elem1.style.top)
      let coord_left1=parseInt(elem1.style.left)
      let coordinate1=this.map.getCoordinateFromPixel([Math.ceil(coord_left0/2+coord_left1/2),Math.ceil(coord_top0/2+coord_top1/2)])
      this.overlay3.setPosition(coordinate1)
      document.getElementById('drop-bg').style.zindex=99
    },
    conn_click:function (conn, originalEvent) {           //点击连线进行操作
      this.selected_conn=conn
      this.selected_source=conn.source.getAttribute('id');
      this.selected_target=conn.target.getAttribute('id');
      //弹出窗口（编辑or删除）
      let edge=this.edge[this.selected_source][this.selected_target]
      document.getElementById('p0').innerText='p0:'+String(this.conn_p0[edge])
      document.getElementById('p1').innerText='p1:'+String(this.conn_p1[edge])
      document.getElementById('p2').innerText='p2:'+String(this.conn_p2[edge])

      document.getElementById('t0').innerText='t0:'+String(this.conn_p0[edge])
      document.getElementById('t1').innerText='t1:'+String(this.conn_p1[edge])
      document.getElementById('t2').innerText='t2:'+String(this.conn_p2[edge])
      //弹出框
      let  elem0=document.getElementById(this.selected_source)
      let  elem1=document.getElementById(this.selected_target)
      let coord_top0=elem0.style.top
      let coord_left0=elem0.style.left
      let coord_top1=elem1.style.top
      let coord_left1=elem1.style.left
      let coordinate=this.map.getCoordinateFromPixel([Math.ceil(coord_left0/2+coord_left1/2),Math.ceil(coord_top0/2+coord_top1/2)])
      this.overlay4.setPosition(coordinate)
    },
    before_drop:function(info){
      this.selected_source=Number(info.sourceId)
      this.selected_target=info.targetId
      //两结点间不允许重复连接或双向边
      if(((this.v[this.selected_source].hasOwnProperty(this.selected_target))||(this.v[this.selected_target].hasOwnProperty(this.selected_source)))||((this.v[this.selected_source][this.selected_target]===1)||(this.v[this.selected_target][this.selected_source]===1))){

        this.selected_source=-1;
        this.selected_target=-1;
        return false;
      }
      this.v[this.selected_source][this.selected_target]=1;
      return true;
    },
    dn0:function(){
      let text=this.input0.value
      if(text.length==0){
        this.msg0.innerHTML='名称不能为空'
        return
      }
      document.getElementById(this.selected_node).innerText=text
      this.node_name[this.selected_node]=text
      this.overlay0.setPosition(undefined)
      //将name发送到后端(待补充)

      return
    },
    dn2:function(){
      let text=this.input2.value
      if(text.length==0){
        this.msg2.innerHTML='名称不能为空'
        return;
      }
      document.getElementById(this.selected_node).innerText=text
      this.node_name[this.selected_node]=text
      this.overlay2.setPosition(undefined)
      this.closer2.blur()
      //将name发送到后端（待补充）


      return
    },
    ed1:function (){
      let elem=document.getElementById(this.selected_node)
      let coord_top=parseInt(elem.style.top)
      let coord_left=parseInt(elem.style.left)
      //弹出窗口，要求用户编辑结点属性（待补充）
      let coordinate=this.map.getCoordinateFromPixel([coord_left,coord_top])
      this.overlay2.setPosition(coordinate)
      this.overlay1.setPosition(undefined)
      this.closer1.blur()
    },
    ed4:function(){
      this.overlay4.setPosition(undefined)
      this.closer4.blur()
      //弹出框，要求编辑
      let  elem0=document.getElementById(this.selected_source)
      let  elem1=document.getElementById(this.selected_target)
      let coord_top0=parseInt(elem0.style.top)
      let coord_left0=parseInt(elem0.style.left)
      let coord_top1=parseInt(elem1.style.top)
      let coord_left1=parseInt(elem1.style.left)
      let coordinate=this.map.getCoordinateFromPixel([Math.ceil(coord_left0/2+coord_left1/2),Math.ceil(coord_top0/2+coord_top1/2)])
      this.overlay5.setPosition(coordinate)
    },
    del1:function(){
      this.overlay1.setPosition(undefined)
      this.closer1.blur()
      //删除结点
      document.getElementById('app').removeChild(document.getElementById(this.selected_node))
      //删除与结点相关的所有边
      jsPlumb.remove(this.selected_node)
      //相关操作后端（待补充）

    },
    del4:function(){
      this.overlay4.setPosition(undefined)
      this.closer4.blur()
      this.v[this.selected_source][this.selected_target]=0
      //删除边
      jsPlumb.detach(this.selected_conn)
      //相应操作后端(待补充)

    },
    cl1:function(){
      this.overlay1.setPosition(undefined)
      this.closer1.blur()
    },
    cl2:function(){
      this.overlay2.setPosition(undefined)
      this.closer2.blur()
    },
    cl4:function(){
      this.overlay4.setPosition(undefined)
      this.closer4.blur()
    },
    cl5:function(){
      this.overlay5.setPosition(undefined)
      this.closer5.blur()
    },
  }
}
</script>

<style scoped>
.min-height{
  position:relative;
  z-index: 2;
  height:100%;
}
.node_container{
  position: relative;
  height:400px;
  width: 900px;
}
#btn{
  height: 100px;
  width: 100px;
  z-index: 2;
}
.pa{
  position: relative;
}
.fixed-node{
  position: relative;
  top: 80px;
  left: 150px;
}

#end-node{
  left: 150px;
  top: 700px;
}
.panel-node{
  width: 150px;
  display: inline-block;
  margin: auto 25px;
}
.panel-node-list{
  padding: 10px 10px;
}
.delete-node{
  cursor: pointer;
  width: 20px;
  display: inline-block;
  text-align: center;
}
.delete-node:hover{
  color: red
}

.map{
  position:relative;
  top:-100px;
  left:100px;
  width:900px;
  height:400px;
  z-index: 1;
}

.pop0 {
  position: absolute;
  background-color: white;
  box-shadow: 0 1px 4px rgba(0,0,0,0.2);
  padding: 15px;
  border-radius: 10px;
  border: 1px solid #cccccc;
  bottom: 12px;
  left: -50px;
  min-width: 280px;
}
.pop0:after, .pop0:before {
  top: 100%;
  border: solid transparent;
  content: " ";
  height: 0;
  width: 0;
  position: absolute;
  pointer-events: none;
}
.pop0:after {
  border-top-color: white;
  border-width: 10px;
  left: 48px;
  margin-left: -10px;
}
.pop0:before {
  border-top-color: #cccccc;
  border-width: 11px;
  left: 48px;
  margin-left: -11px;
}

.pop1 {
  position: absolute;
  background-color: white;
  box-shadow: 0 1px 4px rgba(0,0,0,0.2);
  padding: 15px;
  border-radius: 10px;
  border: 1px solid #cccccc;
  bottom: 12px;
  left: -50px;
  min-width: 280px;
  height:60px;
}
.pop1:after, .pop1:before {
  top: 100%;
  border: solid transparent;
  content: " ";
  height: 0;
  width: 0;
  position: absolute;
  pointer-events: none;
}
.pop1:after {
  border-top-color: white;
  border-width: 10px;
  left: 48px;
  margin-left: -10px;
}
.pop1:before {
  border-top-color: #cccccc;
  border-width: 11px;
  left: 48px;
  margin-left: -11px;
}

.pop2 {
  position: absolute;
  background-color: white;
  box-shadow: 0 1px 4px rgba(0,0,0,0.2);
  padding: 15px;
  border-radius: 10px;
  border: 1px solid #cccccc;
  bottom: 12px;
  left: -50px;
  min-width: 280px;
}
.pop2:after, .pop2:before {
  top: 100%;
  border: solid transparent;
  content: " ";
  height: 0;
  width: 0;
  position: absolute;
  pointer-events: none;
}
.pop2:after {
  border-top-color: white;
  border-width: 10px;
  left: 48px;
  margin-left: -10px;
}
.pop2:before {
  border-top-color: #cccccc;
  border-width: 11px;
  left: 48px;
  margin-left: -11px;
}

.pop3 {
  position: absolute;
  background-color: white;
  box-shadow: 0 1px 4px rgba(0,0,0,0.2);
  padding: 15px;
  border-radius: 10px;
  border: 1px solid #cccccc;
  bottom: 12px;
  left: -50px;
  min-width: 280px;
}
.pop3:after, .pop3:before {
  top: 100%;
  border: solid transparent;
  content: " ";
  height: 0;
  width: 0;
  position: absolute;
  pointer-events: none;
}
.pop3:after {
  border-top-color: white;
  border-width: 10px;
  left: 48px;
  margin-left: -10px;
}
.pop3:before {
  border-top-color: #cccccc;
  border-width: 11px;
  left: 48px;
  margin-left: -11px;
}

.pop4 {
  position: absolute;
  background-color: white;
  box-shadow: 0 1px 4px rgba(0,0,0,0.2);
  padding: 15px;
  border-radius: 10px;
  border: 1px solid #cccccc;
  bottom: 12px;
  left: -50px;
  min-width: 280px;
}
.pop4:after, .pop4:before {
  top: 100%;
  border: solid transparent;
  content: " ";
  height: 0;
  width: 0;
  position: absolute;
  pointer-events: none;
}
.pop4:after {
  border-top-color: white;
  border-width: 10px;
  left: 48px;
  margin-left: -10px;
}
.pop4:before {
  border-top-color: #cccccc;
  border-width: 11px;
  left: 48px;
  margin-left: -11px;
}

.pop5 {
  position: absolute;
  background-color: white;
  box-shadow: 0 1px 4px rgba(0,0,0,0.2);
  padding: 15px;
  border-radius: 10px;
  border: 1px solid #cccccc;
  bottom: 12px;
  left: -50px;
  min-width: 280px;
}
.pop5:after, .pop0:before {
  top: 100%;
  border: solid transparent;
  content: " ";
  height: 0;
  width: 0;
  position: absolute;
  pointer-events: none;
}
.pop5:after {
  border-top-color: white;
  border-width: 10px;
  left: 48px;
  margin-left: -10px;
}
.pop5:before {
  border-top-color: #cccccc;
  border-width: 11px;
  left: 48px;
  margin-left: -11px;
}

.closer1 {
  text-decoration: none;
  position: absolute;
  top: 2px;
  right: 8px;
}
.closer1:after {
  content: "✖";
}
.closer2 {
  text-decoration: none;
  position: absolute;
  top: 2px;
  right: 8px;
}
.closer2:after {
  content: "✖";
}
.closer4 {
  text-decoration: none;
  position: absolute;
  top: 2px;
  right: 8px;
}
.closer4:after {
  content: "✖";
}
.closer5 {
  text-decoration: none;
  position: absolute;
  top: 2px;
  right: 8px;
}
.closer5:after {
  content: "✖";
}
.edit1 {
  text-decoration: none;
  position: absolute;
  top: 25px;
  right: 8px;
}
.edit1:after {
  content: "编辑";
}
.edit4 {
  text-decoration: none;
  position: absolute;
  top: 25px;
  right: 8px;
}
.edit4:after {
  content: "编辑";
}
.remove1 {
  text-decoration: none;
  position: absolute;
  top: 50px;
  right: 8px;
}
.remove1:after {
  content: "移除";
}
.remove4 {
  text-decoration: none;
  position: absolute;
  top: 50px;
  right: 8px;
}
.remove4:after {
  content: "移除";
}

.done0 {
  text-decoration: none;
  position: absolute;
  top: 40px;
  right: 8px;
}
.done0:after {
  content: "√";
}
.done2 {
  text-decoration: none;
  position: absolute;
  top: 40px;
  right: 8px;
}
.done2:after {
  content: "√";
}
.done3 {
  text-decoration: none;
  position: absolute;
  top: 40px;
  right: 8px;
}
.done3:after {
  content: "√";
}
.done5 {
  text-decoration: none;
  position: absolute;
  top: 40px;
  right: 8px;
}
.done5:after {
  content: "√";
}
</style>
