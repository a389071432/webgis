<template>
  <div class="content">
    <el-form :model="ruleForm2"  ref="ruleForm2" label-width="100px" class="demo-ruleForm" status-icon :rules="rules2">

      <el-form-item label="服务器地址" prop="url_server">
        <el-input v-model="ruleForm2.url_server"></el-input>
      </el-form-item>

      <el-form-item label="工作区" prop="url_workspace">
        <el-input v-model="ruleForm2.url_workspace"></el-input>
      </el-form-item>

      <el-form-item label="图层" prop="url_layer">
        <el-input v-model="ruleForm2.url_layer"></el-input>
      </el-form-item>

      <el-form-item label=" 命名" prop="name">
        <el-input v-model="ruleForm2.name"></el-input>
      </el-form-item>
    </el-form>

  </div>
</template>
<script>
import axios from "axios";

export default {
  name: "step1",
  data(){
    return {
      url_server:'',
      url_workspace:'',
      url_layer:'',
      ruleForm2: {
        url_server: '',
        url_workspace: '',
        url_layer: '',
        name:''
      },
      rules2: {
        url_server: [
          { required:true,type:'string', trigger: 'blur' ,message:'不能为空'}
        ],
        url_workspace: [
          { required:true,type:'string', trigger: 'blur' ,message:'不能为空'}
        ],
        url_layer: [
          { required:true,type:'string', trigger: 'blur' ,message:'不能为空'}
        ],
        name: [
          { required:true,type:'string', trigger: 'blur' ,message:'不能为空'}
        ],
      },
      tableData:[],
      layer_name:[],
      control:null,
      map:null,
      isshow: false,
      loading:false,
      dialogFormVisible: false,
      form: {
        name: '',
        type: [],
        resource: '',
        desc: ''
      },
      formLabelWidth: '120px',
    };
  },

  methods: {

//提交url，获取图层
    async submitForm() {
      let url=this.ruleForm2.url_server+'/'+this.ruleForm2.url_workspace+'/wms'
      let url_layer=this.ruleForm2.url_workspace+':'+this.ruleForm2.url_layer
      let msg='ok'
      //先检查输入是否合法
      await this.$refs.ruleForm2.validate((valid) => {
        if (!valid) {
          msg='url格式不正确'
        }
      })
      if(msg!=='ok')
        return msg
      //向后端提交buildings的url（待实现参数传递），成功则返回'ok'，否则返回错误信息
      let ans = await new Promise((resolve,reject) => {
        axios.post('http://222.94.162.146:5000/upload_population_file',{
          url:url,
          url_layer:url_layer
        }).then(res => {
          resolve(res.data)
        }).catch(error => {

        })
      })
      if(ans==='ok')
        msg='ok'
      else
        msg='网络错误，请重试'
      return msg
    },

  }
}
</script>

<style scoped>
.content{
  width:400px;
}
</style>
