<template>
  <div class="home">
    <Wave class="wave" />
    <div class="title">疫情传播仿真平台</div>
    <div class="links special-button1">
      <div class="sys1">
        <router-link to="/build_scene" style="position: relative;width: 380px;">
          <span>城市韧性监测/评估/预测</span>
        </router-link>
      </div>
    </div>
  </div>
</template>

<script>
import Wave from '../components/Wave'
export default {
  name: 'Home',
  components: {
    Wave
  }
}
</script>

<style lang="stylus" scoped>
.home
  position absolute
  width: 100%
  height: 100%
  top: 0
  left: 0
  .title
    font-size: 48px
    text-align: center
    line-height: 50px
    position: absolute
    top: 30%
    width: 100%
  .wave
    position absolute
    z-index 10
  .links
    position absolute
    font-size: 24px
    line-height: 50px
    top: 46%
    left: 0
    box-sizing border-box
    padding 0 100px
    width: 100%
    z-index 12
    display flex
    justify-content space-around
</style>
