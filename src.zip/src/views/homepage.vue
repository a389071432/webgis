<template>
  <div class="home">
    <Wave class="wave" />
    <div class="title">疫情传播仿真平台</div>
    <div class="links special-button1">
      <div class="sys1">
        <router-link to="/build_scene" style="position: relative;width: 380px;">
          <span>城市韧性监测/评估/预测</span>
        </router-link>
      </div>
      <button @click="to_ol_home()"></button>
    </div>
  </div>
</template>

<script>
import Wave from '../components/Wave'
import axios from "axios";
export default {
  name: 'Home',
  components: {
    Wave
  },
  methods:{
    to_ol_home:function (){
      console.log('ooo')
      let that=this
      axios.get('http://127.0.0.1:5000/construct_scene_temp').then( function(response) {
        let ans = response.data
        if(ans==='ok'){ //成功后跳转至仿真页面
          that.$router.push({name:'ol_home'})
        }
      }).catch(function (error) {
        //提示错误信息，待补充
      })
    }
  }
}
</script>

<style lang="stylus" scoped>
.home
  position absolute
  width: 100%
  height: 100%
  top: 0
  left: 0
  .title
    font-size: 48px
    text-align: center
    line-height: 50px
    position: absolute
    top: 30%
    width: 100%
  .wave
    position absolute
    z-index 10
  .links
    position absolute
    font-size: 24px
    line-height: 50px
    top: 46%
    left: 0
    box-sizing border-box
    padding 0 100px
    width: 100%
    z-index 12
    display flex
    justify-content space-around
</style>
