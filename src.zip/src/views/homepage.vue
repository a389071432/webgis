<template>
  <div class="home">

      <img class="pic" src="../assets/1.jpg">
    <Wave class="wave" />
    <h1>Agent-Based 疫情仿真</h1>
    <p>是否需要提供Agent合成支持？</p>
    <a @click="mode1" class="button2 b-pink rot-135">是</a>
    <a @click="mode2" class="button2 b-red rot-135">否</a>
    <div class="links special-button1">
      <div class="sys1">
        <router-link to="/build_scene" style="position: relative;width: 380px;">
        </router-link>
      </div>
      <button @click="to_ol_home()"></button>
    </div>
  </div>
</template>

<script>
import Wave from '../components/Wave'
import axios from "axios";
export default {
  name: 'Home',
  components: {
    Wave
  },
  methods:{
    mode1:function (){
      this.$router.push({name:'build_scene0'})
    },
    mode2:function (){
      this.$router.push({name:'build_scene'})
    },
    to_ol_home:function (){
      console.log('ooo')
      let that=this
      axios.get('http://222.94.162.146:5000/construct_scene_temp').then( function(response) {
        let ans = response.data
        console.log('ans',ans)
        if(ans==='ok'){ //成功后跳转至仿真页面
          that.$router.push({name:'ol_home'})
        }
      }).catch(function (error) {
        //提示错误信息，待补充
      })
    }
  }
}
</script>

<style lang="stylus" scoped>
.pic{
  position fixed
  height 100%
  width 100%
  opacity 0.75
}

h1,
h4 {
  font-family: 'Raleway', 'Open Sans', sans-serif;
  margin: 0;
  line-height: 1;
  position relative
  top -420px
  left 450px
  font-weight bold
  font-size 70px
}

p {
  font-family: 'Raleway', 'Open Sans', sans-serif;
  margin: 0;
  line-height: 1;
  position relative
  top -170px
  left 630px
  font-weight bold
  font-size 25px
}

.b-red, .b-red:before {
  background: rgba(234,110,72,1)
  background: -moz-linear-gradient(45deg, rgba(234,110,72,1) 0%, rgba(188,26,99,1) 100%);
  background: -webkit-gradient(left bottom, right top, color-stop(0%, rgba(234,110,72,1)), color-stop(100%, rgba(188,26,99,1)));
  background: -webkit-linear-gradient(45deg, rgba(234,110,72,1) 0%, rgba(188,26,99,1) 100%);
  background: -o-linear-gradient(45deg, rgba(234,110,72,1) 0%, rgba(188,26,99,1) 100%);
  background: -ms-linear-gradient(45deg, rgba(234,110,72,1) 0%, rgba(188,26,99,1) 100%);
  background: linear-gradient(45deg, rgba(234,110,72,1) 0%, rgba(188,26,99,1) 100%);
}

.button {
  display: inline-block;
  position: relative;
  border-radius: 3px;
  text-decoration: none;
  padding: .5em;
  margin: .5em;
  font-size: 2em;
  font-weight: bold;
  transition: all .5s;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  left:350px
  top:-150px
  width 180px
  padding-left 80px
  height:30px
}
.button:hover {
  text-shadow: 0px 0px 0px rgba(255, 255, 255, .75);
}
.button:hover:after {
  left: 100%;
  top: 100%;
  bottom: 100%;
  right: 100%;
}
.button:before {
  content: '';
  display: block;
  position: absolute;
  left: 0;
  top: 0;
  bottom: 0;
  right: 0;
  z-index: -1;
  border-radius: 5px;
  transition: all .5s;
}
.button:after {
  content: '';
  display: block;
  position: absolute;
  left: 2px;
  top: 2px;
  bottom: 2px;
  right: 2px;
  z-index: -1;
  border-radius: 5px;
  transition: all .5s;
}

.button2 {
  position relative
  display: inline-block;
  font-size: 2em;
  margin: .5em;
  padding: .5em;
  border-radius: 5px;
  transition: all .5s;
  filter: hue-rotate(0deg);
  color: #FFF;
  text-decoration: none;
  left:560px
  top:-150px
  width 180px
  padding-left 80px
  height:80px
}
.rot-135:hover {
  filter: hue-rotate(135deg);
}

.b-pink, .b-pink:before {
  background: rgba(231,72,234,1);
  background: -moz-linear-gradient(45deg, rgba(231,72,234,1) 0%, rgba(75,26,188,1) 100%);
  background: -webkit-gradient(left bottom, right top, color-stop(0%, rgba(231,72,234,1)), color-stop(100%, rgba(75,26,188,1)));
  background: -webkit-linear-gradient(45deg, rgba(231,72,234,1) 0%, rgba(75,26,188,1) 100%);
  background: -o-linear-gradient(45deg, rgba(231,72,234,1) 0%, rgba(75,26,188,1) 100%);
  background: -ms-linear-gradient(45deg, rgba(231,72,234,1) 0%, rgba(75,26,188,1) 100%);
  background: linear-gradient(45deg, rgba(231,72,234,1) 0%, rgba(75,26,188,1) 100%);
}
</style>
