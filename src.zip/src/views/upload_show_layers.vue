<template>
<div>
  <HeadNav></HeadNav>
  <leftMenu></leftMenu>
  <transition name="draw" enter-class="draw-enter" enter-active-class="draw-enter-active"
    leave-to-class="draw-leave-to" leave-active-class="draw-leave-active">
    <div @mouseleave="mouseleave" class="right-d" id="daoh" v-show="isshow" style="z-index: -10">
    <el-table :data="tableData" stripe border style="width:100%" highlight-current-row>
      　　<el-table-column type="server" label="服务器" width="80">
      　　</el-table-column>
      　　<el-table-column prop="workspace" label="工作区" align="center" min-width="80">
      　　</el-table-column>
      　　<el-table-column prop="layer" label="图层" align="center" min-width="80">
      　　</el-table-column>
         <el-table-column prop="name" label="名称" align="center" min-width="80">
        　　</el-table-column>
      　　<el-table-column label="操作" align="center" min-width="100">
      　　　　<template v-slot="scope">
                <el-button type="text" @click="show_layer(scope.$index)">显示</el-button>
                <el-button type="text" @click="hide_layer(scope.$index)">隐藏</el-button>
      　　　　　　<el-button type="text" @click="remove(scope.$index)">移除该图层</el-button>
      　　　　</template>
      　　</el-table-column>
    </el-table>
    </div>
  </transition>
  <div id="follow" class="follow"  @mouseenter="mousein()" style="height:22px;width:100%;background:#F0FFFF;">
    <div class="caret"></div>
  </div>
  <div v-loading="loading">
  <el-dialog title="添加图层" :visible.sync="dialogFormVisible" center >
    <el-form :model="ruleForm2"  ref="ruleForm2" label-width="100px" class="demo-ruleForm" status-icon :rules="rules2">

      <el-form-item label="GeoServer服务器地址" prop="url_server">
        <el-input v-model="ruleForm2.url_server"></el-input>
      </el-form-item>

      <el-form-item label="工作区" prop="url_workspace">
        <el-input v-model="ruleForm2.url_workspace"></el-input>
      </el-form-item>

      <el-form-item label="图层" prop="url_layer">
        <el-input v-model="ruleForm2.url_layer"></el-input>
      </el-form-item>

      <el-form-item label=" 命名" prop="name">
        <el-input v-model="ruleForm2.name"></el-input>
      </el-form-item>
    </el-form>

    <div slot="footer" class="dialog-footer">
      <el-button @click="dialogFormVisible = false; resetForm('ruleForm2')">取 消</el-button>
      <el-button type="primary" @click="submitForm('ruleForm2')">提交</el-button>
    </div>
  </el-dialog>
  </div>
  <el-button v-on:click="add_a_layer" class='button' type="primary" style="position:absolute; top:65px;left:190px;">添加图层</el-button>
  <div id="olmap" ref="olmap" style="position:absolute;width: 100%; height: 700px;top:110px;z-index: -10;" ></div>

</div>
</template>

<script>
import Map from "ol/Map";
import View from "ol/View";
import {transform} from "ol/proj";
import TileLayer from 'ol/layer/Tile';
import TileWMS from 'ol/source/TileWMS';
import HeadNav from "../components/HeadNav";
import LeftMenu from "../components/LeftMenu";

export default {
  name: "upload_show_layers",
  components: {
    LeftMenu,
    HeadNav
  },
  data(){
    return {
      url_server:'',
      url_workspace:'',
      url_layer:'',
      ruleForm2: {
        url_server: '',
        url_workspace: '',
        url_layer: '',
        name:''
      },
      rules2: {
        url_server: [
          { required:true,type:'string', trigger: 'blur' ,message:'不能为空'}
        ],
        url_workspace: [
          { required:true,type:'string', trigger: 'blur' ,message:'不能为空'}
        ],
        url_layer: [
          { required:true,type:'string', trigger: 'blur' ,message:'不能为空'}
        ],
        name: [
          { required:true,type:'string', trigger: 'blur' ,message:'不能为空'}
        ],
      },
      tableData:[],
      layer_name:[],
      control:null,
      map:null,
      isshow: false,
      loading:false,
      dialogTableVisible: false,
      dialogFormVisible: false,
      form: {
        name: '',
        type: [],
        resource: '',
        desc: ''
      },
      formLabelWidth: '120px',
    };
  },
  mounted() {
    this.init()
  },
  activated() {

  },
  deactivated() {
    let that=this
    setTimeout(function (){
      that.$root.$emit('update_layers',{'layers':that.map.getLayers(),'layer_names':that.layer_name})
    },1000)//切出本页时，发送本页当前的所有layer
  },
  methods: {
    //初始化
    init:function(){
      //初始化map对象
      this.map = new Map({
        target: 'olmap',
        view: new View({
          center: [121.5, 31.25],
          zoom: 10,
          minZoom:4,
          maxZoom:100,
          projection: 'EPSG:4326'
        })
      })
      let that=this
      // this.map.on('singleclick', function(evt) {
      //   document.getElementById('nodelist').innerHTML = "Loading... please wait...";
      //   let view = that.map.getView();
      //   let viewResolution = view.getResolution();
      //   let source = that.map.getLayers().item(0).getSource();
      //   let url = source.getGetFeatureInfoUrl(
      //     evt.coordinate, viewResolution, view.getProjection(),
      //     {'INFO_FORMAT': 'text/html', 'FEATURE_COUNT': 50});
      //   if (url) {
      //     document.getElementById('nodelist').innerHTML = '<iframe  src="' + url + '"></iframe>';
      //   }
      // });
    },
    //鼠标移入
    mousein:function() {
      //clearTimeout(this.timer);
      this.isshow = true;
    },
    //鼠标移出
    mouseleave:function (){
      this.timer = setTimeout(() => {
        this.isshow = false;
      }, 100);
    },
    //添加新图层，弹出输入框
    add_a_layer(){
        this.dialogFormVisible=true
    },
    //提交url，获取图层
    submitForm(formName) {
      let url=this.ruleForm2.url_server+'/'+this.ruleForm2.url_workspace+'/wms'
      let url_layer=this.ruleForm2.url_workspace+':'+this.ruleForm2.url_layer
      this.$refs.ruleForm2.validate((valid) => {
        if (valid) {
          this.dialogFormVisible = false;
          //从服务器获取layer
          let layer = new TileLayer({
            source: new TileWMS({
              url:url,
              params: {'FORMAT':  'image/png',
                'VERSION': '1.1.1',
                tiled: true,
                "STYLES": '',
                "LAYERS":url_layer,
                "exceptions": 'application/vnd.ogc.se_inimage',
                //tilesOrigin: 121.12548861 + "," + 31.08278751
              }
            })
          })
          layer.set('name',this.ruleForm2.name)
          this.map.addLayer(layer)
          //更新表格
          this.tableData.push({'server':this.ruleForm2.url_server,'workspace':this.ruleForm2.url_workspace,'layer':this.ruleForm2.url_layer,'name':this.ruleForm2.name})
          this.layer_name.push({name:this.ruleForm2.name})
        }
        else {    //提示输入无效
          return false;
        }
      });
    },
    show_layer:function(index){
      console.log('show show')
      let name=this.tableData[index]['name']
      let layer=null
      this.map.getLayers().forEach(function (lyr) {
        if (name === lyr.get('name')) {
          layer = lyr
        }
      })
      layer.setVisible(true)

    },
    hide_layer:function(index){
      let name=this.tableData[index]['name']
      let layer=null
      this.map.getLayers().forEach(function (lyr) {
        if (name === lyr.get('name')) {
          layer = lyr
        }
      })
      layer.setVisible(false)
    },
  }
}
</script>

<style scoped>
.draw-enter-active,.draw-leave-active{
  transition:max-height 0.5s ease;
}
.draw-enter,.draw-leave-to{
  height: 0 ;
  opacity: 0;
}
.draw-enter-to,.draw-leave {
  max-height: 400px ;
}

.caret {
  display: inline-block;
  width: 0px;
  height: 0px;
  border-left: 10px solid transparent;
  border-top: 10px solid;
  border-right: 10px solid transparent;
}
</style>
