<template>
<div>
  <div class="step_container">
    <el-steps  :active="active" finish-status="success" align-center :space="520" style="width: 90%; margin-bottom: 12px;">
      <el-step title="构建Agent"></el-step>
      <el-step title="城市建筑数据"></el-step>
      <el-step title="城市用地信息"></el-step>
      <el-step title="感染模型"></el-step>
      <el-step title="场景构建完毕"></el-step>
    </el-steps>
  </div>
  <div class="main_container">
    <transition name="slide-fade" >
      <div class="box_container box_step0" v-show="this.show0===1">
        <div class="tip">
          <i class="bb-title">上传人口数据</i>
          <img src="../assets/details.png" @click="show_details0" alt="说明" style="position:relative;left: 156px; top:-8px; width: 22px;height: 22px;">
        </div>
        <step0 class="step0" ref="step0"></step0>
        <el-dialog title="人口数据" :visible.sync="visible0" center @close="close0" >
          <div style="height:500px;"></div>
        </el-dialog>
      </div>
    </transition>
    <transition name="slide-fade" >
    <div class="box_container box_step1" v-show="this.show1===1">
        <div class="tip">
          <i class="bb-title">上传城市建筑图层</i>
          <img src="../assets/details.png" @click="show_details1" alt="说明" style="position:relative;left: 156px; top:-8px; width: 22px;height: 22px;">
        </div>
        <step1 class="step1" ref="step1"></step1>
      <el-dialog title="城市建筑数据" :visible.sync="visible1" center @close="close1" >
        <div style="height:500px;"></div>
      </el-dialog>
    </div>
    </transition>
    <transition name="slide-fade">
    <div class="box_container box_step2" v-show="this.show2===1">
      <div class="tip">
        <i class="bb-title">上传城市用地图层</i>
        <img src="../assets/details.png" @click="show_details2" alt="说明" style="position:relative;left: 156px; top:-8px; width: 22px;height: 22px;">
      </div>
      <step1 class="step1" ref="step2"></step1>
      <el-dialog title="城用地筑数据" :visible.sync="visible2" center @close="close2" >
        <div style="height:500px;"></div>
      </el-dialog>
    </div>
      </transition>
    <transition name="slide-fade">
    <div class="box_container box_step3" v-show="this.show3===1">
      <div style="left:470px;"  class="tip">
        <i class="bb-title">编辑感染模型</i>
        <img src="../assets/details.png" @click="show_details3" alt="说明" style="position:relative;left: 156px; top:-8px; width: 22px;height: 22px;">
      </div>
        <editable_form class="step3" ref="step3"></editable_form>
      <el-dialog title="感染状态模型" :visible.sync="visible3" center @close="close3" >
        <div style="height:500px;"></div>
      </el-dialog>
    </div>
    </transition>
  </div>
  <div class="button_container">
    <el-button style="margin-top:12px;" @click="pre">上一步</el-button>
    <div style="width:70px"></div>
    <el-button id="next" style="margin-top:12px;" @click="next">下一步</el-button>
  </div>
</div>
</template>

<script>
import step0 from './components/step0'
import step1 from './components/step1'
import step2 from './components/step2'
import editable_form from "./editable_form";
import Editable_form from "./editable_form";
import axios from "axios";
import Feature from "ol/Feature";
import Point from "ol/geom/Point";

export default {
  name: "build_scene",
  components:{
    Editable_form,
    step0,
    step1,
    step2,
    editable_form
  },

  data(){
    return{
      active: 0,
      visible0:false,
      visible1:false,
      visible2:false,
      visible3:false,
      show0:1,
      show1:0,
      show2:0,
      show3:0,
   };
  },
  async mounted() {
    await this.init()
  },
  methods:{
    async init(){
      let msg=await axios.post('http://127.0.0.1:5000/init_globvars')
    },
    async next(){
      let msg
      if(this.active===0){
        msg=await this.$refs.step0.submit()
        if(msg==='ok'){
          this.show0=0
          let that=this
          setTimeout(function () {
            that.show1=1
            that.active++
          }, 1000)
        }
        else{   //提示错误信息，待补充

        }
      }
      else if(this.active===1){
        msg=await this.$refs.step1.submitForm()
        if(msg==='ok'){
          this.show1=0
          let that=this
          setTimeout(function () {
            that.show2=1
            that.active++
          }, 1000);
        }
        else{   //提示错误信息，待补充

        }
      }
      else if(this.active===2){
        msg=await this.$refs.step2.submitForm()
        if(msg==='ok'){
          this.show2=0
          let that=this
          setTimeout(function () {
            that.show3=1
            that.active++
          }, 1000);
        }
        else{   //提示错误信息，待补充

        }
      }
      else if(this.active===3){
        msg=await this.$refs.step3.submitForm()
        if(msg==='ok'){
          this.active++
          document.getElementById('next').innerText='完成'
        }
        else{   //提示错误信息，待补充

        }
      }
      else if(this.active===4){  //数据准备完毕
        //要求后端构建场景
        let that=this
        axios.get('http://127.0.0.1:5000/construct_scene').then( function(response) {
          let ans = response.data
          if(ans==='ok'){ //成功后跳转至仿真页面
            that.$router.push({path:'/map'})
            console.log('jump to ol_map')
          }
        }).catch(function (error) {
          //提示错误信息，待补充
        })

      }
        if(this.active>4)
          this.active = 0
    },
    pre() {
      if(this.active===4){
         document.getElementById('next').innerText='下一步';
         this.active--
      }
      if(this.active===3){
          this.show3=0
          let that=this
          setTimeout(function () {
            that.show2=1
            that.active--
          }, 1000);
      }
      else if(this.active===2){
        this.show2=0
        let that=this
        setTimeout(function () {
          that.show1=1
          that.active--
        }, 1000);
      }
      else if(this.active===1){
        this.show1=0
        let that=this
        setTimeout(function () {
          that.show0=1
          that.active--
        }, 1000);
      }
    },
    show_details0(){
      this.visible0=true
    },
    show_details1(){
      this.visible1=true
    },
    show_details2(){
      this.visible2=true
    },
    show_details3(){
      this.visible3=true
    },
    close0(){
      this.visible0=false
    },
    close1(){
      this.visible1=false
    },
    close2(){
      this.visible2=false
    },
    close3(){
      this.visible3=false
    },
  }
}
</script>

<style scoped>
.step_container{
  position: relative;
  height: 100px;
  width: 100%;
  display: flex;
  justify-content: space-around;
  align-items: flex-end;
}
.main_container{
  position: relative;
  top:15px;
  width: 100%;
  height:535px;
}
.button_container{
  position: relative;
  display: flex;
  display: -webkit-flex;
  flex-direction: row;
  justify-content: center;
  align-content: center;
  width: 100%;
}
.box_container{

}
.box_step0{
  width: 100%;
  height:420px;
  padding-left: 590px;
  padding-top: 100px;
}
.box_step1{
  width: 100%;
  height:420px;
  padding-left: 590px;
  padding-top: 100px;
}
.box_step2{
  width: 100%;
  height:420px;
  padding-left: 590px;
  padding-top: 100px;
}
.box_step3{
  width: 100%;
  height:420px;
  padding-left: 200px;
  padding-top: 100px;
}

.tip{
  position: relative;
  display: flex;
  display: -webkit-flex;
  flex-direction: row;
}
.bb-title{
  position:relative;
  top: -10px;
  left: 150px;
  font-size: 18px;
  font-weight: 700;
  color:black;
  padding-left: 16px;
}

.box_step3{
  width: 900px;
  height:420px;
  padding-left: 130px;
}
.box0{
  padding-left: 130px;
  padding-bottom: 0;
  padding-top: 0;
  width:45%;
  display: flex;
  flex-wrap: wrap;
  flex-direction: column;
  align-content: flex-start;
}
.box1{
  padding-left: 0px;
  padding-bottom: 0;
  padding-top: 0;
  width:55%;
}
.step1{
  position: relative;
  top:30px;
}
.step2{
  position: relative;
  top:30px;
}
.step3{
  position: relative;
  left:330px;
  top:30px;
}

.slide-fade-enter-active {
  transition: all .25s linear;
}
.slide-fade-leave-active {
  transition: all .25s linear;
}
.slide-fade-enter, .slide-fade-leave-to {
  transform: translateX(-200px);
  opacity: 0;
}

</style>
