<template>
  <div>
  <HeadNav></HeadNav>
  <leftMenu></leftMenu>
    <p>您需要上传以下两种数据文件，来进行人口数据合成</p>
    <p></p>
    <p>household信息，包含家庭成员的基本属性，数据格式如下图所示</p>
    <img src="../assets/pic1.png">
    <p></p>
    <p></p>
    <input ref="fileRef" type="file" @change="fileChange">
    <p></p>
    <p></p>
    <p></p>
    <p></p>
    <p></p>
    <p></p>
    <p>个体活动模式信息，数据格式如下图所示</p>
    <img src="../assets/pic2.png">
    <p></p>
    <p></p>
    <input ref="fileRef" type="file" @change="fileChange">
    <div class="dialog_btn">
      <p></p>
      <p></p>
      <p></p>
      <p></p>
      <el-button @click="readFile">确认</el-button>
    </div>
  </div>
</template>

<script>
import LeftMenu from "../components/LeftMenu";
import HeadNav from "../components/HeadNav";

export default {
  name: "upload_population",
  components: {
    LeftMenu,
    HeadNav
  },
  methods:{
    fileChange:function (){

    },
    readFile:function (){

    },
  }
}
</script>

<style scoped>

</style>
