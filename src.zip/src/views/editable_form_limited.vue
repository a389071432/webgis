<template>
  <div>
    <el-table
      ref="mytable"
      :data="table_data"
      style="width: 100%"
      :row-style="tableRowStyle"
      :header-cell-style="tableHeaderColor"
      @selection-change="handleSelectionChange"
    >
      <el-table-column v-if="radio" type="index" width="50"></el-table-column>
      <el-table-column v-if="selection" type="selection" width="55"></el-table-column>
      <el-table-column label="原状态" prop="state0" width="100" >
        <template slot-scope="scope">
          <el-input
            v-if="nosense"
            size="small"
            v-model="scope.row['state0']"
          ></el-input>
          <span v-if="  !nosense">{{scope.row['state0']}}</span>
        </template>
      </el-table-column>
      <el-table-column label="新状态" prop="state1">
        <template slot-scope="scope">
          <el-input
            v-if="nosense"
            size="small"
            v-model="scope.row['state1']"
          ></el-input>
          <span v-if="  !nosense">{{scope.row['state1']}}</span>
        </template>
      </el-table-column>
      <el-table-column label="转移概率" >
        <el-table-column label="青少年" prop="p0">
          <template slot-scope="scope">
            <el-input
              v-if=" scope.row.edit"
              size="small"
              v-model="scope.row['p0']"
            ></el-input>
            <span v-if="  !scope.row.edit">{{scope.row['p0']}}</span>
          </template>
        </el-table-column>
        <el-table-column label="中年" prop="p1"><template slot-scope="scope">
          <el-input
            v-if=" scope.row.edit"
            size="small"
            v-model="scope.row['p1']"
          ></el-input>
          <span v-if="  !scope.row.edit">{{scope.row['p1']}}</span>
        </template></el-table-column>
        <el-table-column label="老年" prop="p2">
          <template slot-scope="scope">
            <el-input
              v-if=" scope.row.edit"
              size="small"
              v-model="scope.row['p2']"
            ></el-input>
            <span v-if="  !scope.row.edit">{{scope.row['p2']}}</span>
          </template>
        </el-table-column>
      </el-table-column>
      <el-table-column label="转移时延" >
        <el-table-column label="青少年" prop="t0">
          <template slot-scope="scope">
            <el-input
              v-if=" scope.row.edit"
              size="small"
              v-model="scope.row['t0']"
            ></el-input>
            <span v-if="  !scope.row.edit">{{scope.row['t0']}}</span>
          </template>
        </el-table-column>
        <el-table-column label="中年" prop="t1">
          <template slot-scope="scope">
            <el-input
              v-if=" scope.row.edit"
              size="small"
              v-model="scope.row['t1']"
            ></el-input>
            <span v-if="  !scope.row.edit">{{scope.row['t1']}}</span>
          </template>
        </el-table-column>
        <el-table-column label="老年" prop="t2">
          <template slot-scope="scope">
            <el-input
              v-if=" scope.row.edit"
              size="small"
              v-model="scope.row['t2']"
            ></el-input>
            <span v-if="  !scope.row.edit">{{scope.row['t2']}}</span>
          </template>
        </el-table-column>
      </el-table-column>
      <el-table-column label="操作" align="center">
        <template slot-scope="scope">
          <!-- 全局控制的编辑 -->
          <div v-if="is_edit&&scope.row.add==undefined" style="display: inline-block;">
            <!-- 编辑 -->
            <el-button
              size="mini"
              v-if="!scope.row.edit"
              @click="handleEdit(scope.$index, scope.row)"
              type="primary"
            >Edit</el-button>
            <!-- 保存 -->
            <el-button
              size="mini"
              type="success"
              :plain="true"
              v-if="scope.row.edit"
              @click="handleSave(scope.$index, scope.row)"
            >Save</el-button>
          </div>
          <!-- 添加控制 -->
          <div v-if="scope.row.add!=undefined&&scope.row.add" style="display: inline-block;">
            <!-- 保存 -->
            <el-button
              size="mini"
              type="success"
              :plain="true"
              v-if="scope.row.edit"
              @click="handleSave(scope.$index, scope.row)"
            >Save</el-button>
          </div>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
import axios from "axios";

export default {
  mounted: function() {
    this.initEditAttribute();
    //确保方法在页面渲染后调用
    this.$nextTick(function() {
      /////方法
      this.tableRowClassName();
    });
  },
  watch: {
    space_color: function() {
      //监听数据变化
      this.$nextTick(function() {
        /////方法
        this.tableRowClassName();
      });
    },
    table_data: function() {
      //监听数据变化f
      this.$nextTick(function() {
        /////方法
        this.tableRowClassName();
      });
    }
  },
  data() {
    return {
      nosense:false,
      new_date_json: {}, //数据结构
      multipleSelection: [], //复选框，数据
      is_edit: true, //是否可编辑
      is_delete: true, //是否可删除
      selection: true, //是否需要复选框
      radio: false, //单选变色
      space_color: true, //隔行变色
      //表头信息
      table_columns: [
        {
          prop: "date",
          label: "日期",
          width: "150"
        },
        {
          prop: "name",
          label: "姓名",
          width: "150"
        },
        {
          prop: "sex",
          label: "年龄",
          width: "150"
        },
        {
          prop: "province",
          label: "省份",
          width: ""
        },
        {
          prop: "city",
          label: "城市",
          width: "150"
        },
        {
          prop: "address",
          label: "地址",
          width: "150"
        }
      ],
      //表格数据
      table_data: null,
    };
  },
  methods: {
    allow_modify:function(){     //显示修改
       for(let i=0;i<this.table_data.length;i++)
         this.table_data[i].edit=true
    },
    async submitForm(){   //提交感染模型到后端
      let msg
      //向后端提交infected_model表格，成功则返回'ok'，否则返回错误信息
      let ans = await new Promise((resolve,reject) => {
        axios.post('http://127.0.0.1:5000/upload_infected_model_limited',
          {form:this.table_data,land_contacts:0,p:0}  //待修改前端，land_contacts和p应是用户输入
        ).then(res => {
          resolve(res.data)
        }).catch(error => {

        })
      })
      if(ans==='ok')
        msg='ok'
      else
        msg='网络错误，请重试'
      return msg
    },
    //隔行变色
    tableRowClassName() {
      //选取DOM节点
      var trs = this.$refs.mytable.$el
        .getElementsByTagName("tbody")[0]
        .getElementsByTagName("tr");
      for (var i in trs) {
        if (i % 2 == 0) {
          //当隔行变色未true时改变颜色
          if (this.space_color) {
            trs[i].style.backgroundColor = "#f0f9eb";
          } else {
            trs[i].style.backgroundColor = "";
          }
        }
      }
    },
    //多选框
    handleSelectionChange(val) {
      this.multipleSelection = val;
      console.log("selection:", this.multipleSelection);
    },
    //编辑
    handleEdit(index, row) {
      console.log(index, row);
      row.edit = true;
    },
    //初始化时逐个添加并保存条目
    init_items:function (data){
      this.table_data=[]
      for(let k=0;k<data.length;k++){
        let row=data[k]
        //row.edit=true
        //row.add=true
        this.table_data.push(row)
      }
    },
    //保存
    handleSave(index, row) {
      this.table_data[index]=row
      row.edit = false
      delete this.table_data[index].add
      //console.log(JSON.parse(JSON.stringify(this.table_data)))
      this.$message({
        message: "保存成功！",
        type: "success"
      });
    },
    handleAdd() {
      var addDataJson = {};
      for (var key in this.new_date_json) {
        if (key === "edit") {
          delete addDataJson[key];
        } else if (key === "add") {
          delete addDataJson[key];
        } else {
          addDataJson[key] = "";
        }
      }
      addDataJson.edit = true;
      addDataJson.add = true;
      this.table_data.push(addDataJson);
    },
    //初始化编辑属性
    initEditAttribute() {
      var self = this;
      var edit = self.edit;

      var dataArray = [];

      if (dataArray.length > 0) {
        //添加编辑事件
        for (var index in dataArray) {
          dataArray[index]["edit"] = false;
          this.table_data.push(dataArray[index]);
        }

        if (Object.keys(this.new_date_json).length === 0) {
          //新增时，初始化数据结构
          this.initAddDataJson(dataArray[0]);
        }
      }
    },
    initAddDataJson(dataArray) {
      //新增时，初始化数据结构
      var dataJson = dataArray;
      var newDateJson = {};
      for (var key in dataJson) {
        if (key === "edit") {
          newDateJson[key] = "true";
        } else {
          newDateJson[key] = "";
        }
      }
      newDateJson["add"] = true;
      this.new_date_json = newDateJson;
    },
    tableRowStyle({row,rowIndex}){             //设置表格行的样式
      return 'background-color:pink;font-size:15px;'
    },
    tableHeaderColor({row,column,rowIndex,columnIndex}){         //设置表头行的样式
      return 'background-color:lightgrey;color:#ff;font-wight:300;font-size:20px;text-align:center'
    }
  },
};
</script>
<style scoped>
</style>
