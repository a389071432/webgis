import Vue from 'vue'
import Router from 'vue-router'
import homepage from '../views/homepage'
import ol_home from '../views/ol_home'
import edit_infected_model from "../views/edit_infected_model";
import upload_show_layers from "../views/upload_show_layers";
import statis from "../views/statis";
import upload_population from "../views/upload_population";
Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'homepage',
      component: homepage
    },
    {
      path: '/upload_show_layers',
      name: 'upload_show_layers',
      component: upload_show_layers
    },
    {
      path: '/upload_population',
      name: 'upload_population',
      component: upload_population
    },
    {
      path: '/edit_infected_model',
      name: 'edit_infected_model',
      component: edit_infected_model
    },
    {
      path: '/map',
      name: 'ol_home',
      component: ol_home
    },
    {
      path: '/statis',
      name: 'statis',
      component: statis
    },

  ]
})
