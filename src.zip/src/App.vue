<template>
  <div id="app">
<keep-alive>
    <router-view/>
</keep-alive>
  </div>
</template>

<script>
export default {
  name: 'App',
  // data(){
  //   return{
  //     eventHub:new Vue()
  //   }
  // }
}
</script>

<style lang="stylus">
[v-cloak] {
  display: none;
}

html, body
  width: 100%
  height: 100%
  padding: 0
  margin: 0

#app
  width: 100%
  height: 100%
  color #fff

.border-box
  border: 1px solid #232831
  margin: 8px
  padding: 10px
  overflow hidden
  box-sizing: border-box
  position relative


.fade-enter-active, .fade-leave-active
  transition: opacity .5s;
.fade-enter, .fade-leave-to
  opacity 0
.child-view
  transition: all .5s cubic-bezier(.55,0,.1,1);
.slide-left-enter, .slide-right-leave-active
  opacity: 0;
  transform: translate(30px, 0);
.slide-left-leave-active, .slide-right-enter
  opacity: 0;
  transform: translate(-30px, 0);
</style>
