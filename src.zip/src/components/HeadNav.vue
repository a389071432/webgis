<template>
  <div class="header">
    <i class="title">疫情传播仿真系统</i>
  </div>
</template>

<script>
export default {
  name: 'Header',
}
</script>

<style lang="stylus" scoped>
$header-height = 70px
.header
  width: 100%
  height: $header-height
  line-height: $header-height
  background-image: linear-gradient(rgba(5, 14, 38, 0.91), #061c38);
  text-align center
  position relative
  &::after
    content: ''
    position absolute
    display block
    width: 400px
    height: 0
    border-bottom: 0 solid transparent
    border-top: $header-height solid #2c3549
    border-right: 60px solid transparent
    border-left: 60px solid transparent
    top: 0
    left: 50%
    z-index 5
    transform translateX(-50%)
  .title
    position relative
    z-index 10
    font-size: 40px
    background: linear-gradient(#8bdeed 50%, #3680ff);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    font-weight: 700
    text-shadow 2px 2px 2px rgba(200,200,200,0.1)
</style>
