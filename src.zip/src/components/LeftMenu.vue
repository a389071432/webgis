<template>
  <!-- 侧边栏 -->
  <el-aside :width="isCollapse?'64px':'180px'">
    <!-- 侧边栏菜单区域 -->
    <el-menu background-color="#324057" text-color="#fff" active-text-color="#409EFF"
             unique-opened
             :collapse="isCollapse"
             :collapse-transition="false"
             :router="true">
      <!-- 一级菜单 -->

      <keep-alive>
        <router-link to="/edit_infected_model">
          <el-menu-item index='2'>
            <i class="fa fa-margin fa-server"></i>
            <span slot="title">编辑传染模型</span>
          </el-menu-item>
        </router-link>
      </keep-alive>

      <keep-alive>
        <router-link to="/map">
          <el-menu-item index='3'>
            <i class="fa fa-margin fa-server"></i>
            <span slot="title">仿真主界面</span>
          </el-menu-item>
        </router-link>
      </keep-alive>

      <keep-alive>
        <router-link to="/visualization_3d">
          <el-menu-item index='4'>
            <i class="fa fa-margin fa-server"></i>
            <span slot="title">3D可视化</span>
          </el-menu-item>
        </router-link>
      </keep-alive>

      <keep-alive>
        <router-link to="/upload_show_layers">
          <el-menu-item index='5'>
            <i class="fa fa-margin fa-server"></i>
            <span slot="title">添加/预览图层</span>
          </el-menu-item>
        </router-link>
      </keep-alive>

      <keep-alive>
        <router-link to="/statis">
          <el-menu-item index='6'>
            <i class="fa fa-margin fa-server"></i>
            <span slot="title">感染曲线图</span>
          </el-menu-item>
        </router-link>
      </keep-alive>
    </el-menu>
  </el-aside>
</template>
<script>
export default {
  name: "leftmenu",
  data() {
    return {
      isCollapse: false,
      items: [
        {
          icon: "fa-mapbox",
          name: "MapBox",
          path: "mapbox",
          children: [
            { path: "mapboxgl_initmap", name: "基础地图" },
            { path: "mapboxgl_drawmap", name: "绘制地图" },
            { path: "mapboxgl_3dbuilding", name: "3D建筑物" },
            { path: "mapboxgl_tdtbuilding", name: "三维测试"},
            { path: "mapboxgl_gridmap", name: "网格可视化"},
            { path: "mapboxgl_hexagonmap", name: "蜂窝图可视化"}
          ]
        },
        {
          icon: "fa-openlayers",
          name: "Openlayers",
          path: "openlayers",
          children: [
            { path: "ol_superclustermap", name: "聚类" },
            { path: "ol_clipmap", name: "按区域裁剪地图"},
            { path: "ol_clustermap", name: "统计聚类" },
            { path: "ol_FeatureEdit", name: "要素编辑"}
          ]
        },
        {
          icon: "fa-arcgis",
          name: "ArcGIS",
          path: "ArcGIS",
          children: [
            { path: "arcgismap", name: "ArcGIS地图（3D）" },
            { path: "ags_basemap", name: "基础地图"},
            { path: "ags_tilemap", name: "切片地图"},
            { path: "ags_drawmap", name: "绘制要素"}
          ]
        }
      ]
    };
  },
  methods: {
    toggleCollapse () {
      this.isCollapse = !this.isCollapse
    }
  }
};
</script>
<style lang="less" scoped>
.el-aside {
  border-radius: 4px;
  //border: 1px solid #1a2030);
  position: fixed;
  top: 60px;
  left: 0;
  min-height: 100%;
  background-image: linear-gradient(#1a2030);
  z-index: 99;
  .el-menu {
    border-right: none;
    background: #1a2030;
  }
}
.el-menu-item{
  border: 2px green;
}

.el-main {
  background-image: linear-gradient(#1a2030);
}
.iconfont {
  margin-right: 20px;
}
.toggle-button {
  background-image: linear-gradient(#1a2030);
  font-size: 10px;
  line-height: 24px;
  color: #fff;
  text-align: center;
  letter-spacing: 0.2em;
  cursor: pointer;
}
.hiddenDropdown,
.hiddenDropname {
  display: none;
}
a {
  text-decoration: none;
}
</style>
