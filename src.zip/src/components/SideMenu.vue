<template>
  <div class='dashboard'>
    <div class="dashboard-nav">
      <header><span style="font-size: 20px;font-weight: bold">界面选择</span></header>
      <nav class="dashboard-nav-list">
        <keep-alive>
          <div class="dashboard-nav-item">
          <router-link to="/map">
            <p style="font-size: 18px;font-weight: bold;position: relative;left:-5px;">主界面</p>
          </router-link>
          </div>
        </keep-alive>

        <keep-alive>
          <div class="dashboard-nav-item">
            <router-link to="/visualization_3d">
              <p style="font-size: 18px;font-weight: bold;position: relative;left:-19px;">三维可视化</p>
            </router-link>
          </div>
        </keep-alive>

        <keep-alive>
          <div class="dashboard-nav-item">
            <router-link to="/statis">
              <p style="font-size: 18px;font-weight: bold;position: relative;left:-9px;">状态统计</p>
            </router-link>
          </div>
        </keep-alive>

        <keep-alive>
          <div class="dashboard-nav-item">
            <router-link to="/edit_infected_model">
              <p style="font-size: 18px;font-weight: bold;position: relative;left:-9px;">感染模型</p>
            </router-link>
          </div>
        </keep-alive>
        <div class="nav-item-divider"></div>
      </nav>
    </div>
  </div>
</template>

<script>
export default {
  name: "SideMenu"
}
</script>

<style scoped>
:root {
  --font-family-sans-serif: "Open Sans", -apple-system, BlinkMacSystemFont,
  "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif, "Apple Color Emoji",
  "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
}

*, *::before, *::after {
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
}


nav {
  display: block;
}


h1, h2, h3, h4, h5, h6 {
  margin-top: 0;
  margin-bottom: 0.5rem;
}

p {
  margin-top: 0;
  margin-bottom: 1rem;
}

a {
  color: #3f84fc;
  text-decoration: none;
  background-color: transparent;
}

a:hover {
  color: #0458eb;
  text-decoration: underline;
}

h1, h2, h3, h4, h5, h6, .h1, .h2, .h3, .h4, .h5, .h6 {
  font-family: "Nunito", sans-serif;
  margin-bottom: 0.5rem;
  font-weight: 500;
  line-height: 1.2;
}

h1, .h1 {
  font-size: 2.5rem;
  font-weight: normal;
}


.dashboard {
  display: -webkit-box;
  display: -webkit-flex;
  display: -ms-flexbox;
  display: flex;
  min-height: 100vh;
  height:800px;
}


.dashboard-nav {
  height:750px;
  min-width: 180px;
  position: relative;
  left: 0;
  top: 3px;
  bottom: 0;
  overflow: auto;
  background-color: #ffffff;
  border-radius: 4px;
  box-shadow: 2px 2px 4px #969494;
}

.dashboard-compact .dashboard-nav {
  display: none;
}

.dashboard-nav header {
  min-height: 84px;
  padding: 8px 27px;
  display: -webkit-box;
  display: -webkit-flex;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-pack: center;
  -webkit-justify-content: center;
  -ms-flex-pack: center;
  justify-content: center;
  -webkit-box-align: center;
  -webkit-align-items: center;
  -ms-flex-align: center;
  align-items: center;
}

.dashboard-nav header .menu-toggle {
  display: none;
  margin-right: auto;
}

.dashboard-nav a {
  color: #444444;
}

.dashboard-nav a:hover {
  text-decoration: none;
}

.dashboard-nav {
  background-color: rgba(5, 19, 45, 0.82);
}

.dashboard-nav a {
  color: #fff;
}

.brand-logo {
  font-family: "Nunito", sans-serif;
  font-weight: bold;
  font-size: 20px;
  display: -webkit-box;
  display: -webkit-flex;
  display: -ms-flexbox;
  display: flex;
  color: #515151;
  -webkit-box-align: center;
  -webkit-align-items: center;
  -ms-flex-align: center;
  align-items: center;
}

.brand-logo:focus, .brand-logo:active, .brand-logo:hover {
  color: #dbdbdb;
  text-decoration: none;
}

.brand-logo i {
  color: #d2d1d1;
  font-size: 27px;
  margin-right: 10px;
}

.dashboard-nav-list {
  display: -webkit-box;
  display: -webkit-flex;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-orient: vertical;
  -webkit-box-direction: normal;
  -webkit-flex-direction: column;
  -ms-flex-direction: column;
  flex-direction: column;
}

.dashboard-nav-item {
  min-height: 56px;
  padding: 8px 20px 8px 70px;
  display: -webkit-box;
  display: -webkit-flex;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-align: center;
  -webkit-align-items: center;
  -ms-flex-align: center;
  align-items: center;
  letter-spacing: 0.02em;
  transition: ease-out 0.5s;
  border-radius: 4px;
  border-color: #4e4c4c;
}

.dashboard-nav-item i {
  width: 36px;
  font-size: 19px;
  margin-left: -40px;
}

.dashboard-nav-item:hover {
  background: rgba(255, 255, 255, 0.04);
}

.active {
  background: rgba(0, 0, 0, 0.1);
}

.dashboard-nav-dropdown.show > .dashboard-nav-dropdown-toggle {
  font-weight: bold;
}

.dashboard-nav-dropdown.show > .dashboard-nav-dropdown-toggle:after {
  -webkit-transform: none;
  -o-transform: none;
  transform: none;
}

.dashboard-nav-dropdown.show > .dashboard-nav-dropdown-menu {
  display: -webkit-box;
  display: -webkit-flex;
  display: -ms-flexbox;
  display: flex;
}


.dashboard-nav .dashboard-nav-dropdown-toggle:after {
  border-top-color: rgba(255, 255, 255, 0.72);
}


.menu-toggle {
  position: relative;
  width: 42px;
  height: 42px;
  display: -webkit-box;
  display: -webkit-flex;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-align: center;
  -webkit-align-items: center;
  -ms-flex-align: center;
  align-items: center;
  -webkit-box-pack: center;
  -webkit-justify-content: center;
  -ms-flex-pack: center;
  justify-content: center;
  color: #443ea2;
}

.menu-toggle:hover, .menu-toggle:active, .menu-toggle:focus {
  text-decoration: none;
  color: #875de5;
}

.menu-toggle i {
  font-size: 20px;
}


.nav-item-divider {
  height: 1px;
  margin: 1rem 0;
  overflow: hidden;
  background-color: rgba(235, 237, 238, 0.3);
}

@media (min-width: 992px) {
  .dashboard-app {
    margin-left: 238px;
  }

  .dashboard-compact .dashboard-app {
    margin-left: 0;
  }
}


@media (max-width: 768px) {
  .dashboard-content {
    padding: 15px 0px;
  }
}

@media (max-width: 992px) {
  .dashboard-nav {
    display: none;
    position: fixed;
    top: 0;
    right: 0;
    left: 0;
    bottom: 0;
    z-index: 1070;
  }

  .dashboard-nav.mobile-show {
    display: block;
  }
}

@media (max-width: 992px) {
  .dashboard-nav header .menu-toggle {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
  }
}

@media (min-width: 992px) {
  .dashboard-toolbar {
    left: 238px;
  }

  .dashboard-compact .dashboard-toolbar {
    left: 0;
  }
}
</style>
